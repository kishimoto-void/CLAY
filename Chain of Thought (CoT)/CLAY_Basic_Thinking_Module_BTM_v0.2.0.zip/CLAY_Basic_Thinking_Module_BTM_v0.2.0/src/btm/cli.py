from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

from .analysis import analyze_instructions
from .models import validate_instruction_set
from .prompt_compiler import compile_prompt


def _load(path: str) -> Any:
    try:
        with Path(path).open("r", encoding="utf-8") as fh:
            return json.load(fh)
    except (OSError, json.JSONDecodeError) as exc:
        raise ValueError(f"cannot read JSON file {path}: {exc}") from exc


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="btm", description="CLAY Basic Thinking Module utilities")
    sub = parser.add_subparsers(dest="command", required=True)

    p_validate = sub.add_parser("validate", help="validate an instruction JSON array")
    p_validate.add_argument("instructions")

    p_analyze = sub.add_parser("analyze", help="analyze scope, time, and potential conflicts")
    p_analyze.add_argument("--instructions", required=True)
    p_analyze.add_argument("--context", required=True)

    p_compile = sub.add_parser("compile", help="compile a portable prompt package")
    p_compile.add_argument("--instructions", required=True)
    p_compile.add_argument("--context", required=True)
    p_compile.add_argument("--personality")
    p_compile.add_argument("--thinking-control", help="optional task-level thinking-control JSON object")
    p_compile.add_argument("--target", default="generic")
    p_compile.add_argument("--output", required=True)

    args = parser.parse_args(argv)
    try:
        records = _load(args.instructions if args.command != "validate" else args.instructions)
        if not isinstance(records, list):
            raise ValueError("instructions JSON root must be an array")
        if args.command == "validate":
            errors = validate_instruction_set(records)
            print(json.dumps({"valid": not errors, "errors": errors}, ensure_ascii=False, indent=2))
            return 0 if not errors else 2

        context = _load(args.context)
        if not isinstance(context, dict):
            raise ValueError("context JSON root must be an object")

        if args.command == "analyze":
            result = analyze_instructions(records, context)
            print(json.dumps(result, ensure_ascii=False, indent=2))
            return 0 if result["valid"] else 2

        personality = _load(args.personality) if args.personality else {}
        if not isinstance(personality, dict):
            raise ValueError("personality JSON root must be an object")
        thinking_control = _load(args.thinking_control) if args.thinking_control else None
        if thinking_control is not None and not isinstance(thinking_control, dict):
            raise ValueError("thinking-control JSON root must be an object")
        prompt, result = compile_prompt(records, context, personality, args.target, thinking_control)
        try:
            Path(args.output).write_text(prompt, encoding="utf-8")
        except OSError as exc:
            raise ValueError(f"cannot write prompt output {args.output}: {exc}") from exc
        print(json.dumps({"written": args.output, "active": result["active"], "held": result["held"], "conflicts": result["conflicts"]}, ensure_ascii=False, indent=2))
        return 0
    except (ValueError, KeyError, TypeError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2
