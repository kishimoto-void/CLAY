from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Mapping

from .models import parse_datetime, validate_instruction_set


def _scope_state(record: Mapping[str, Any], context: Mapping[str, Any]) -> tuple[bool, str]:
    scope = record["scope"]
    kind = scope["type"]
    if kind in {"TURN", "SESSION", "TASK"}:
        key = {"TURN": "turn_id", "SESSION": "session_id", "TASK": "task_id"}[kind]
        if context.get(key) != scope.get("ref"):
            return False, f"scope_mismatch_or_missing_context:{key}"
    elif kind not in {"PERSISTENT", "TEMPORARY", "CONDITIONAL"}:
        return False, "unsupported_scope"

    # Additional exact-match conditions may be attached to any scope type.
    conditions = record.get("conditions", {})
    for key, expected in conditions.items():
        if key not in context:
            return False, f"condition_context_missing:{key}"
        if context[key] != expected:
            return False, f"condition_not_met:{key}"
    return True, "conditions_match" if conditions else "scope_matches"


def _in_time(record: Mapping[str, Any], now: datetime) -> tuple[bool, str]:
    start = parse_datetime(record.get("valid_from"))
    end = parse_datetime(record.get("valid_until"))
    if start and now < start:
        return False, "not_yet_valid"
    if end and now >= end:
        return False, "expired"
    return True, "within_validity_window"


def _scope_overlap(a: Mapping[str, Any], b: Mapping[str, Any]) -> str:
    sa, sb = a["scope"], b["scope"]
    ka, kb = sa["type"], sb["type"]
    ca, cb = a.get("conditions", {}), b.get("conditions", {})
    for key in set(ca) & set(cb):
        if ca[key] != cb[key]:
            return "NO"
    if ka == "PERSISTENT" or kb == "PERSISTENT":
        return "YES"
    if ka == kb:
        if ka in {"TURN", "SESSION", "TASK"}:
            return "YES" if sa.get("ref") == sb.get("ref") else "NO"
        if ka == "CONDITIONAL":
            return "YES" if ca == cb else "UNKNOWN"
        return "YES"  # TEMPORARY time overlap is checked separately.
    return "UNKNOWN"  # e.g. SESSION and TASK hierarchy is host-specific.


def _time_overlap(a: Mapping[str, Any], b: Mapping[str, Any]) -> str:
    a_start = parse_datetime(a.get("valid_from")) or datetime.min.replace(tzinfo=timezone.utc)
    b_start = parse_datetime(b.get("valid_from")) or datetime.min.replace(tzinfo=timezone.utc)
    a_end = parse_datetime(a.get("valid_until")) or datetime.max.replace(tzinfo=timezone.utc)
    b_end = parse_datetime(b.get("valid_until")) or datetime.max.replace(tzinfo=timezone.utc)
    return "YES" if max(a_start, b_start) < min(a_end, b_end) else "NO"


def analyze_instructions(records: list[Mapping[str, Any]], context: Mapping[str, Any], now: datetime | None = None) -> dict[str, Any]:
    errors = validate_instruction_set(records)
    if errors:
        return {"valid": False, "errors": errors, "active": [], "held": [], "conflicts": [], "supersessions": []}

    now = now or datetime.now(timezone.utc)
    if now.tzinfo is None:
        raise ValueError("now must be timezone-aware")
    candidates: list[Mapping[str, Any]] = []
    held: list[dict[str, str]] = []

    # First establish which replacement records are themselves eligible.
    # An unconfirmed, expired, or out-of-scope record must not supersede anything.
    for record in records:
        rid = record["id"]
        if record["status"] == "SUPERSEDED":
            held.append({"id": rid, "reason": "status:superseded"})
            continue
        if record["status"] != "ACTIVE":
            held.append({"id": rid, "reason": f"status:{record['status'].lower()}"})
            continue
        if record["confirmation"] != "CONFIRMED":
            held.append({"id": rid, "reason": f"confirmation:{record['confirmation'].lower()}"})
            continue
        time_ok, time_reason = _in_time(record, now)
        if not time_ok:
            held.append({"id": rid, "reason": time_reason})
            continue
        scope_ok, scope_reason = _scope_state(record, context)
        if not scope_ok:
            held.append({"id": rid, "reason": scope_reason})
            continue
        candidates.append(record)

    by_id = {r["id"]: r for r in records}
    accepted_supersessions: list[dict[str, str]] = []
    supersession_issues: list[dict[str, Any]] = []
    for replacement in candidates:
        for old_id in replacement.get("supersedes", []):
            old = by_id[old_id]
            if replacement["topic"].strip().casefold() != old["topic"].strip().casefold():
                supersession_issues.append({"new_id": replacement["id"], "old_id": old_id, "reason": "topic_mismatch"})
                continue
            scope_state = _scope_overlap(replacement, old)
            time_state = _time_overlap(replacement, old)
            if scope_state != "YES" or time_state != "YES":
                supersession_issues.append({
                    "new_id": replacement["id"], "old_id": old_id,
                    "reason": "scope_or_time_overlap_not_proven",
                    "scope_overlap": scope_state, "time_overlap": time_state
                })
                continue
            accepted_supersessions.append({"new_id": replacement["id"], "superseded_id": old_id})

    # Reject cyclic replacement graphs; a cycle cannot establish a stable current record.
    graph: dict[str, list[str]] = {}
    for edge in accepted_supersessions:
        graph.setdefault(edge["new_id"], []).append(edge["superseded_id"])
    cycle_edges: set[tuple[str, str]] = set()

    def walk(node: str, path: list[str]) -> None:
        if node in path:
            cycle = path[path.index(node):]
            for index, source in enumerate(cycle):
                target = cycle[(index + 1) % len(cycle)]
                cycle_edges.add((source, target))
            return
        for target in graph.get(node, []):
            walk(target, path + [node])

    for node in graph:
        walk(node, [])

    if cycle_edges:
        kept_edges = []
        for edge in accepted_supersessions:
            pair = (edge["new_id"], edge["superseded_id"])
            if pair in cycle_edges:
                supersession_issues.append({"new_id": pair[0], "old_id": pair[1], "reason": "supersession_cycle"})
            else:
                kept_edges.append(edge)
        accepted_supersessions = kept_edges

    superseded_ids = {item["superseded_id"] for item in accepted_supersessions}
    eligible: list[Mapping[str, Any]] = []
    for record in candidates:
        if record["id"] in superseded_ids:
            held.append({"id": record["id"], "reason": "superseded_by_active_confirmed_record"})
        else:
            eligible.append(record)

    conflicts: list[dict[str, Any]] = []
    conflicted_ids: set[str] = set()
    for i, left in enumerate(eligible):
        for right in eligible[i + 1:]:
            same_topic = left["topic"].strip().casefold() == right["topic"].strip().casefold()
            declared_conflict = right["id"] in left.get("conflicts_with", []) or left["id"] in right.get("conflicts_with", [])
            different_content = left["content"].strip() != right["content"].strip()
            if not declared_conflict and not (same_topic and different_content):
                continue
            time_state = _time_overlap(left, right)
            scope_state = _scope_overlap(left, right)
            if time_state == "NO" or scope_state == "NO":
                continue
            # Explicit replacement is already removed via superseded_ids above.
            conflicts.append({
                "type": "POTENTIAL_CONFLICT",
                "instruction_ids": [left["id"], right["id"]],
                "topic": left["topic"] if same_topic else f"{left['topic']} <> {right['topic']}",
                "declared": declared_conflict,
                "time_overlap": time_state,
                "scope_overlap": scope_state,
                "resolution": "HOLD_FOR_REVIEW",
                "note": "Do not select by recency or priority. Human/host review required."
            })
            conflicted_ids.update((left["id"], right["id"]))

    active = [r["id"] for r in eligible if r["id"] not in conflicted_ids]
    for rid in sorted(conflicted_ids):
        held.append({"id": rid, "reason": "potential_conflict"})

    supersessions = [dict(item, declaration="explicit") for item in accepted_supersessions]

    return {
        "valid": True,
        "errors": [],
        "evaluated_at": now.isoformat(),
        "active": active,
        "held": held,
        "conflicts": conflicts,
        "supersessions": supersessions,
        "supersession_issues": supersession_issues,
        "notes": [
            "Conflict detection is topic-key screening, not semantic contradiction proof.",
            "Different non-persistent scope types are treated as unknown overlap.",
            "The host must validate source authority before accepting supersession."
        ]
    }
