"""CLAY Basic Thinking Module."""

__version__ = "0.2.0"
