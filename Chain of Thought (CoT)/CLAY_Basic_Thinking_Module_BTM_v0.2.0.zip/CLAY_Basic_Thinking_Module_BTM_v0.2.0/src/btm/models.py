from __future__ import annotations

from datetime import datetime
from typing import Any, Mapping

SOURCES = {"USER", "SYSTEM", "DEVELOPER", "HOST", "IMPORTED", "MODEL_INFERRED"}
SCOPES = {"TURN", "SESSION", "TASK", "TEMPORARY", "PERSISTENT", "CONDITIONAL"}
STATUSES = {"DRAFT", "ACTIVE", "SUSPENDED", "REVOKED", "SUPERSEDED"}
CONFIRMATIONS = {"CONFIRMED", "UNCONFIRMED", "REVIEW_REQUIRED"}
PRIORITIES = {"LOW", "NORMAL", "HIGH", "CRITICAL"}


def parse_datetime(value: str | None) -> datetime | None:
    if value is None:
        return None
    if not isinstance(value, str) or not value.strip():
        raise ValueError("datetime must be a non-empty ISO-8601 string")
    normalized = value[:-1] + "+00:00" if value.endswith("Z") else value
    dt = datetime.fromisoformat(normalized)
    if dt.tzinfo is None:
        raise ValueError("datetime must include timezone information, e.g. +00:00 or Z")
    return dt


def validate_instruction(record: Mapping[str, Any]) -> list[str]:
    """Return structural errors. Does not infer meaning from natural-language content."""
    errors: list[str] = []
    required = ("id", "topic", "content", "source", "confirmed_by", "scope", "created_at", "status", "confirmation")
    for key in required:
        if key not in record:
            errors.append(f"missing required field: {key}")
    if errors:
        return errors

    for key in ("id", "topic", "content"):
        if not isinstance(record.get(key), str) or not record[key].strip():
            errors.append(f"{key} must be a non-empty string")

    if record.get("source") not in SOURCES:
        errors.append(f"source must be one of {sorted(SOURCES)}")
    if record.get("status") not in STATUSES:
        errors.append(f"status must be one of {sorted(STATUSES)}")
    if record.get("confirmation") not in CONFIRMATIONS:
        errors.append(f"confirmation must be one of {sorted(CONFIRMATIONS)}")
    if record.get("confirmation") == "CONFIRMED" and not (isinstance(record.get("confirmed_by"), str) and record["confirmed_by"].strip()):
        errors.append("confirmed_by must identify the confirming actor when confirmation is CONFIRMED")
    if record.get("confirmed_by") is not None and not isinstance(record.get("confirmed_by"), str):
        errors.append("confirmed_by must be a string or null")
    if record.get("priority", "NORMAL") not in PRIORITIES:
        errors.append(f"priority must be one of {sorted(PRIORITIES)}")

    scope = record.get("scope")
    if not isinstance(scope, dict):
        errors.append("scope must be an object")
    else:
        kind = scope.get("type")
        if kind not in SCOPES:
            errors.append(f"scope.type must be one of {sorted(SCOPES)}")
        if kind in {"TURN", "SESSION", "TASK"} and not (isinstance(scope.get("ref"), str) and scope["ref"].strip()):
            errors.append(f"scope.ref is required for {kind}")
        if kind == "PERSISTENT" and scope.get("ref") is not None:
            errors.append("PERSISTENT scope must not have ref")

    for field in ("created_at", "valid_from", "valid_until"):
        try:
            parse_datetime(record.get(field))
        except (ValueError, TypeError) as exc:
            errors.append(f"{field}: {exc}")
    try:
        start = parse_datetime(record.get("valid_from"))
        end = parse_datetime(record.get("valid_until"))
        if start and end and end <= start:
            errors.append("valid_until must be later than valid_from")
    except (ValueError, TypeError):
        pass

    if isinstance(scope, dict) and scope.get("type") == "TEMPORARY" and not record.get("valid_until"):
        errors.append("valid_until is required for TEMPORARY scope")
    if isinstance(scope, dict) and scope.get("type") == "CONDITIONAL":
        conditions = record.get("conditions")
        if not isinstance(conditions, dict) or not conditions:
            errors.append("non-empty conditions object is required for CONDITIONAL scope")

    conditions = record.get("conditions", {})
    if not isinstance(conditions, dict):
        errors.append("conditions must be an object")
    elif any(not isinstance(k, str) or not k.strip() for k in conditions):
        errors.append("condition keys must be non-empty strings")

    for field in ("supersedes", "conflicts_with"):
        value = record.get(field, [])
        if not isinstance(value, list) or any(not isinstance(x, str) or not x.strip() for x in value):
            errors.append(f"{field} must be an array of non-empty strings")
    return errors


def validate_instruction_set(records: list[Mapping[str, Any]]) -> list[str]:
    errors: list[str] = []
    ids: set[str] = set()
    object_records: list[tuple[int, Mapping[str, Any]]] = []
    for index, record in enumerate(records):
        if not isinstance(record, Mapping):
            errors.append(f"record[{index}] must be an object")
            continue
        object_records.append((index, record))
        for error in validate_instruction(record):
            errors.append(f"record[{index}]: {error}")
        record_id = record.get("id")
        if isinstance(record_id, str):
            if record_id in ids:
                errors.append(f"duplicate instruction id: {record_id}")
            ids.add(record_id)
    for index, record in object_records:
        for field in ("supersedes", "conflicts_with"):
            refs = record.get(field, []) if isinstance(record.get(field, []), list) else []
            for target in refs:
                if target not in ids:
                    errors.append(f"record[{index}]: {field} references unknown id: {target}")
                if target == record.get("id"):
                    errors.append(f"record[{index}]: instruction cannot reference itself in {field}")
    return errors


def validate_personality_profile(profile: Mapping[str, Any]) -> list[str]:
    errors: list[str] = []
    allowed = {"display_name", "tone", "style", "traits", "preferences", "avoid", "initiative", "verbosity", "debate_style"}
    for key in profile:
        if key not in allowed:
            errors.append(f"unknown personality field: {key}")
    string_fields = {"display_name", "tone", "style", "initiative", "verbosity", "debate_style"}
    list_fields = {"traits", "preferences", "avoid"}
    for key in string_fields:
        if key in profile and not isinstance(profile[key], str):
            errors.append(f"personality.{key} must be a string")
    for key in list_fields:
        if key in profile:
            value = profile[key]
            if not isinstance(value, list) or any(not isinstance(x, str) or not x.strip() for x in value):
                errors.append(f"personality.{key} must be an array of non-empty strings")
    return errors
