from __future__ import annotations

from typing import Any, Mapping

REQUESTED_RIGOR = {"QUICK", "STANDARD", "RIGOROUS"}
COGNITIVE_DIRECTIONS = {"AUTO", "CONVERGENCE", "DIFFUSION"}
SCOPE_POLICIES = {"BOUNDED", "CONSULT_BEFORE_EXPANSION", "USER_EXPANSION_REQUESTED"}
_ALLOWED_FIELDS = {
    "requested_rigor", "cognitive_direction", "scope_policy", "objective",
    "critical_outcomes", "hard_constraints", "flexible_constraints", "stop_condition"
}
_DEFAULTS: dict[str, Any] = {
    "requested_rigor": "STANDARD",
    "cognitive_direction": "AUTO",
    "scope_policy": "BOUNDED",
    "objective": None,
    "critical_outcomes": [],
    "hard_constraints": [],
    "flexible_constraints": [],
    "stop_condition": None,
}


def validate_thinking_control(profile: Mapping[str, Any] | None) -> list[str]:
    """Validate explicit task-control metadata; this does not infer user intent."""
    if profile is None:
        return []
    if not isinstance(profile, Mapping):
        return ["thinking_control must be an object/mapping"]

    errors: list[str] = []
    for key in profile:
        if key not in _ALLOWED_FIELDS:
            errors.append(f"unknown thinking_control field: {key}")

    if "requested_rigor" in profile:
        value = profile["requested_rigor"]
        if not isinstance(value, str) or value not in REQUESTED_RIGOR:
            errors.append(f"thinking_control.requested_rigor must be one of {sorted(REQUESTED_RIGOR)}")
    if "cognitive_direction" in profile:
        value = profile["cognitive_direction"]
        if not isinstance(value, str) or value not in COGNITIVE_DIRECTIONS:
            errors.append(f"thinking_control.cognitive_direction must be one of {sorted(COGNITIVE_DIRECTIONS)}")
    if "scope_policy" in profile:
        value = profile["scope_policy"]
        if not isinstance(value, str) or value not in SCOPE_POLICIES:
            errors.append(f"thinking_control.scope_policy must be one of {sorted(SCOPE_POLICIES)}")

    for key in ("objective", "stop_condition"):
        if key in profile and profile[key] is not None:
            if not isinstance(profile[key], str) or not profile[key].strip():
                errors.append(f"thinking_control.{key} must be a non-empty string or null")

    for key in ("critical_outcomes", "hard_constraints", "flexible_constraints"):
        if key in profile:
            value = profile[key]
            if not isinstance(value, list) or any(not isinstance(x, str) or not x.strip() for x in value):
                errors.append(f"thinking_control.{key} must be an array of non-empty strings")
    return errors


def normalize_thinking_control(profile: Mapping[str, Any] | None = None) -> dict[str, Any]:
    """Return a fresh profile with conservative defaults after structural validation."""
    errors = validate_thinking_control(profile)
    if errors:
        raise ValueError("Invalid thinking control profile: " + "; ".join(errors))
    normalized = {
        key: (value.copy() if isinstance(value, list) else value)
        for key, value in _DEFAULTS.items()
    }
    if profile:
        for key, value in profile.items():
            normalized[key] = value.copy() if isinstance(value, list) else value
    return normalized
