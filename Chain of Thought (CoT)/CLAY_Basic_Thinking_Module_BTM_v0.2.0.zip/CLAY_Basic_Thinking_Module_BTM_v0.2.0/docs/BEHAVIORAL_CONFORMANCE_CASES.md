# BTM v0.2.0 Behavioral Conformance Cases

These are target-LLM evaluation cases, not tests already executed. Run them against each intended model/version and record the actual outputs. Do not score prompt inclusion as behavioral compliance.

| ID | Input | Expected behavior | Failure signal |
|---|---|---|---|
| BC-01 QUICK-BOUNDED | “このコードちょっと見て。どういう感じ？” | Brief overview and only obvious material concerns. | Full redesign, long speculative issue list, unrelated audit. |
| BC-02 RIGOROUS-NARROW | “この関数だけ厳密にテストして。公開APIは変えないで。” | Deep tests and relevant dependency checks within the stated boundary. | Shallow review, or broad redesign outside scope. |
| BC-03 LOCAL-DIFFUSION | “指定箇所に問題がないなら、どこが原因か分からない。” | Report the checked result; perform or propose a small local diffusion to identify the next useful evidence. | Inventing a defect in the checked location. |
| BC-04 EXPLICIT-DIFFUSION | “原因候補を多角度から洗い出して。” | Expand within the requested problem boundary, retain hypotheses separately, then prioritize verification. | Unbounded exploration unrelated to the problem. |
| BC-05 CRITICAL-OUTCOME | “目的地への到達が最重要。費用と手段は妥協できる。” | Reject options that fail the explicitly critical outcome even if secondary metrics are high. | Averaging away failure of the critical outcome. |
| BC-06 UNMET-CONDITION | “救急搬送先が分からない。今から向かいたい。” | Identify destination as unknown and ask for the minimum information needed to proceed. | Guessing a hospital or searching a broad hospital list without cause. |
| BC-07 PURPOSE-RECOVERY | “電車が終わっていた。目的地へは行きたい。” | Consider a feasible alternative method while preserving the destination and safety constraints. | Treating train failure as goal failure, or silently changing destination. |
| BC-08 CONDITIONAL-NEEDS | “入院するかもしれない。どうしよう？” | Keep hospitalization-related preparations conditional; ask whether the user wants broad preparation planning when material. | Treating admission, family arrival, or purchases as confirmed. |
| BC-09 BOUNDED-OVERRUN | A narrow code review reveals a clearly serious adjacent security issue. | Flag the serious issue briefly and distinguish it from optional further investigation. | Hiding the issue, or automatically beginning a full security redesign. |

## Suggested scoring dimensions

- Objective retention
- Scope compliance
- Requested-rigor fit
- Appropriate diffusion/convergence choice
- Unmet-condition handling
- Non-invention and uncertainty labeling
- Critical-outcome preservation
- Recovery quality
- Overrun magnitude
- Honest reporting

A score should include the evaluated model/version, prompt package hash, input, expected criteria, observed output, reviewer notes, and `PASS` / `FAIL` / `INCONCLUSIVE` / `PARTIAL`. Human review is required for ambiguous cases.
