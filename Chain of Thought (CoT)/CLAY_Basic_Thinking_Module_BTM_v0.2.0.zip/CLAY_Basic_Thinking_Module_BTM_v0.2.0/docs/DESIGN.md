# BTM Design Overview

## Purpose

BTM defines a shared baseline for instruction handling across CLAY thinking and specialist modules. It does not add domain knowledge or claim to make an LLM more intelligent. It aims to reduce avoidable errors caused by ambiguous instructions, stale context, scope leakage, silent conflict resolution, and dishonest reporting.

## Layers

### 1. Basic Thinking Principles — stable baseline

Defines how instructions and evidence should be handled. These principles should not be rewritten by personality settings.

### 2. Instruction Registry — structured and auditable

Stores each instruction with source, scope, validity interval, conditions, status, confirmation state, and explicit supersession references. A record is not automatically valid merely because it exists in memory.

### 3. Personality / Behavior Layer — variable

Stores preferred tone, conversational style, initiative, debate style, verbosity, and similar preferences. This layer changes expression and interaction style; it must not silently rewrite BTM principles, authority boundaries, or factual standards.

### 4. Prompt Compiler — translation

Combines the BTM baseline, active instruction subset, unresolved issues, and personality profile into a prompt package for a target LLM. v0.2.0 uses a generic portable format. Provider-specific optimizations are not claimed.

### 5. Task Thinking Control — task-local and optional

Validates and packages explicit task-level rigor, cognitive direction, scope policy, objective, critical outcomes, hard/flexible constraints, and stop condition. It is distinct from personality. When absent, the compiled prompt supplies conservative defaults and instructs the target LLM to infer intent cautiously from the current request. The deterministic reference code does not classify natural-language intent.

### 6. Host / Runtime — outside BTM

The host loads data, selects models, grants tool permissions, executes tools, validates results, and applies non-delegable safety policy. BTM does not acquire these capabilities merely by declaring them.

## Processing flow

```text
Instruction + Context + Personality Profile + Optional Task Control
                  |
                  v
         Record Validation + Task-Control Validation
                  |
                  v
     Scope / Time / Condition Check
                  |
                  v
       Conflict & Supersession Analysis
             /             \
       Clear active       Unresolved
           |                 |
           v                 v
  Prompt Compilation   Hold / Ask / Report
           |
           v
    Target LLM (external)
           |
           v
 Host-side output review / execution controls
```

## Conservative resolution rules

- Newer does not automatically mean more authoritative.
- Priority metadata does not silently resolve a contradiction.
- Only an explicit `supersedes` relationship expresses an intended replacement in the registry.
- A model-inferred instruction is not active until confirmed.
- Unknown context or natural-language conditions are not guessed by the deterministic engine.
- Potential conflicts are reported for review; no score or majority vote manufactures a resolution.

## What BTM is not

BTM is not a truth engine, provider-side memory manager, autonomous execution environment, or security boundary. It is a structured instruction-integrity component and prompt compiler reference implementation.


## Request-adaptive thinking guidance

BTM distinguishes requested rigor from exploration scope. A narrow task may require rigorous verification without broadening the task. Convergence focuses on a named target; diffusion explores the smallest relevant set of unknown causes or alternatives. The target LLM chooses the direction from intent and context, while the code validates only explicitly supplied task-control metadata.

See `THINKING_CONTROL.md` and `ICC_BOUNDARY.md`.
