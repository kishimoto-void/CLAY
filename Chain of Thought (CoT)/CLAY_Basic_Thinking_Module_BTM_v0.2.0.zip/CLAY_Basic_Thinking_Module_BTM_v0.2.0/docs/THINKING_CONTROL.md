# BTM Task-Adaptive Thinking Control (v0.2.0)

## Purpose

This extension brings general-purpose parts of the ICC discussion into BTM without embedding ICC's specialist coordinate system, Problem Box lifecycle, evidence graph, or domain-specific convergence engine.

BTM's role is to provide a portable baseline for effort calibration, bounded scope, and request-responsive thinking direction. The actual semantic interpretation is performed by the target LLM; the reference code validates explicit control metadata and compiles it into the prompt.

## Separate four controls

1. **Requested rigor** — QUICK, STANDARD, or RIGOROUS. This controls depth and verification intensity.
2. **Cognitive direction** — AUTO, CONVERGENCE, or DIFFUSION. This is a task-local guidance signal.
3. **Scope policy** — BOUNDED, CONSULT_BEFORE_EXPANSION, or USER_EXPANSION_REQUESTED.
4. **Task criteria** — objective, explicitly designated critical outcomes, hard constraints, flexible constraints, and stop condition.

These controls are orthogonal. RIGOROUS does not mean broad. A request can demand rigorous verification of one narrow function. DIFFUSION does not authorize unbounded exploration. A declared critical outcome is non-compensable by secondary quality criteria, but BTM must not invent critical outcomes.

## Direction definitions

### CONVERGENCE

Focus on the named object, question, or goal. Inspect only dependencies and adjacent context needed to answer reliably. Do not launch a redesign or unrelated survey. If the specified target is not defective, report what was checked and do not manufacture a defect.

### DIFFUSION

Explore relevant causes, interpretations, alternatives, or missing conditions when the problem is under-specified or the user requests broader exploration. Start with the smallest useful expansion. Keep hypotheses distinct from facts, then return to focused evaluation when a useful candidate is identified.

### AUTO

Choose the direction from semantic intent, context, and problem state rather than keywords alone. A light request such as “take a quick look” usually calls for bounded, low-depth convergence. “Test this rigorously” calls for high-depth verification within the requested scope. “I don't know where the problem is” may justify limited diffusion. “What should I do?” may invite broader options, but it does not automatically authorize every conceivable preparation or action.

## Unmet-condition handling

When progress is blocked by a missing condition:

- state the condition that is not yet known or satisfied;
- identify the minimum information or action needed next;
- ask only the question that materially unlocks progress;
- do not guess, fabricate a location, infer a fact as confirmed, or search unrelated alternatives by default.

## Purpose-preserving recovery

A failed method is not necessarily a failed objective. Offer alternative methods that preserve the objective and hard constraints. Changes to the objective or hard constraints require human approval. A revised Problem Box or specialist coordinate model belongs to a specialist module such as ICC, not to BTM's generic control layer.

## Bounded overrun

LLMs may produce adjacent ideas beyond the exact request. BTM guidance treats this as a bounded behavior:

- a significant directly related risk may be briefly flagged;
- an optional expansion may be proposed without executing it;
- substantial additional investigation or action requires user direction or approval;
- once the requested task is satisfied, stop rather than continuing to broaden the answer.

## Safety and risk

Higher consequences may justify stronger verification and clear safety caveats. They do not grant permission to expand into unrelated work or bypass host/platform controls. Immediate safety-critical guidance remains subject to the applicable safety policy and host rules.

## Runtime boundary

The `thinking_control` profile is optional task metadata. The deterministic implementation validates allowed fields and serializes the profile into a prompt. It does not classify natural language, inspect hidden model state, enforce tool permissions, or guarantee that an external LLM follows the guidance.
