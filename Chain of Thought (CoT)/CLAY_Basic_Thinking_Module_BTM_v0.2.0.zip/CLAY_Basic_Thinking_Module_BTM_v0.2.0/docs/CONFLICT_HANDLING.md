# Conflict Handling

## Why recency is insufficient

A newer instruction may be a temporary exception, a context switch, a correction, or an accidental contradiction. A timestamp alone cannot determine which interpretation is legitimate.

## v0.1.0 deterministic rule

The analyzer flags potential conflicts when records share a topic and have different content, or when either record explicitly lists the other in `conflicts_with`. It then checks time and scope overlap. It does not infer semantic equivalence or contradiction from arbitrary prose.

### Explicit supersession

A new record may list old instruction IDs in `supersedes`. This makes the intended replacement explicit in the record. The analyzer excludes the superseded record from the effective set only when the topic, time interval, and scope overlap are supported. Cyclic replacement declarations are rejected and surfaced. A production host should still verify the source's authority before accepting the replacement.

### Unresolved conflict

When no explicit supersession exists, both records are held out of the active prompt and returned as `POTENTIAL_CONFLICT`. The host should ask the authorized person, preserve both records, and append a decision event. Do not delete or silently overwrite either record.

## Scope overlap

- Same scope type + same reference: known overlap.
- Any `PERSISTENT` scope: overlaps other scopes unless explicit conditions prove otherwise.
- Different non-persistent scope types: overlap is treated as unknown and surfaced for review, not silently assumed to be disjoint.
- Different values for the same exact-match condition key: treated as non-overlapping for that key.

This is a conservative screening heuristic, not a full temporal logic or natural-language reasoning engine.
