# Boundary Between BTM and ICC

## BTM responsibility

BTM owns general-purpose instruction integrity and request-adaptive interaction guidance:

- Verified Fidelity and instruction lifecycle handling;
- effort calibration to requested rigor;
- bounded diffusion and targeted convergence as general response guidance;
- scope expansion consultation and bounded overrun;
- preservation of explicitly declared critical outcomes;
- minimum unmet-condition resolution;
- purpose-preserving recovery guidance;
- honest reporting and human handoff.

## ICC responsibility

ICC remains a separate specialist thinking module. It may implement deeper domain-independent problem-engineering mechanisms such as:

- Problem Box formation and revalidation;
- human-approved initial coordinate axes;
- critical-axis non-compensation with formal axis metadata;
- coordinate expansion versus coordinate resolution;
- phase-based macro-to-micro refinement;
- evidence graphs, independence analysis, residual vectors, and hypothesis ecology;
- specialized diffusion/convergence dynamics and recovery planning;
- phase records and handoff capsules.

## Non-absorption rule

BTM does not become a lightweight ICC implementation. Its control principles should be useful for ordinary tasks and other specialist modules. It must not require all tasks to create a Problem Box, define three axes, run a multi-phase process, or perform broad evidence analysis.

ICC may use BTM as a baseline, but ICC-specific concepts remain in the ICC module and cannot be silently imposed on unrelated modules.
