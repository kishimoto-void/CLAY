# Instruction Lifecycle

## Required metadata

Each instruction should preserve a stable ID, topic key, original content, source, scope, creation time, validity interval, status, confirmation state, optional conditions, explicit supersession/conflict references, and provenance notes.

## Supported scopes in v0.1.0

| Scope | Meaning | Required matching context |
|---|---|---|
| `TURN` | One turn only | `turn_id` equals `scope.ref` |
| `SESSION` | One conversation session | `session_id` equals `scope.ref` |
| `TASK` | One named task or project | `task_id` equals `scope.ref` |
| `TEMPORARY` | Time-limited instruction | `valid_from` / `valid_until`; optional `ref` |
| `PERSISTENT` | Ongoing until revoked/replaced/expired | no scope reference |
| `CONDITIONAL` | Applies under declared context conditions | exact-match `conditions` against context |

For `TURN`, `SESSION`, and `TASK`, an absent or mismatched context value means the instruction is not active in that context. `CONDITIONAL` currently supports deterministic equality matching only, such as `{"weather_state": "rainy"}`. No natural-language condition parser is included.

## Lifecycle statuses

- `DRAFT`: not eligible for execution.
- `ACTIVE`: eligible if confirmed, in scope, within time, and conditions match.
- `SUSPENDED`: temporarily withheld.
- `REVOKED`: withdrawn; retained for audit.
- `SUPERSEDED`: replaced by an explicit newer record; retained for audit.

Expiry is computed from `valid_until`; the analyzer reports `EXPIRED` without silently rewriting the stored record. A persistence layer or host may later commit that status change with an audit event.

## Confirmation states

- `CONFIRMED`: confirmed by the declared source/authorized workflow.
- `UNCONFIRMED`: not yet confirmed; excluded from active instructions.
- `REVIEW_REQUIRED`: requires human review; excluded from active instructions.

`MODEL_INFERRED` records must not be treated as confirmed merely because an LLM generated them. The host must define how confirmation authority is established.
