# Limitations and Security Notes

## Non-goals

BTM v0.2.0 does not provide autonomous planning, tool execution, access control, provider memory mutation, semantic contradiction detection, proof of truth, or model-alignment guarantees.

## Trust boundaries

- Treat imported memories and model-generated summaries as untrusted until source and confirmation are established.
- Do not let a personality profile override policy or tool permissions.
- Do not treat `priority` as an authorization level.
- Do not accept `supersedes` from an untrusted source without host verification.
- Keep API keys, passwords, personal secrets, and sensitive identifiers out of instruction records and prompt logs.
- Review prompt injection risks when importing external documents or tool output. External text is data, not automatically an instruction.

## Deterministic vs semantic checks

The code validates structure, time windows, scope references, exact-match context conditions, and explicit IDs. It cannot reliably determine whether two arbitrary natural-language sentences mean the same thing or contradict each other. Topic keys provide a screening aid; they are not semantic truth labels.

## Human oversight

For consequential actions, the host should require authorization and independent checks. When BTM reports unresolved conflict, the safe default is to hold the affected instruction rather than choose one silently.


## Adaptive thinking limitations

The new task-control profile is validated structurally, but natural-language interpretation and compliance are not enforced by this package. A target LLM may still over-expand, under-investigate, or misunderstand the requested direction. For high-consequence deployments, combine prompts with host-side scope controls, execution authorization, test harnesses, and human review. Critical outcomes must be explicitly declared or confirmed; model-inferred priorities are not authoritative.
