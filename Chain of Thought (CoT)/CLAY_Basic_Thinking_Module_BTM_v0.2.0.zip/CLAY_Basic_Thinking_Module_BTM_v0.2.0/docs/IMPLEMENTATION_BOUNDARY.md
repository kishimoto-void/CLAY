# Implementation Boundary

## Implemented now

- JSON instruction and personality records.
- Deterministic validation and eligibility checks.
- Time and scope evaluation.
- Simple equality conditions.
- Explicit supersession relationships.
- Potential-conflict screening.
- Markdown prompt compilation.
- CLI and unit tests.

## Deliberately not implemented

- General natural-language intent extraction.
- Automatic semantic conflict resolution.
- Automatic rewriting or deleting of historical instructions.
- Runtime model routing or provider API calls.
- Enforcement of model output or tool permissions.
- Autonomous personality inference and persistent memory writes.

## Suggested next implementation increments

1. Add an append-only event log for instruction creation, confirmation, suspension, replacement, and revocation.
2. Add a host-provided authority policy (who may create/confirm/replace which instruction classes).
3. Add a human review UI for unresolved conflicts.
4. Add provider-specific prompt adapters with conformance tests.
5. Add output checks for structured action requests and tool permissions, enforced outside the LLM.

Do not merge these specialist runtime capabilities into the BTM baseline without separate tests and explicit design approval.


## v0.2.0 thinking-control boundary

Implemented locally: validation/defaulting of a task-control JSON object and inclusion of that object plus adaptive guidance in the compiled prompt.

Prompt-specified only: semantic interpretation of user intent, selection of diffusion/convergence, actual effort calibration by a target model, recognition of critical outcomes from natural language, and behavioral scope discipline.

Not implemented: ICC coordinate construction, runtime scope enforcement, automatic tool permission management, output inspection for overrun, or measurement of model reasoning effort.
