# Prompt Compiler

## Purpose

The compiler turns validated records into a portable prompt package. It keeps the shared baseline separate from user-specific personality settings and from task-scoped instructions.

## Sections emitted

1. Role and limits of BTM.
2. Basic Thinking Principles.
3. Current context and active instructions.
4. Unresolved conflicts / instructions withheld from activation.
5. Personality and behavior preferences.
6. Reporting requirements.

## Personality separation

Personality settings can influence tone, verbosity, degree of initiative, and debate style. They cannot override BTM principles, create permissions, modify facts, suppress uncertainty, or silently promote model-inferred preferences into confirmed instructions.

## Target model adapter

v0.2.0 emits a generic portable prompt with optional task-level thinking controls. The `target` label is metadata only; it does not imply verified vendor-specific prompt optimization. Provider-specific adapters should be added only after testing against the relevant model versions and interfaces.

## Important

A prompt is an instruction to a model, not a technical guarantee. Host-side validators and permission controls are required where compliance matters.


## Task thinking-control profile (v0.2.0)

The optional `--thinking-control` input keeps task depth and scope separate. For example, a rigorous review of one function can use `requested_rigor=RIGOROUS`, `cognitive_direction=CONVERGENCE`, and `scope_policy=BOUNDED`. A broad cause search can use `cognitive_direction=DIFFUSION`, but diffusion remains bounded by the stated scope policy.

The compiler validates and serializes this metadata; it does not decide the semantic direction from raw conversation text. When no profile is supplied, the compiled prompt provides conservative defaults and asks the target LLM to infer intent cautiously.
