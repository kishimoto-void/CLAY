# BTM v0.2.0 Test Report

**Test date:** 2026-11-07  
**Runtime:** Python 3.13.5  
**Scope:** local reference implementation, schemas as JSON documents, CLI smoke tests, generated prompt content.  
**Status:** local structural checks passed; target-LLM behavioral compliance not tested.

## Results

| Check | Result |
|---|---|
| Unit tests | PASS — 30 tests |
| Python syntax / compileall | PASS |
| Existing instruction-set validation tests | PASS |
| Existing scope / lifecycle / conflict tests | PASS |
| Existing prompt compiler regression tests | PASS |
| New thinking-control validation tests | PASS |
| Prompt separation and control-profile injection | PASS |
| Rigor-vs-scope regression case | PASS |
| JSON parse: all schemas and manifest | PASS |
| Draft 2020-12 schema meta-validation | PASS |
| Example instruction/context/personality/thinking-control/analysis data validation | PASS |
| CLI instruction validation | PASS |
| CLI context / lifecycle analysis | PASS |
| CLI prompt compilation with task-control profile | PASS |
| Generated prompt contains adaptive policy and supplied control profile | PASS |

## New coverage

- Conservative defaults: `STANDARD`, `AUTO`, `BOUNDED`.
- Explicit `QUICK` / `RIGOROUS` depth selection.
- `AUTO` / `CONVERGENCE` / `DIFFUSION` direction validation.
- `BOUNDED` / `CONSULT_BEFORE_EXPANSION` / `USER_EXPANSION_REQUESTED` scope policy validation.
- Rejection of unknown fields and invalid types, including unhashable enum values.
- Normalization does not mutate caller-supplied lists.
- Prompt keeps rigor and scope separate; a rigorous request can remain narrowly bounded.
- Personality profile remains a separate section from task thinking-control metadata.

## Not tested / not claimed

- Behavioral conformance cases are documented but have not been run against a live target LLM.

- No live ChatGPT, Claude, Gemini, or other provider behavioral test was run.
- No claim is made that a target LLM will reliably infer user intent, choose diffusion/convergence correctly, or obey scope guidance.
- No natural-language intent-classification engine is implemented in Python.
- No runtime authorization, tool execution, memory persistence, or host-side scope enforcement is implemented.
- No ICC Problem Box, formal coordinate model, evidence graph, or specialist recovery engine is implemented in BTM.
- Python 3.10 runtime compatibility was not directly executed; tests were run on Python 3.13.5.

## Interpretation

The BTM v0.2.0 local reference implementation and prompt compilation checks passed in this environment. This demonstrates structural consistency of the included code and examples, not production readiness or behavioral compliance by an external model. Prompt guidance must be combined with host-side controls and human review for consequential actions.
