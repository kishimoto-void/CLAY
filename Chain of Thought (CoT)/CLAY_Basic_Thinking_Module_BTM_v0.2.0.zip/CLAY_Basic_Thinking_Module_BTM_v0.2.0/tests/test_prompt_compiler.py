import unittest
from btm.prompt_compiler import compile_prompt


class PromptCompilerTests(unittest.TestCase):
    def test_personality_and_baseline_are_separate(self):
        record = {
            "id": "I1", "topic": "tone", "content": "Use friendly Japanese", "source": "USER", "confirmed_by": "USER",
            "scope": {"type": "PERSISTENT", "ref": None}, "created_at": "2026-11-06T00:00:00Z",
            "status": "ACTIVE", "confirmation": "CONFIRMED", "conditions": {},
            "priority": "NORMAL", "supersedes": [], "conflicts_with": []
        }
        prompt, analysis = compile_prompt([record], {}, {"tone": "friendly", "traits": ["curious"]}, "test-model")
        self.assertIn("VERIFIED FIDELITY", prompt)
        self.assertIn("ACTIVE INSTRUCTIONS", prompt)
        self.assertIn("PERSONALITY / BEHAVIOR PROFILE", prompt)
        self.assertIn("REQUEST-ADAPTIVE EFFORT", prompt)
        self.assertIn("BOUNDED DIFFUSION", prompt)
        self.assertIn("MINIMUM UNMET-CONDITION RESOLUTION", prompt)
        self.assertIn("PURPOSE-PRESERVING RECOVERY", prompt)
        self.assertIn("BOUNDED OVERRUN", prompt)
        self.assertIn("TASK THINKING CONTROL", prompt)
        self.assertIn('"scope_policy": "BOUNDED"', prompt)
        self.assertIn("Target label: test-model", prompt)
        self.assertEqual(analysis["active"], ["I1"])

    def test_invalid_personality_profile_is_rejected(self):
        with self.assertRaises(ValueError):
            compile_prompt([], {}, {"initiative": ["too", "many"]})

    def test_invalid_thinking_control_is_rejected(self):
        with self.assertRaises(ValueError):
            compile_prompt([], {}, thinking_control={"requested_rigor": "MAXIMUM"})

    def test_rigor_does_not_imply_scope_expansion(self):
        prompt, _ = compile_prompt([], {}, thinking_control={
            "requested_rigor": "RIGOROUS", "scope_policy": "BOUNDED"
        })
        self.assertIn('"requested_rigor": "RIGOROUS"', prompt)
        self.assertIn('"scope_policy": "BOUNDED"', prompt)
        self.assertIn("Rigor changes depth, not scope.", prompt)


if __name__ == "__main__":
    unittest.main()
