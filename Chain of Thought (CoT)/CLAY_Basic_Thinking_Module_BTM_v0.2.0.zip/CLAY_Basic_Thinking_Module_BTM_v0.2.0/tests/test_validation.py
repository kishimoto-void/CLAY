import unittest
from btm.models import validate_instruction_set


def record(**overrides):
    value = {
        "id": "I-1", "topic": "style", "content": "Be concise", "source": "USER",
        "confirmed_by": "USER", "scope": {"type": "PERSISTENT", "ref": None},
        "created_at": "2026-11-06T00:00:00Z", "valid_from": None, "valid_until": None,
        "conditions": {}, "status": "ACTIVE", "confirmation": "CONFIRMED",
        "priority": "NORMAL", "supersedes": [], "conflicts_with": []
    }
    value.update(overrides)
    return value


class ValidationTests(unittest.TestCase):
    def test_valid_instruction(self):
        self.assertEqual(validate_instruction_set([record()]), [])

    def test_non_object_record_is_reported(self):
        self.assertTrue(any("must be an object" in e for e in validate_instruction_set([None])))

    def test_duplicate_id_fails(self):
        self.assertTrue(any("duplicate instruction id" in e for e in validate_instruction_set([record(), record(content="Detailed")])) )

    def test_temporary_requires_expiry(self):
        r = record(scope={"type": "TEMPORARY"})
        self.assertTrue(any("valid_until is required" in e for e in validate_instruction_set([r])))

    def test_scope_reference_required(self):
        r = record(scope={"type": "TASK"})
        self.assertTrue(any("scope.ref is required" in e for e in validate_instruction_set([r])))

    def test_self_supersession_rejected(self):
        r = record(supersedes=["I-1"])
        self.assertTrue(any("cannot reference itself in supersedes" in e for e in validate_instruction_set([r])))

    def test_confirmed_record_requires_actor(self):
        r = record(confirmed_by=None)
        self.assertTrue(any("confirmed_by" in e for e in validate_instruction_set([r])))


if __name__ == "__main__":
    unittest.main()
