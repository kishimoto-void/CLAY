import unittest
from btm.thinking_control import validate_thinking_control, normalize_thinking_control


class ThinkingControlTests(unittest.TestCase):
    def test_defaults_are_conservative(self):
        profile = normalize_thinking_control()
        self.assertEqual(profile["requested_rigor"], "STANDARD")
        self.assertEqual(profile["cognitive_direction"], "AUTO")
        self.assertEqual(profile["scope_policy"], "BOUNDED")
        self.assertEqual(profile["critical_outcomes"], [])

    def test_valid_explicit_profile(self):
        profile = {
            "requested_rigor": "RIGOROUS",
            "cognitive_direction": "CONVERGENCE",
            "scope_policy": "BOUNDED",
            "objective": "Check one function",
            "critical_outcomes": ["Identify root cause"],
            "hard_constraints": ["Do not change public API"],
            "flexible_constraints": ["Compare fixes"],
            "stop_condition": "Tests pass"
        }
        self.assertEqual(validate_thinking_control(profile), [])
        self.assertEqual(normalize_thinking_control(profile)["requested_rigor"], "RIGOROUS")

    def test_unknown_fields_rejected(self):
        self.assertTrue(any("unknown thinking_control field" in e for e in validate_thinking_control({"magic_override": True})))

    def test_invalid_enum_rejected(self):
        self.assertTrue(validate_thinking_control({"requested_rigor": "MAXIMUM"}))

    def test_unhashable_enum_value_is_reported_not_raised(self):
        self.assertTrue(validate_thinking_control({"requested_rigor": ["RIGOROUS"]}))

    def test_invalid_list_rejected(self):
        self.assertTrue(validate_thinking_control({"critical_outcomes": ["valid", 4]}))

    def test_normalizer_does_not_mutate_caller_lists(self):
        source = {"critical_outcomes": ["goal"]}
        normalized = normalize_thinking_control(source)
        normalized["critical_outcomes"].append("other")
        self.assertEqual(source["critical_outcomes"], ["goal"])


if __name__ == "__main__":
    unittest.main()
