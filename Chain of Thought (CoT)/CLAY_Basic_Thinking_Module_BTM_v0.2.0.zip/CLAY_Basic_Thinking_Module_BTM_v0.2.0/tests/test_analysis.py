import unittest
from datetime import datetime, timezone
from btm.analysis import analyze_instructions

NOW = datetime(2026, 11, 6, 12, 0, tzinfo=timezone.utc)
CTX = {"turn_id": "t1", "session_id": "s1", "task_id": "project-a", "mode": "work"}


def rec(id, content, **kw):
    r = {
        "id": id, "topic": "response_style", "content": content, "source": "USER", "confirmed_by": "USER",
        "scope": {"type": "PERSISTENT", "ref": None},
        "created_at": "2026-11-01T00:00:00Z", "valid_from": None, "valid_until": None,
        "conditions": {}, "status": "ACTIVE", "confirmation": "CONFIRMED",
        "priority": "NORMAL", "supersedes": [], "conflicts_with": []
    }
    r.update(kw)
    return r


class AnalysisTests(unittest.TestCase):
    def test_active_persistent_instruction(self):
        result = analyze_instructions([rec("I1", "Be concise")], CTX, NOW)
        self.assertEqual(result["active"], ["I1"])

    def test_unconfirmed_instruction_is_held(self):
        r = rec("I1", "Be concise", confirmation="UNCONFIRMED")
        result = analyze_instructions([r], CTX, NOW)
        self.assertEqual(result["active"], [])
        self.assertIn({"id": "I1", "reason": "confirmation:unconfirmed"}, result["held"])

    def test_expired_instruction_is_held(self):
        r = rec("I1", "Be concise", valid_until="2026-11-06T11:00:00Z")
        result = analyze_instructions([r], CTX, NOW)
        self.assertEqual(result["active"], [])
        self.assertIn({"id": "I1", "reason": "expired"}, result["held"])

    def test_task_scope_does_not_leak(self):
        r = rec("I1", "Review ICC rigorously", scope={"type": "TASK", "ref": "other-task"})
        result = analyze_instructions([r], CTX, NOW)
        self.assertEqual(result["active"], [])
        self.assertTrue(any(x["reason"].startswith("scope_mismatch") for x in result["held"]))

    def test_condition_is_exact_match(self):
        r = rec("I1", "Use rainy-day procedure", scope={"type": "CONDITIONAL"}, conditions={"weather": "rainy"})
        self.assertEqual(analyze_instructions([r], CTX, NOW)["active"], [])
        ctx = dict(CTX, weather="rainy")
        self.assertEqual(analyze_instructions([r], ctx, NOW)["active"], ["I1"])

    def test_conditions_also_apply_to_task_scope(self):
        r = rec("I1", "Use special review mode", scope={"type": "TASK", "ref": "project-a"}, conditions={"mode": "review"})
        self.assertEqual(analyze_instructions([r], CTX, NOW)["active"], [])
        ctx = dict(CTX, mode="review")
        self.assertEqual(analyze_instructions([r], ctx, NOW)["active"], ["I1"])

    def test_conflict_is_held_not_newest_wins(self):
        a = rec("I1", "Always be concise")
        b = rec("I2", "Always provide exhaustive detail", created_at="2026-11-06T11:00:00Z", priority="HIGH")
        result = analyze_instructions([a, b], CTX, NOW)
        self.assertEqual(result["active"], [])
        self.assertEqual(len(result["conflicts"]), 1)
        self.assertEqual(result["conflicts"][0]["resolution"], "HOLD_FOR_REVIEW")

    def test_explicit_active_supersession_replaces_old(self):
        old = rec("I1", "Always be concise")
        new = rec("I2", "Prefer detailed answers", supersedes=["I1"], created_at="2026-11-06T11:00:00Z")
        result = analyze_instructions([old, new], CTX, NOW)
        self.assertEqual(result["active"], ["I2"])
        self.assertIn({"id": "I1", "reason": "superseded_by_active_confirmed_record"}, result["held"])

    def test_unconfirmed_replacement_cannot_supersede(self):
        old = rec("I1", "Always be concise")
        new = rec("I2", "Prefer detailed answers", supersedes=["I1"], confirmation="UNCONFIRMED", confirmed_by=None)
        result = analyze_instructions([old, new], CTX, NOW)
        self.assertEqual(result["active"], ["I1"])
        self.assertEqual(result["supersessions"], [])

    def test_cross_topic_supersession_is_not_applied(self):
        old = rec("I1", "Always be concise", topic="response_style")
        new = rec("I2", "Do not use external websites", topic="web_policy", supersedes=["I1"])
        result = analyze_instructions([old, new], CTX, NOW)
        self.assertCountEqual(result["active"], ["I1", "I2"])
        self.assertEqual(result["supersessions"], [])
        self.assertEqual(result["supersession_issues"][0]["reason"], "topic_mismatch")

    def test_declared_conflict_works_across_topics(self):
        a = rec("I1", "Use external lookup", topic="tool_usage", conflicts_with=["I2"])
        b = rec("I2", "Never use external lookup", topic="web_preference")
        result = analyze_instructions([a, b], CTX, NOW)
        self.assertEqual(result["active"], [])
        self.assertTrue(result["conflicts"][0]["declared"])

    def test_supersession_cycle_is_rejected(self):
        a = rec("I1", "Concise answers", supersedes=["I2"])
        b = rec("I2", "Detailed answers", supersedes=["I1"])
        result = analyze_instructions([a, b], CTX, NOW)
        self.assertEqual(result["supersessions"], [])
        self.assertTrue(any(x["reason"] == "supersession_cycle" for x in result["supersession_issues"]))
        self.assertEqual(result["active"], [])  # The remaining same-topic contradiction is held.


if __name__ == "__main__":
    unittest.main()
