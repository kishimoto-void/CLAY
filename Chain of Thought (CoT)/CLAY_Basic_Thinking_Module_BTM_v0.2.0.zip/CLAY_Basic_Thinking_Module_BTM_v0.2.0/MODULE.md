# MODULE — CLAY Basic Thinking Module (BTM)

## Module identity
- **Module ID:** `clay.basic-thinking`
- **Version:** `0.2.0`
- **Type:** `thinking_support`
- **Status:** reference implementation / draft

## Responsibility

Provide a common, auditable instruction-handling baseline for CLAY modules. Validate instruction records, evaluate declared scope and validity, surface potential conflicts, validate optional task-level thinking-control metadata, and compile a portable prompt package that keeps baseline principles, task controls, and personality preferences separate.

## Non-responsibilities

BTM does not make domain decisions, prove truth, infer all natural-language intent, enforce model compliance, grant permissions, execute tools, or mutate provider-side memory.

## Inputs

- `instructions`: array conforming to `schemas/instruction.schema.json`
- `context`: object conforming to `schemas/context.schema.json`
- `personality`: optional object conforming to `schemas/personality.schema.json`
- `thinking_control`: optional object conforming to `schemas/thinking-control.schema.json`
- `target`: optional target label; metadata only in v0.2.0

## Outputs

- `analysis`: active IDs, held IDs with reasons, potential conflicts, supersession decisions, and issues
- `prompt`: Markdown prompt package for manual or host-controlled handoff to the target LLM

## Public Python API

```python
from btm.analysis import analyze_instructions
from btm.models import validate_instruction_set
from btm.prompt_compiler import compile_prompt
from btm.thinking_control import validate_thinking_control, normalize_thinking_control
```

## Execution and authority

This module performs local deterministic validation and text generation only. Request-adaptive semantic interpretation remains target-LLM guidance, not a deterministic classifier. It has no network access, tool permissions, external execution, or persistent storage. A host must verify source authority, persist audit events, and enforce all permissions.

## Safe default

If an important instruction is ambiguous or a potential conflict is detected, hold the affected instruction(s) and request authorized clarification rather than silently choosing one.
