# Changelog

## v0.2.0 — 2026-11-07
- Added task-adaptive effort, cognitive direction, and scope-control guidance.
- Added optional task-control metadata with structural validation, normalization, JSON Schema, example, and CLI support.
- Added prompt rules for bounded diffusion, targeted convergence, minimum unmet-condition resolution, purpose-preserving recovery, critical outcome preservation, and bounded overrun.
- Kept ICC-specific Problem Box and coordinate-system machinery outside the BTM baseline.
- Added regression tests for task-control validation and prompt compilation.
- Clarified that semantic intent classification and target-model compliance remain prompt-level behavior, not deterministic runtime enforcement.


## v0.1.0 — 2026-11-06
- Initial BTM design and Python reference implementation.
- Defined Verified Fidelity as the central instruction-handling principle.
- Separated stable thinking principles from variable personality settings.
- Added instruction lifecycle metadata, conservative conflict reporting, prompt compilation, schemas, examples, CLI, and tests.
- Documented the difference between prompt guidance and runtime enforcement.
