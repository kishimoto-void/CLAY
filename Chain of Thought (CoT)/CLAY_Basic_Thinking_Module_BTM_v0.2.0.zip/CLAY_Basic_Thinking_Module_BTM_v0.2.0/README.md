# CLAY Basic Thinking Module (BTM) v0.2.0

**Status:** reference implementation / design draft.  
**Purpose:** a shared baseline for how an LLM interprets instructions, checks context, handles conflicts, and reports execution status.

## Core principle — Verified Fidelity / 検証的忠実性

> 忠実な実行とは、指示を無条件に受け入れることではない。指示の内容、意図、適用条件、有効期間、既存指示との整合性を検証し、その正当な意味と適用範囲を保持して実行することである。

Doubt is used to improve fidelity, not to justify disobedience. Literal obedience and faithful execution are not the same.

## Architecture

1. **Basic Thinking Principles:** shared baseline rules (Verified Fidelity, Context Integrity, Temporal Validity, Conflict Visibility, Non-invention, Honest Reporting, Self-checking, Bounded Skepticism).
2. **Instruction Registry:** structured records for source, scope, dates, conditions, status, confirmation, and explicit supersession.
3. **Personality / Behavior Layer:** user-specific tone and behavior preferences, separate from the baseline.
4. **Task Thinking Control:** optional task-scoped rigor, cognitive direction, scope policy, and criteria. It is distinct from personality.
5. **Prompt Compiler:** compiles the baseline, active instructions, unresolved items, task-control metadata, and personality profile into a portable prompt for a target LLM.
6. **Host / Runtime:** responsible for loading, permissions, tool execution, safety enforcement, and output review. This is outside BTM.

## Quick start

Python 3.10+; standard library only.

```bash
PYTHONPATH=src python -m unittest discover -s tests -v
PYTHONPATH=src python -m btm validate examples/instructions.json
PYTHONPATH=src python -m btm analyze --instructions examples/instructions.json --context examples/context.json
PYTHONPATH=src python -m btm compile --instructions examples/instructions.json --context examples/context.json --personality examples/personality.json --thinking-control examples/thinking_control.json --output /tmp/btm_prompt.md
```

Run commands from this project directory, or set `PYTHONPATH=src` when invoking from elsewhere.

## v0.2.0 thinking-control additions

- Request-adaptive effort guidance (QUICK / STANDARD / RIGOROUS).
- Task-local cognitive direction (AUTO / CONVERGENCE / DIFFUSION).
- Scope policies (BOUNDED / CONSULT_BEFORE_EXPANSION / USER_EXPANSION_REQUESTED).
- Optional objective, critical outcomes, hard/flexible constraints, and stop condition metadata.
- Prompt guidance for minimum unmet-condition resolution, purpose-preserving recovery, and bounded overrun.
- A documented boundary keeping specialist ICC mechanisms outside the BTM baseline.
- Behavioral conformance cases for later testing against actual target LLM versions.

## What is implemented

- Instruction record validation and deterministic analysis.
- `TURN`, `SESSION`, `TASK`, `TEMPORARY`, `PERSISTENT`, and `CONDITIONAL` scopes.
- Effective-time checks, simple exact-match conditions, explicit supersession, and potential-conflict detection.
- A conservative conflict policy: newness or priority does not silently decide a conflict.
- Prompt compilation with separate baseline, instructions, unresolved items, task thinking-control metadata, and personality sections.
- Structural validation and CLI ingestion of an optional task thinking-control profile.
- JSON Schemas, examples, command-line interface, and unit tests.

## New limitations for thinking control

- Natural-language intent classification is performed by the target LLM using compiled guidance; the Python code does not infer it.
- Task-control metadata is advisory input. It does not prove that the target LLM actually used the selected effort or scope.
- The code does not implement ICC's Problem Box, formal coordinate axes, evidence graph, or autonomous recovery engine.

## Critical limitations

BTM can validate structured records and generate prompts. It **cannot force an external LLM to comply**, inspect hidden model state, reliably interpret every natural-language contradiction, enforce tool permissions, or prove an instruction is correct. The generated prompt is advisory input, not an enforcement boundary. Use host-side authorization, deterministic validators, external evidence, and human review for consequential actions.
