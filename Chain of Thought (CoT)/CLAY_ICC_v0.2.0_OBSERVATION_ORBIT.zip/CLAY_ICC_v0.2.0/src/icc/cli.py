from __future__ import annotations
import argparse
import json
from pathlib import Path
from .validation import validate_problem_box, validate_axis_set, validate_bundle
from .analysis import analyze_bundle
from .prompt_compiler import compile_prompt
from .policy import validate_btm_control


MAX_JSON_INPUT_BYTES = 5_000_000


def _load(path: str):
    p = Path(path)
    if p.stat().st_size > MAX_JSON_INPUT_BYTES:
        raise ValueError(f"input file exceeds {MAX_JSON_INPUT_BYTES} byte safety limit")
    with p.open("r", encoding="utf-8") as f:
        return json.load(f)


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(prog="icc", description="CLAY ICC structural reference tools")
    sub = parser.add_subparsers(dest="command", required=True)
    for name in ("validate-problem", "validate-axes", "validate-bundle", "analyze"):
        p = sub.add_parser(name)
        p.add_argument("--input", required=True)
    c = sub.add_parser("compile")
    c.add_argument("--input", required=True, help="ICC JSON bundle")
    c.add_argument("--btm-control", help="optional BTM v0.2.0 thinking-control JSON")
    c.add_argument("--target", default="generic")
    c.add_argument("--language", choices=["ja", "en"], default="ja")
    c.add_argument("--output", required=True)
    args = parser.parse_args(argv)
    data = _load(args.input)
    if args.command == "validate-problem":
        errors = validate_problem_box(data)
    elif args.command == "validate-axes":
        errors = validate_axis_set(data)
    elif args.command == "validate-bundle":
        errors = validate_bundle(data)
    elif args.command == "analyze":
        result = analyze_bundle(data)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0 if not any(x["severity"] == "ERROR" for x in result["issues"]) else 2
    else:
        control = _load(args.btm_control) if args.btm_control else None
        control_errors = validate_btm_control(control)
        if control_errors:
            print(json.dumps({"errors": control_errors}, ensure_ascii=False, indent=2))
            return 2
        prompt = compile_prompt(data, control, args.target, args.language)
        Path(args.output).write_text(prompt, encoding="utf-8")
        print(f"Prompt written: {args.output}")
        return 0
    print(json.dumps({"valid": not errors, "errors": errors}, ensure_ascii=False, indent=2))
    return 0 if not errors else 2


if __name__ == "__main__":
    raise SystemExit(main())
