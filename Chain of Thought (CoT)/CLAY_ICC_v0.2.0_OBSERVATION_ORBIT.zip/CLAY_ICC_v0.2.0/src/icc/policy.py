"""Translate BTM v0.2.0 task controls into bounded ICC process guidance."""
from __future__ import annotations
from typing import Any

RIGOR = {"QUICK", "STANDARD", "RIGOROUS"}
DIRECTION = {"AUTO", "CONVERGENCE", "DIFFUSION"}
SCOPE = {"BOUNDED", "CONSULT_BEFORE_EXPANSION", "USER_EXPANSION_REQUESTED"}


def validate_btm_control(control: Any) -> list[str]:
    if control is None:
        return []
    if not isinstance(control, dict):
        return ["btm_thinking_control: expected object"]
    errors = []
    allowed = {"requested_rigor", "cognitive_direction", "scope_policy", "objective", "critical_outcomes", "hard_constraints", "flexible_constraints", "stop_condition"}
    for key in control:
        if key not in allowed:
            errors.append(f"btm_thinking_control: unknown field {key}")
    if "requested_rigor" in control and (not isinstance(control["requested_rigor"], str) or control["requested_rigor"] not in RIGOR):
        errors.append("btm_thinking_control.requested_rigor: invalid BTM v0.2.0 value")
    if "cognitive_direction" in control and (not isinstance(control["cognitive_direction"], str) or control["cognitive_direction"] not in DIRECTION):
        errors.append("btm_thinking_control.cognitive_direction: invalid BTM v0.2.0 value")
    if "scope_policy" in control and (not isinstance(control["scope_policy"], str) or control["scope_policy"] not in SCOPE):
        errors.append("btm_thinking_control.scope_policy: invalid BTM v0.2.0 value")
    for field in ("objective", "stop_condition"):
        if field in control and control[field] is not None and (not isinstance(control[field], str) or not control[field].strip()):
            errors.append(f"btm_thinking_control.{field}: expected non-empty string or null")
    for field in ("critical_outcomes", "hard_constraints", "flexible_constraints"):
        if field in control and (not isinstance(control[field], list) or any(not isinstance(x, str) or not x.strip() for x in control[field])):
            errors.append(f"btm_thinking_control.{field}: expected array of non-empty strings")
    return errors

def derive_process_guidance(control: dict | None) -> dict:
    """Deterministic mapping only; it does not classify user language or authorize scope."""
    raw = control or {}
    errors = validate_btm_control(raw)
    if errors:
        return {"valid": False, "errors": errors, "can_proceed_outside_current_box": False}
    c = {
        "requested_rigor": "STANDARD", "cognitive_direction": "AUTO", "scope_policy": "BOUNDED",
        "objective": None, "critical_outcomes": [], "hard_constraints": [],
        "flexible_constraints": [], "stop_condition": None
    }
    for key, value in raw.items():
        c[key] = list(value) if isinstance(value, list) else value
    rigor = c.get("requested_rigor", "STANDARD")
    direction = c.get("cognitive_direction", "AUTO")
    scope_policy = c.get("scope_policy", "BOUNDED")
    if direction == "DIFFUSION":
        direction_guidance = "REQUESTED_DIFFUSION"
    elif direction == "CONVERGENCE":
        direction_guidance = "FOCUSED_CONVERGENCE"
    else:
        direction_guidance = "SEMANTICALLY_ADAPTIVE_WITH_BOUNDED_DEFAULT"
    if scope_policy == "BOUNDED":
        scope_guidance = "NO_SCOPE_EXPANSION"
    elif scope_policy == "CONSULT_BEFORE_EXPANSION":
        scope_guidance = "PROPOSE_EXPANSION_AND_WAIT_FOR_APPROVAL"
    else:
        scope_guidance = "USER_REQUESTED_BOX_REVISION_REQUIRED_BEFORE_OUT_OF_BOX_WORK"
    return {
        "valid": True,
        "normalized_control": c,
        "requested_rigor": rigor,
        "direction_guidance": direction_guidance,
        "scope_guidance": scope_guidance,
        "can_proceed_outside_current_box": False,
        "user_requested_expansion": scope_policy == "USER_EXPANSION_REQUESTED",
        "note": "RIGOROUS changes verification depth, not scope. Even an explicit expansion request requires a revised, human-approved Problem Box and Host authorization. A BTM scope policy is not a permission grant."
    }
