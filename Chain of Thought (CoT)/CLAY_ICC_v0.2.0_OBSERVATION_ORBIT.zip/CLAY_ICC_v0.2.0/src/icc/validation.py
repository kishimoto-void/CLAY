"""Structural validators for ICC records. No semantic truth claims are made here."""
from __future__ import annotations

from datetime import datetime
from typing import Any
import re

ID_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._:-]{1,63}$")
BOX_STATUSES = {"DRAFT", "PROPOSED", "APPROVED", "REVISION_REQUIRED"}
APPROVAL_STATUSES = {"PENDING", "HUMAN_APPROVED"}
AXIS_SET_STATUSES = {"PROPOSED", "LOCKED", "REVISION_REQUIRED"}
AXIS_KINDS = {"CRITICAL", "CONDITIONAL", "FLEXIBLE", "EXPLORATORY"}
PRIORITIES = {"P0", "P1", "P2", "P3"}
NEGOTIABILITY = {"LOCKED", "HUMAN_REAPPROVAL", "FLEXIBLE"}
MAX_GENERIC_ITEMS = 10000
MAX_AXES = 256
MAX_EVIDENCE = 5000
MAX_SCOPE_ITEMS = 512
MAX_CONSTRAINTS = 1024
MAX_CRITERIA = 1024
MAX_ASSESSMENTS = 2048
EVIDENCE_RELATIONS = {"SUPPORT", "CONTRADICT", "PARTIAL", "UNKNOWN"}
EVIDENCE_VERIFICATION = {"VERIFIED", "UNVERIFIED", "PARTIAL", "REJECTED"}
ASSESSMENT_STATUSES = {"PASS", "FAIL", "NOT_EXECUTED", "INCONCLUSIVE", "PARTIAL"}
CONSTRAINT_TYPES = {"HARD", "SOFT"}


def _obj(value: Any, label: str, errors: list[str]) -> dict:
    if not isinstance(value, dict):
        errors.append(f"{label}: expected object")
        return {}
    return value


def _str(value: Any, label: str, errors: list[str], *, optional: bool = False) -> None:
    if optional and value is None:
        return
    if not isinstance(value, str) or not value.strip():
        errors.append(f"{label}: expected non-empty string")


def _id(value: Any, label: str, errors: list[str]) -> None:
    if not isinstance(value, str) or not ID_RE.fullmatch(value):
        errors.append(f"{label}: invalid identifier (2-64 safe characters required)")


def _list(value: Any, label: str, errors: list[str], *, nonempty: bool = False,
          max_items: int = MAX_GENERIC_ITEMS) -> list:
    if not isinstance(value, list):
        errors.append(f"{label}: expected array")
        return []
    if nonempty and not value:
        errors.append(f"{label}: must not be empty")
    if len(value) > max_items:
        errors.append(f"{label}: item limit exceeded ({len(value)} > {max_items})")
        return value[:max_items]
    return value


def _enum(value: Any, allowed: set[str], label: str, errors: list[str]) -> None:
    if not isinstance(value, str) or value not in allowed:
        errors.append(f"{label}: expected one of {', '.join(sorted(allowed))}")


def _unique_ids(items: list, key: str, label: str, errors: list[str]) -> None:
    seen: set[str] = set()
    for i, item in enumerate(items):
        if not isinstance(item, dict):
            errors.append(f"{label}[{i}]: expected object")
            continue
        value = item.get(key)
        if isinstance(value, str):
            if value in seen:
                errors.append(f"{label}: duplicate {key} '{value}'")
            seen.add(value)


def _validate_approval(value: Any, label: str, errors: list[str], *, required: bool) -> None:
    approval = _obj(value, label, errors)
    _enum(approval.get("status"), APPROVAL_STATUSES, f"{label}.status", errors)
    if approval.get("status") == "HUMAN_APPROVED":
        _str(approval.get("approved_by"), f"{label}.approved_by", errors)
        timestamp = approval.get("approved_at")
        _str(timestamp, f"{label}.approved_at", errors)
        if isinstance(timestamp, str):
            try:
                datetime.fromisoformat(timestamp.replace("Z", "+00:00"))
            except ValueError:
                errors.append(f"{label}.approved_at: invalid ISO-8601 timestamp")
    elif required:
        errors.append(f"{label}: human approval is required for this status")


def validate_problem_box(box: Any) -> list[str]:
    errors: list[str] = []
    b = _obj(box, "problem_box", errors)
    if b.get("schema_version") != "icc.problem-box/0.1":
        errors.append("problem_box.schema_version: expected icc.problem-box/0.1")
    _id(b.get("problem_id"), "problem_box.problem_id", errors)
    _str(b.get("version"), "problem_box.version", errors)
    _enum(b.get("status"), BOX_STATUSES, "problem_box.status", errors)
    for key in ("domain", "purpose", "target"):
        _str(b.get(key), f"problem_box.{key}", errors)
    scope = _obj(b.get("scope"), "problem_box.scope", errors)
    scope_values = {}
    for key in ("in_scope", "out_of_scope"):
        vals = _list(scope.get(key), f"problem_box.scope.{key}", errors, nonempty=(key == "in_scope"), max_items=MAX_SCOPE_ITEMS)
        scope_values[key] = {v for v in vals if isinstance(v, str)}
        for i, val in enumerate(vals):
            _str(val, f"problem_box.scope.{key}[{i}]", errors)
    overlap = scope_values.get("in_scope", set()) & scope_values.get("out_of_scope", set())
    if overlap:
        errors.append("problem_box.scope: items cannot be both in_scope and out_of_scope: " + ", ".join(sorted(overlap)))
    constraints = _list(b.get("constraints"), "problem_box.constraints", errors, max_items=MAX_CONSTRAINTS)
    _unique_ids(constraints, "constraint_id", "problem_box.constraints", errors)
    for i, item in enumerate(constraints):
        if not isinstance(item, dict):
            continue
        _id(item.get("constraint_id"), f"constraints[{i}].constraint_id", errors)
        _enum(item.get("type"), CONSTRAINT_TYPES, f"constraints[{i}].type", errors)
        _str(item.get("description"), f"constraints[{i}].description", errors)
        _enum(item.get("negotiability"), NEGOTIABILITY, f"constraints[{i}].negotiability", errors)
        if item.get("type") == "HARD" and item.get("negotiability") == "FLEXIBLE":
            errors.append(f"constraints[{i}]: HARD constraints cannot be FLEXIBLE")
    criteria = _list(b.get("success_criteria"), "problem_box.success_criteria", errors, nonempty=True, max_items=MAX_CRITERIA)
    _unique_ids(criteria, "criterion_id", "problem_box.success_criteria", errors)
    for i, item in enumerate(criteria):
        if not isinstance(item, dict):
            continue
        _id(item.get("criterion_id"), f"success_criteria[{i}].criterion_id", errors)
        _str(item.get("description"), f"success_criteria[{i}].description", errors)
        _str(item.get("verification_method"), f"success_criteria[{i}].verification_method", errors)
        if not isinstance(item.get("critical"), bool):
            errors.append(f"success_criteria[{i}].critical: expected boolean")
    for key in ("failure_conditions", "assumptions"):
        vals = _list(b.get(key), f"problem_box.{key}", errors, max_items=MAX_CRITERIA)
        if key == "assumptions":
            _unique_ids(vals, "assumption_id", "problem_box.assumptions", errors)
        for i, item in enumerate(vals):
            if key == "failure_conditions":
                _str(item, f"failure_conditions[{i}]", errors)
            elif isinstance(item, dict):
                _id(item.get("assumption_id"), f"assumptions[{i}].assumption_id", errors)
                _str(item.get("statement"), f"assumptions[{i}].statement", errors)
                _enum(item.get("status"), {"ASSUMED", "VERIFIED", "REJECTED"}, f"assumptions[{i}].status", errors)
            else:
                errors.append(f"assumptions[{i}]: expected object")
    approval = b.get("approval")
    _validate_approval(approval, "problem_box.approval", errors, required=b.get("status") == "APPROVED")
    if b.get("status") == "APPROVED" and isinstance(approval, dict) and approval.get("status") != "HUMAN_APPROVED":
        errors.append("problem_box: APPROVED status requires HUMAN_APPROVED metadata")
    return errors


def validate_axis_set(axis_set: Any, problem_box: Any | None = None) -> list[str]:
    errors: list[str] = []
    a = _obj(axis_set, "axis_set", errors)
    if a.get("schema_version") != "icc.axis-set/0.1":
        errors.append("axis_set.schema_version: expected icc.axis-set/0.1")
    _id(a.get("problem_id"), "axis_set.problem_id", errors)
    _str(a.get("problem_box_version"), "axis_set.problem_box_version", errors)
    _str(a.get("version"), "axis_set.version", errors)
    _enum(a.get("status"), AXIS_SET_STATUSES, "axis_set.status", errors)
    axes = _list(a.get("axes"), "axis_set.axes", errors, nonempty=True, max_items=MAX_AXES)
    _unique_ids(axes, "axis_id", "axis_set.axes", errors)
    for i, axis in enumerate(axes):
        if not isinstance(axis, dict):
            continue
        _id(axis.get("axis_id"), f"axes[{i}].axis_id", errors)
        for key in ("name", "definition", "objective_link", "measurement_method", "pass_condition"):
            _str(axis.get(key), f"axes[{i}].{key}", errors)
        _enum(axis.get("kind"), AXIS_KINDS, f"axes[{i}].kind", errors)
        _enum(axis.get("priority"), PRIORITIES, f"axes[{i}].priority", errors)
        _enum(axis.get("negotiability"), NEGOTIABILITY, f"axes[{i}].negotiability", errors)
        if axis.get("kind") == "CRITICAL" and axis.get("negotiability") == "FLEXIBLE":
            errors.append(f"axes[{i}]: CRITICAL axis cannot be FLEXIBLE")
        if axis.get("parent_axis_id") is not None:
            _id(axis.get("parent_axis_id"), f"axes[{i}].parent_axis_id", errors)
        if "dependencies" in axis:
            deps = _list(axis.get("dependencies"), f"axes[{i}].dependencies", errors, max_items=MAX_AXES)
            for j, dep in enumerate(deps):
                _id(dep, f"axes[{i}].dependencies[{j}]", errors)
    axis_map = {ax.get("axis_id"): ax for ax in axes if isinstance(ax, dict) and isinstance(ax.get("axis_id"), str)}
    adjacency: dict[str, list[str]] = {}
    for axis_id, axis in axis_map.items():
        deps = axis.get("dependencies", []) if isinstance(axis.get("dependencies", []), list) else []
        adjacency[axis_id] = []
        for dep in deps:
            if dep == axis_id:
                errors.append(f"axes[{axis_id}]: self-dependency is not allowed")
            elif dep not in axis_map:
                errors.append(f"axes[{axis_id}].dependencies: unknown axis '{dep}'")
            else:
                adjacency[axis_id].append(dep)
        parent_id = axis.get("parent_axis_id")
        if parent_id is not None and parent_id not in axis_map:
            errors.append(f"axes[{axis_id}].parent_axis_id: parent axis must exist in this axis-set snapshot")
    visiting: set[str] = set()
    visited: set[str] = set()
    def visit(node: str) -> None:
        if node in visiting:
            errors.append(f"axis_set: dependency cycle detected at '{node}'")
            return
        if node in visited:
            return
        visiting.add(node)
        for child in adjacency.get(node, []):
            visit(child)
        visiting.remove(node)
        visited.add(node)
    for node in adjacency:
        visit(node)
    approval = a.get("approval")
    _validate_approval(approval, "axis_set.approval", errors, required=a.get("status") == "LOCKED")
    if a.get("status") == "LOCKED" and isinstance(approval, dict) and approval.get("status") != "HUMAN_APPROVED":
        errors.append("axis_set: LOCKED status requires HUMAN_APPROVED metadata")
    if isinstance(problem_box, dict):
        if a.get("problem_id") != problem_box.get("problem_id"):
            errors.append("axis_set.problem_id: does not match Problem Box")
        if a.get("problem_box_version") != problem_box.get("version"):
            errors.append("axis_set.problem_box_version: stale or mismatched Problem Box version")
        if problem_box.get("status") != "APPROVED" and a.get("status") == "LOCKED":
            errors.append("axis_set: cannot lock axes before Problem Box approval")
    return errors


def validate_evidence_records(records: Any) -> list[str]:
    errors: list[str] = []
    items = _list(records, "evidence_records", errors, max_items=MAX_EVIDENCE)
    _unique_ids(items, "evidence_id", "evidence_records", errors)
    for i, item in enumerate(items):
        if not isinstance(item, dict):
            continue
        _id(item.get("evidence_id"), f"evidence[{i}].evidence_id", errors)
        for key in ("claim", "source", "provenance", "independence_group_id", "scope", "uncertainty"):
            _str(item.get(key), f"evidence[{i}].{key}", errors)
        _str(item.get("axis_id"), f"evidence[{i}].axis_id", errors)
        _enum(item.get("relation"), EVIDENCE_RELATIONS, f"evidence[{i}].relation", errors)
        _enum(item.get("verification_status"), EVIDENCE_VERIFICATION, f"evidence[{i}].verification_status", errors)
    return errors


def validate_assessments(assessments: Any) -> list[str]:
    errors: list[str] = []
    a = _obj(assessments, "assessments", errors)
    for group_name, id_key in (("axis_results", "axis_id"), ("constraint_results", "constraint_id")):
        rows = _list(a.get(group_name), f"assessments.{group_name}", errors, max_items=MAX_ASSESSMENTS)
        _unique_ids(rows, id_key, f"assessments.{group_name}", errors)
        for i, row in enumerate(rows):
            if not isinstance(row, dict):
                continue
            _id(row.get(id_key), f"{group_name}[{i}].{id_key}", errors)
            _enum(row.get("status"), ASSESSMENT_STATUSES, f"{group_name}[{i}].status", errors)
            ev = _list(row.get("evidence_ids"), f"{group_name}[{i}].evidence_ids", errors)
            for j, evidence_id in enumerate(ev):
                _id(evidence_id, f"{group_name}[{i}].evidence_ids[{j}]", errors)
            if "summary" in row:
                _str(row.get("summary"), f"{group_name}[{i}].summary", errors)
    return errors



def validate_satellite_map(satellite_map: Any, problem_box: Any, axis_set: Any, evidence_records: Any) -> list[str]:
    """Validate satellite-map structure/references; never infer causality or intent."""
    errors: list[str] = []
    m = _obj(satellite_map, "satellite_map", errors)
    if m.get("schema_version") != "icc.satellite-map/0.1":
        errors.append("satellite_map.schema_version: expected icc.satellite-map/0.1")
    _id(m.get("map_id"), "satellite_map.map_id", errors)
    _id(m.get("problem_id"), "satellite_map.problem_id", errors)
    _str(m.get("problem_box_version"), "satellite_map.problem_box_version", errors)
    _enum(m.get("status"), {"DRAFT", "ACTIVE", "ARCHIVED"}, "satellite_map.status", errors)
    _str(m.get("coverage_scope"), "satellite_map.coverage_scope", errors)
    if isinstance(problem_box, dict):
        if m.get("problem_id") != problem_box.get("problem_id"):
            errors.append("satellite_map.problem_id: does not match Problem Box")
        if m.get("problem_box_version") != problem_box.get("version"):
            errors.append("satellite_map.problem_box_version: does not match Problem Box version")

    coverage = _list(m.get("coverage"), "satellite_map.coverage", errors, max_items=64)
    _unique_ids(coverage, "sector_id", "satellite_map.coverage", errors)
    for i, row in enumerate(coverage):
        if not isinstance(row, dict):
            errors.append(f"satellite_map.coverage[{i}]: expected object")
            continue
        _id(row.get("sector_id"), f"satellite_map.coverage[{i}].sector_id", errors)
        _str(row.get("sector_name"), f"satellite_map.coverage[{i}].sector_name", errors)
        _enum(row.get("status"), {"SCANNED", "PARTIAL", "NOT_SCANNED", "NOT_APPLICABLE"}, f"satellite_map.coverage[{i}].status", errors)

    satellites = _list(m.get("satellites"), "satellite_map.satellites", errors, max_items=1024)
    subproblems = _list(m.get("subproblems"), "satellite_map.subproblems", errors, max_items=256)
    relations = _list(m.get("relations"), "satellite_map.relations", errors, max_items=4096)
    _unique_ids(satellites, "satellite_id", "satellite_map.satellites", errors)
    _unique_ids(subproblems, "subproblem_id", "satellite_map.subproblems", errors)
    _unique_ids(relations, "relation_id", "satellite_map.relations", errors)
    satellite_ids = {x.get("satellite_id") for x in satellites if isinstance(x, dict)}
    subproblem_ids = {x.get("subproblem_id") for x in subproblems if isinstance(x, dict)}
    axis_ids = {x.get("axis_id") for x in (axis_set.get("axes", []) if isinstance(axis_set, dict) else []) if isinstance(x, dict)}
    evidence_ids = {x.get("evidence_id") for x in (evidence_records if isinstance(evidence_records, list) else []) if isinstance(x, dict)}

    categories = {"STAKEHOLDER", "GOAL", "INCENTIVE", "RESOURCE", "STRUCTURE", "INSTITUTION", "EVENT", "TIMELINE", "INFORMATION", "TECHNOLOGY", "ENVIRONMENT", "FEEDBACK", "EXTERNAL_FORCE", "OTHER"}
    observation_states = {"OBSERVED", "REPORTED", "INFERRED", "HYPOTHESIS", "UNKNOWN"}
    materialities = {"HIGH", "MEDIUM", "LOW", "UNASSESSED"}
    for i, sat in enumerate(satellites):
        if not isinstance(sat, dict):
            errors.append(f"satellites[{i}]: expected object")
            continue
        _id(sat.get("satellite_id"), f"satellites[{i}].satellite_id", errors)
        _str(sat.get("label"), f"satellites[{i}].label", errors)
        _enum(sat.get("category"), categories, f"satellites[{i}].category", errors)
        _str(sat.get("description"), f"satellites[{i}].description", errors)
        _enum(sat.get("observation_state"), observation_states, f"satellites[{i}].observation_state", errors)
        _enum(sat.get("materiality"), materialities, f"satellites[{i}].materiality", errors)
        for field, valid in (("evidence_ids", evidence_ids), ("axis_ids", axis_ids), ("subproblem_ids", subproblem_ids)):
            values = _list(sat.get(field), f"satellites[{i}].{field}", errors, max_items=256)
            for j, value in enumerate(values):
                if not isinstance(value, str) or value not in valid:
                    errors.append(f"satellites[{i}].{field}[{j}]: unknown {field[:-4].rstrip(' _')} reference")
        motive = sat.get("motive_profile")
        if motive is not None:
            motive_obj = _obj(motive, f"satellites[{i}].motive_profile", errors)
            for field in ("stated_goals", "observed_actions", "observed_outcomes", "plausible_incentives"):
                values = _list(motive_obj.get(field), f"satellites[{i}].motive_profile.{field}", errors, max_items=128)
                for j, value in enumerate(values):
                    _str(value, f"satellites[{i}].motive_profile.{field}[{j}]", errors)
            _enum(motive_obj.get("assessment_status"), {"UNASSESSED", "DECLARATION_ONLY", "ACTION_ALIGNMENT", "OUTCOME_ALIGNMENT", "MIXED", "CONTRADICTED", "UNKNOWN"}, f"satellites[{i}].motive_profile.assessment_status", errors)
            _str(motive_obj.get("caveat"), f"satellites[{i}].motive_profile.caveat", errors)

    subproblem_relationships = {"DIRECT_SUBQUESTION", "CAUSAL_DEPENDENCY", "CONTEXT_ONLY", "COMPETING_OBJECTIVE", "INDEPENDENT_BUT_RELEVANT"}
    merge_policies = {"KEEP_SEPARATE", "LINK_ONLY", "MERGE_AFTER_HUMAN_REVIEW"}
    for i, sub in enumerate(subproblems):
        if not isinstance(sub, dict):
            errors.append(f"subproblems[{i}]: expected object")
            continue
        _id(sub.get("subproblem_id"), f"subproblems[{i}].subproblem_id", errors)
        for field in ("label", "question", "boundary"):
            _str(sub.get(field), f"subproblems[{i}].{field}", errors)
        _enum(sub.get("relationship_to_core"), subproblem_relationships, f"subproblems[{i}].relationship_to_core", errors)
        _enum(sub.get("merge_policy"), merge_policies, f"subproblems[{i}].merge_policy", errors)
        for field, valid in (("linked_satellite_ids", satellite_ids), ("linked_axis_ids", axis_ids), ("depends_on", subproblem_ids)):
            values = _list(sub.get(field), f"subproblems[{i}].{field}", errors, max_items=256)
            for j, value in enumerate(values):
                if not isinstance(value, str) or value not in valid:
                    errors.append(f"subproblems[{i}].{field}[{j}]: unknown reference")
        if sub.get("subproblem_id") in sub.get("depends_on", []):
            errors.append(f"subproblems[{i}].depends_on: self-dependency is not allowed")

    # Subproblem dependencies must form a DAG; feedback loops belong in typed relations instead.
    sub_adj = {row.get("subproblem_id"): [x for x in row.get("depends_on", []) if isinstance(x, str) and x in subproblem_ids]
               for row in subproblems if isinstance(row, dict) and isinstance(row.get("subproblem_id"), str)}
    visiting_sub: set[str] = set()
    visited_sub: set[str] = set()
    def visit_sub(node: str) -> None:
        if node in visiting_sub:
            errors.append(f"satellite_map.subproblems: dependency cycle detected at '{node}'")
            return
        if node in visited_sub:
            return
        visiting_sub.add(node)
        for dep in sub_adj.get(node, []):
            visit_sub(dep)
        visiting_sub.remove(node)
        visited_sub.add(node)
    for node in sub_adj:
        visit_sub(node)

    relation_types = {"CAUSES", "ENABLES", "CONSTRAINS", "MEDIATES", "MODERATES", "CORRELATES_WITH", "INDICATES", "REACTS_TO", "COMPETES_WITH", "FEEDBACK_TO", "SHARES_DEPENDENCY_WITH"}
    relation_statuses = {"HYPOTHESIS", "UNDER_TEST", "SUPPORTED", "CONTRADICTED", "UNRESOLVED"}
    target_types = {"CORE_PROBLEM", "SATELLITE", "SUBPROBLEM", "AXIS"}
    targets = {"CORE_PROBLEM": {problem_box.get("problem_id")} if isinstance(problem_box, dict) else set(),
               "SATELLITE": satellite_ids, "SUBPROBLEM": subproblem_ids, "AXIS": axis_ids}
    for i, rel in enumerate(relations):
        if not isinstance(rel, dict):
            errors.append(f"relations[{i}]: expected object")
            continue
        _id(rel.get("relation_id"), f"relations[{i}].relation_id", errors)
        if not isinstance(rel.get("from_satellite_id"), str) or rel.get("from_satellite_id") not in satellite_ids:
            errors.append(f"relations[{i}].from_satellite_id: unknown satellite reference")
        _enum(rel.get("to_type"), target_types, f"relations[{i}].to_type", errors)
        _id(rel.get("to_id"), f"relations[{i}].to_id", errors)
        if isinstance(rel.get("to_type"), str) and rel.get("to_type") in targets:
            if not isinstance(rel.get("to_id"), str) or rel.get("to_id") not in targets[rel.get("to_type")]:
                errors.append(f"relations[{i}].to_id: unknown {str(rel.get('to_type')).lower()} reference")
        _enum(rel.get("relation_type"), relation_types, f"relations[{i}].relation_type", errors)
        _str(rel.get("mechanism"), f"relations[{i}].mechanism", errors)
        _enum(rel.get("hypothesis_status"), relation_statuses, f"relations[{i}].hypothesis_status", errors)
        _str(rel.get("time_scope"), f"relations[{i}].time_scope", errors)
        refs = _list(rel.get("evidence_ids"), f"relations[{i}].evidence_ids", errors, max_items=256)
        for j, eid in enumerate(refs):
            if not isinstance(eid, str) or eid not in evidence_ids:
                errors.append(f"relations[{i}].evidence_ids[{j}]: unknown evidence reference")
        if rel.get("hypothesis_status") == "SUPPORTED":
            verified_support = any(
                rec.get("evidence_id") in refs and rec.get("relation") == "SUPPORT" and rec.get("verification_status") == "VERIFIED"
                for rec in (evidence_records if isinstance(evidence_records, list) else []) if isinstance(rec, dict)
            )
            if not verified_support:
                errors.append(f"relations[{i}]: SUPPORTED relation requires linked VERIFIED SUPPORT evidence")
        for field in ("alternative_explanations", "disconfirmers"):
            values = _list(rel.get(field), f"relations[{i}].{field}", errors, max_items=64)
            for j, value in enumerate(values):
                _str(value, f"relations[{i}].{field}[{j}]", errors)
    for field in ("blind_spots", "separation_notes"):
        if field in m:
            values = _list(m.get(field), f"satellite_map.{field}", errors, max_items=256)
            for i, value in enumerate(values):
                _str(value, f"satellite_map.{field}[{i}]", errors)
    return errors

def validate_bundle(bundle: Any) -> list[str]:
    errors: list[str] = []
    b = _obj(bundle, "bundle", errors)
    errors.extend(validate_problem_box(b.get("problem_box")))
    errors.extend(validate_axis_set(b.get("axis_set"), b.get("problem_box")))
    errors.extend(validate_evidence_records(b.get("evidence_records", [])))
    errors.extend(validate_assessments(b.get("assessments", {})))
    if "satellite_map" in b:
        errors.extend(validate_satellite_map(b.get("satellite_map"), b.get("problem_box"), b.get("axis_set"), b.get("evidence_records", [])))

    # Cross-reference checks are separate from per-record shape checks.
    box = b.get("problem_box") if isinstance(b.get("problem_box"), dict) else {}
    axis_set = b.get("axis_set") if isinstance(b.get("axis_set"), dict) else {}
    axis_ids = {a.get("axis_id") for a in axis_set.get("axes", []) if isinstance(a, dict)}
    constraint_ids = {c.get("constraint_id") for c in box.get("constraints", []) if isinstance(c, dict)}
    evidence = b.get("evidence_records", [])
    evidence_ids = {e.get("evidence_id") for e in evidence if isinstance(e, dict)}
    for i, rec in enumerate(evidence if isinstance(evidence, list) else []):
        if isinstance(rec, dict) and rec.get("axis_id") not in axis_ids:
            errors.append(f"evidence_records[{i}].axis_id: unknown axis reference")
    assessments = b.get("assessments") if isinstance(b.get("assessments"), dict) else {}
    for group_name, id_key, valid_ids in (("axis_results", "axis_id", axis_ids), ("constraint_results", "constraint_id", constraint_ids)):
        rows = assessments.get(group_name, [])
        for i, row in enumerate(rows if isinstance(rows, list) else []):
            if not isinstance(row, dict):
                continue
            if row.get(id_key) not in valid_ids:
                errors.append(f"assessments.{group_name}[{i}].{id_key}: unknown reference")
            for j, evidence_id in enumerate(row.get("evidence_ids", []) if isinstance(row.get("evidence_ids", []), list) else []):
                if evidence_id not in evidence_ids:
                    errors.append(f"assessments.{group_name}[{i}].evidence_ids[{j}]: unknown evidence reference")
    return errors
