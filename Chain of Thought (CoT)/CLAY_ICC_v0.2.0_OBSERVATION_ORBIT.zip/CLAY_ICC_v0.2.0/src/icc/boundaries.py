"""Explicit change/scope boundary checks; these do not grant authorization."""
from __future__ import annotations
from typing import Any

PROTECTED_BOX_FIELDS = ("purpose", "target", "domain", "scope", "constraints", "success_criteria", "failure_conditions", "assumptions")


def compare_problem_boxes(old: dict[str, Any], new: dict[str, Any]) -> dict:
    """Detect declared protected-field changes using structural equality only."""
    changed = [field for field in PROTECTED_BOX_FIELDS if old.get(field) != new.get(field)]
    return {
        "changed_protected_fields": changed,
        "human_reapproval_required": bool(changed),
        "decision": "HUMAN_REAPPROVAL_REQUIRED" if changed else "NO_PROTECTED_FIELD_CHANGE_DETECTED",
        "note": "Structural comparison cannot determine semantic equivalence or authenticate an approver."
    }


def compare_axis_sets(old: dict[str, Any], new: dict[str, Any]) -> dict:
    old_axes = {a.get("axis_id"): a for a in old.get("axes", []) if isinstance(a, dict)}
    new_axes = {a.get("axis_id"): a for a in new.get("axes", []) if isinstance(a, dict)}
    added = sorted(set(new_axes) - set(old_axes))
    removed = sorted(set(old_axes) - set(new_axes))
    changed = sorted(k for k in set(old_axes) & set(new_axes) if old_axes[k] != new_axes[k])
    critical_changes = []
    resolution_additions = []
    expansion_additions = []
    invalid_parent_refs = []
    for axis_id in added:
        parent_id = new_axes[axis_id].get("parent_axis_id")
        if parent_id:
            if parent_id not in old_axes:
                invalid_parent_refs.append(axis_id)
            else:
                resolution_additions.append(axis_id)
        else:
            expansion_additions.append(axis_id)
    for axis_id in set(old_axes) | set(new_axes):
        before, after = old_axes.get(axis_id), new_axes.get(axis_id)
        if (before and before.get("kind") == "CRITICAL") or (after and after.get("kind") == "CRITICAL"):
            if before != after:
                critical_changes.append(axis_id)
    material = bool(added or removed or changed)
    return {
        "added_axis_ids": added,
        "resolution_additions": sorted(resolution_additions),
        "expansion_additions": sorted(expansion_additions),
        "invalid_parent_refs": sorted(invalid_parent_refs),
        "removed_axis_ids": removed,
        "changed_axis_ids": changed,
        "critical_axis_changes": sorted(critical_changes),
        "human_reapproval_required": material,
        "decision": "HUMAN_REAPPROVAL_REQUIRED" if material else "NO_AXIS_CHANGE_DETECTED",
        "note": "A child axis with parent_axis_id refines an existing axis (resolution); an unparented new axis adds a new direction (expansion). All axis-set revisions require human re-approval."
    }

def check_scope_request(problem_box: dict[str, Any], requested_items: list[str]) -> dict:
    """Exact-label scope check only. Semantic scope interpretation belongs to the LLM/human."""
    in_scope = set(problem_box.get("scope", {}).get("in_scope", []))
    out_scope = set(problem_box.get("scope", {}).get("out_of_scope", []))
    requested = set(x for x in requested_items if isinstance(x, str))
    explicitly_excluded = sorted(requested & out_scope)
    not_declared = sorted(requested - in_scope - out_scope)
    needs_review = bool(explicitly_excluded or not_declared)
    return {
        "requested_items": sorted(requested),
        "explicitly_out_of_scope": explicitly_excluded,
        "not_declared_in_scope": not_declared,
        "decision": "SCOPE_REVIEW_REQUIRED" if needs_review else "WITHIN_DECLARED_LABELS",
        "can_proceed": not needs_review,
        "note": "Exact string matching only; this is not semantic scope detection or permission enforcement."
    }
