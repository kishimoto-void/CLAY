"""CLAY ICC specialist problem-engineering module."""
__version__ = "0.2.0"
