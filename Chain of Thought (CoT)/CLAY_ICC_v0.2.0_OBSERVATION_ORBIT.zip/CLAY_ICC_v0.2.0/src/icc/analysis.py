"""Deterministic status analysis; never claims to establish objective truth."""
from __future__ import annotations
from collections import defaultdict
from typing import Any
from .validation import validate_bundle


def _index(rows: list[dict], key: str) -> dict[str, dict]:
    return {r.get(key): r for r in rows if isinstance(r, dict) and isinstance(r.get(key), str)}


def summarize_evidence(evidence_records: list[dict]) -> dict:
    groups: dict[str, dict[str, set[str]]] = defaultdict(lambda: defaultdict(set))
    records_by_axis: dict[str, list[dict]] = defaultdict(list)
    for rec in evidence_records:
        if not isinstance(rec, dict):
            continue
        group = rec.get("independence_group_id") or rec.get("evidence_id", "UNKNOWN")
        relation = rec.get("relation", "UNKNOWN")
        axis_id = rec.get("axis_id", "UNLINKED")
        groups[group][relation].add(rec.get("evidence_id", "UNKNOWN"))
        records_by_axis[axis_id].append(rec)
    axis_summary = {}
    for axis_id, rows in records_by_axis.items():
        relation_groups = defaultdict(set)
        for rec in rows:
            group = rec.get("independence_group_id") or rec.get("evidence_id", "UNKNOWN")
            relation_groups[rec.get("relation", "UNKNOWN")].add(group)
        axis_summary[axis_id] = {
            "record_count": len(rows),
            "independent_group_count": len({r.get("independence_group_id") or r.get("evidence_id") for r in rows}),
            "relation_group_counts": {k: len(v) for k, v in sorted(relation_groups.items())},
            "contains_contradiction": bool(relation_groups.get("CONTRADICT")),
            "contains_support": bool(relation_groups.get("SUPPORT")),
        }
    return {"record_count": len(evidence_records), "independence_group_count": len(groups), "by_axis": axis_summary}


def analyze_bundle(bundle: dict[str, Any], *, approval_verifier=None) -> dict:
    """Analyze declared records. Host must supply an approval verifier for formal gate readiness.

    approval_verifier(subject_type, subject_record, approval_record) -> bool
    The callback is a trusted Host integration point; this module never authenticates identity itself.
    """
    validation_errors = validate_bundle(bundle)
    box = bundle.get("problem_box", {})
    axis_set = bundle.get("axis_set", {})
    evidence = bundle.get("evidence_records", [])
    assessments = bundle.get("assessments", {})
    axes = axis_set.get("axes", []) if isinstance(axis_set, dict) else []
    axis_results = _index(assessments.get("axis_results", []), "axis_id") if isinstance(assessments, dict) else {}
    constraint_results = _index(assessments.get("constraint_results", []), "constraint_id") if isinstance(assessments, dict) else {}
    evidence_by_id = _index(evidence, "evidence_id")

    issues: list[dict] = []
    for err in validation_errors:
        issues.append({"code": "STRUCTURAL_VALIDATION_ERROR", "severity": "ERROR", "message": err})

    box_declared_approved = (
        isinstance(box, dict) and box.get("status") == "APPROVED"
        and isinstance(box.get("approval"), dict) and box["approval"].get("status") == "HUMAN_APPROVED"
    )
    axes_declared_approved = (
        isinstance(axis_set, dict) and axis_set.get("status") == "LOCKED"
        and isinstance(axis_set.get("approval"), dict) and axis_set["approval"].get("status") == "HUMAN_APPROVED"
    )
    def host_verified(kind: str, record: dict) -> bool:
        if approval_verifier is None:
            return False
        try:
            return bool(approval_verifier(kind, record, record.get("approval", {})))
        except Exception:
            return False
    box_host_verified = box_declared_approved and host_verified("problem_box", box)
    axes_host_verified = axes_declared_approved and host_verified("axis_set", axis_set)
    box_ready = box_declared_approved and box_host_verified
    axes_ready = axes_declared_approved and axes_host_verified
    if not box_declared_approved:
        issues.append({"code": "PROBLEM_BOX_NOT_APPROVED", "severity": "BLOCKER", "message": "Problem Box requires a recorded human approval before formal evaluation."})
    elif not box_host_verified:
        issues.append({"code": "PROBLEM_BOX_APPROVAL_NOT_HOST_VERIFIED", "severity": "BLOCKER", "message": "Approval metadata is not identity proof; Host-side approval verification is required."})
    if not axes_declared_approved:
        issues.append({"code": "AXIS_SET_NOT_LOCKED", "severity": "BLOCKER", "message": "Coordinate axes require human approval and locking before formal evaluation."})
    elif not axes_host_verified:
        issues.append({"code": "AXIS_APPROVAL_NOT_HOST_VERIFIED", "severity": "BLOCKER", "message": "Axis approval metadata is not identity proof; Host-side approval verification is required."})

    critical_states = []
    axis_report = []
    for axis in axes:
        if not isinstance(axis, dict):
            continue
        axis_id = axis.get("axis_id")
        result = axis_results.get(axis_id)
        status = result.get("status") if result else "NOT_EXECUTED"
        evidence_ids = result.get("evidence_ids", []) if result else []
        linked = [evidence_by_id[eid] for eid in evidence_ids if eid in evidence_by_id]
        has_verified_support = any(e.get("relation") == "SUPPORT" and e.get("verification_status") == "VERIFIED" for e in linked)
        has_contradiction = any(e.get("relation") == "CONTRADICT" for e in linked)
        if status == "PASS" and not has_verified_support:
            issues.append({"code": "PASS_WITHOUT_VERIFIED_SUPPORT", "severity": "BLOCKER" if axis.get("kind") == "CRITICAL" else "WARNING", "axis_id": axis_id, "message": "PASS is not accepted as evidence-backed without linked VERIFIED SUPPORT evidence."})
            status = "INCONCLUSIVE"
        if has_contradiction and status == "PASS":
            issues.append({"code": "CONTRADICTORY_EVIDENCE", "severity": "BLOCKER" if axis.get("kind") == "CRITICAL" else "WARNING", "axis_id": axis_id, "message": "Linked contradictory evidence prevents treating this axis as an unqualified PASS."})
            status = "INCONCLUSIVE"
        axis_report.append({"axis_id": axis_id, "name": axis.get("name"), "kind": axis.get("kind"), "priority": axis.get("priority"), "negotiability": axis.get("negotiability"), "status": status, "linked_evidence_count": len(linked), "independent_evidence_groups": len({e.get("independence_group_id") for e in linked}), "contains_contradiction": has_contradiction})
        if axis.get("kind") == "CRITICAL":
            critical_states.append((axis_id, status))

    hard_constraints = [c for c in box.get("constraints", []) if isinstance(c, dict) and c.get("type") == "HARD"] if isinstance(box, dict) else []
    constraint_report = []
    for constraint in hard_constraints:
        cid = constraint.get("constraint_id")
        result = constraint_results.get(cid)
        status = result.get("status") if result else "NOT_EXECUTED"
        linked = [evidence_by_id[eid] for eid in (result or {}).get("evidence_ids", []) if eid in evidence_by_id]
        has_verified_support = any(e.get("relation") == "SUPPORT" and e.get("verification_status") == "VERIFIED" for e in linked)
        has_contradiction = any(e.get("relation") == "CONTRADICT" for e in linked)
        if status == "PASS" and (not has_verified_support or has_contradiction):
            issues.append({"code": "HARD_CONSTRAINT_PASS_NOT_ESTABLISHED", "severity": "BLOCKER", "constraint_id": cid, "message": "A hard constraint PASS requires linked verified supporting evidence and no linked contradiction."})
            status = "INCONCLUSIVE"
        constraint_report.append({"constraint_id": cid, "status": status, "linked_evidence_count": len(linked)})

    if not any(a.get("kind") == "CRITICAL" for a in axes if isinstance(a, dict)):
        issues.append({"code": "NO_CRITICAL_AXIS_DEFINED", "severity": "BLOCKER", "message": "No non-compensatory critical axis is defined; human review is required before feasibility can be established."})

    critical_fail = any(s == "FAIL" for _, s in critical_states)
    hard_fail = any(c["status"] == "FAIL" for c in constraint_report)
    critical_pending = any(s != "PASS" for _, s in critical_states)
    hard_pending = any(c["status"] != "PASS" for c in constraint_report)
    ready = box_ready and axes_ready and not validation_errors and any(a.get("kind") == "CRITICAL" for a in axes if isinstance(a, dict))
    if not ready:
        overall = "NOT_READY_FOR_FORMAL_EVALUATION"
    elif critical_fail or hard_fail:
        overall = "BLOCKED_BY_NONCOMPENSATORY_FAILURE"
    elif critical_pending or hard_pending:
        overall = "FEASIBILITY_NOT_ESTABLISHED"
    elif any(a["status"] != "PASS" for a in axis_report):
        overall = "PROVISIONALLY_FEASIBLE_WITH_RESIDUALS"
    else:
        overall = "PROVISIONALLY_FEASIBLE"

    # Do not collapse evidence to a scalar truth/confidence score.
    result = {
        "schema_version": "icc.analysis-result/0.1",
        "problem_id": box.get("problem_id") if isinstance(box, dict) else None,
        "overall_status": overall,
        "problem_box_gate": "HOST_VERIFIED" if box_ready else ("DECLARED_NOT_HOST_VERIFIED" if box_declared_approved else "PENDING_HUMAN_APPROVAL"),
        "axis_gate": "HOST_VERIFIED_LOCKED" if axes_ready else ("DECLARED_NOT_HOST_VERIFIED" if axes_declared_approved else "PENDING_HUMAN_APPROVAL"),
        "critical_axis_results": [{"axis_id": aid, "status": status} for aid, status in critical_states],
        "axis_results": axis_report,
        "hard_constraint_results": constraint_report,
        "evidence_summary": summarize_evidence(evidence if isinstance(evidence, list) else []),
        "issues": issues,
        "limitations": [
            "This is structural/status analysis, not proof of objective truth or engineering safety.",
            "Approval metadata must be authenticated by a trusted Host callback; strings in JSON are not identity proof.",
            "Evidence authenticity, relevance, independence, and assessment quality require external review.",
            "No weighted average or majority vote can compensate for a failed critical axis or hard constraint.",
            "The module does not select or execute a final design on behalf of the human designer.",
            "Satellite-map breadth is an observation-coverage record, not a confidence score or causal proof."
        ]
    }
    satellite_map = bundle.get("satellite_map") if isinstance(bundle, dict) else None
    if isinstance(satellite_map, dict):
        coverage = satellite_map.get("coverage", []) if isinstance(satellite_map.get("coverage", []), list) else []
        result["satellite_map_summary"] = {
            "status": satellite_map.get("status"),
            "satellite_count": len(satellite_map.get("satellites", [])) if isinstance(satellite_map.get("satellites", []), list) else 0,
            "subproblem_count": len(satellite_map.get("subproblems", [])) if isinstance(satellite_map.get("subproblems", []), list) else 0,
            "relation_count": len(satellite_map.get("relations", [])) if isinstance(satellite_map.get("relations", []), list) else 0,
            "coverage_counts": {state: sum(1 for row in coverage if isinstance(row, dict) and row.get("status") == state) for state in ("SCANNED", "PARTIAL", "NOT_SCANNED", "NOT_APPLICABLE")},
            "blind_spot_count": len(satellite_map.get("blind_spots", [])) if isinstance(satellite_map.get("blind_spots", []), list) else 0,
            "interpretation": "Coverage counts describe which observation sectors were examined; they do not measure certainty, truth, or completeness."
        }
    return result
