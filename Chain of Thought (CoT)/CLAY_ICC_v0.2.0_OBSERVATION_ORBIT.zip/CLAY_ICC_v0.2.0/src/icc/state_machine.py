"""Conservative state-transition guard for ICC phase records."""
from __future__ import annotations

TRANSITIONS = {
    "INTAKE": {"BOX_FORMATION"},
    "BOX_FORMATION": {"BOX_REVIEW"},
    "BOX_REVIEW": {"AXIS_PROPOSAL", "HANDOFF_REQUIRED"},
    "AXIS_PROPOSAL": {"AXIS_REVIEW", "HANDOFF_REQUIRED"},
    "AXIS_REVIEW": {"PLANNING", "AXIS_PROPOSAL", "HANDOFF_REQUIRED"},
    "PLANNING": {"DIFFUSION", "EVALUATION", "CONVERGENCE", "HANDOFF_REQUIRED"},
    "DIFFUSION": {"EVALUATION", "CONVERGENCE", "HANDOFF_REQUIRED"},
    "EVALUATION": {"DIFFUSION", "CONVERGENCE", "RECOVERY", "REFRAMING", "HANDOFF_REQUIRED"},
    "CONVERGENCE": {"DIFFUSION", "EVALUATION", "HANDOFF", "HANDOFF_REQUIRED"},
    "RECOVERY": {"DIFFUSION", "EVALUATION", "HANDOFF_REQUIRED"},
    "REFRAMING": {"BOX_FORMATION", "HANDOFF_REQUIRED"},
    "HANDOFF": set(),
    "HANDOFF_REQUIRED": {"BOX_FORMATION", "AXIS_PROPOSAL", "PLANNING", "HANDOFF"},
}


def validate_transition(current: str, target: str, *, problem_box_approved: bool = False,
                        axes_human_approved: bool = False, human_reapproval: bool = False) -> list[str]:
    errors = []
    if current not in TRANSITIONS:
        return [f"unknown current state: {current}"]
    if target not in TRANSITIONS.get(current, set()):
        errors.append(f"transition not allowed: {current} -> {target}")
    if target in {"AXIS_PROPOSAL", "AXIS_REVIEW", "PLANNING", "DIFFUSION", "EVALUATION", "CONVERGENCE"} and not problem_box_approved:
        errors.append("Problem Box human approval is required before coordinate work")
    if target in {"PLANNING", "DIFFUSION", "EVALUATION", "CONVERGENCE"} and not axes_human_approved:
        errors.append("human-approved coordinate axes are required before formal evaluation")
    if current == "REFRAMING" and target == "BOX_FORMATION" and not human_reapproval:
        errors.append("reframing requires explicit human re-approval of the revised Problem Box")
    if current == "HANDOFF_REQUIRED" and target in {"BOX_FORMATION", "AXIS_PROPOSAL", "PLANNING"} and not human_reapproval:
        errors.append("resuming after handoff requires explicit human approval")
    return errors
