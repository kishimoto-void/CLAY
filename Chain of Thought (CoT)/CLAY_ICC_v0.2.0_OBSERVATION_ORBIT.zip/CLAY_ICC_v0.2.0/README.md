# CLAY Iterative Coordinate Convergence (ICC) v0.2.0

**Status:** specialist reference implementation + working design specification. Not a production-certified reasoning engine.

ICC is a human-governed specialist module for problem engineering: it structures a finite problem space, proposes problem-specific evaluation axes, preserves critical conditions, organizes evidence and counterevidence, guides bounded diffusion/convergence, tracks residuals, and prepares phase handoffs.

It is designed to work **above the general thinking baseline of CLAY BTM v0.2.0**, not replace it.

## Architecture boundary

| Component | Owns | Does not own |
|---|---|---|
| BTM v0.2.0 | Verified Fidelity, instruction lifecycle, request rigor, general diffusion/convergence direction, bounded scope, honest reporting | ICC Problem Box, formal coordinate model, evidence graph, phase lifecycle |
| ICC | Problem Box, axes, non-compensatory gates, evidence organization, specialist process guidance, recovery, handoff | Host permissions, tool execution, domain certification, autonomous final decisions |
| Host / human | Identity/provenance verification, approvals, persistence, tool execution, external checks, final authority | Must not delegate its permissions/approval role merely by loading ICC |

## Key design choices

- Problem Box formation precedes coordinate design.
- Axis count is **problem-dependent**. The earlier three-axis idea is a historical starting heuristic, not a universal requirement.
- Axis priority and negotiability are separate attributes.
- `CRITICAL` axes and `HARD` constraints are non-compensatory. A fail cannot be offset by other criteria.
- A missing, untested, or inconclusive critical axis means feasibility is not established.
- Coordinate Resolution (more detail within an axis) differs from Coordinate/Observation Expansion (a new evaluation direction or observation path).
- Evidence is tracked by provenance, relation, scope, uncertainty, verification state, and independence group. Correlated sources are not counted as independent.
- Optional Satellite Observation Map records surrounding stakeholders, incentives, resources, institutions, timelines, external forces, feedback, and blind spots without turning every factor into a core axis.
- A Problem Separation Firewall partitions entangled tasks into subproblems, links shared factors, and prevents automatic transfer of assumptions or conclusions between them.
- Actor goals are assessed separately from statements, actions, resource allocation, and outcomes; inner intent is never treated as directly observed.
- Convergence is provisional and conditional. The module never certifies truth or forces a single answer when evidence conflicts.
- Scope, objective, hard constraints, and critical-axis meaning cannot be silently changed. Human re-approval creates a new version.
- ICC core does not execute experiments, destructive tests, tools, deployment, or external actions.

## Quick start

Python 3.10+; runtime uses the standard library only. Optional JSON Schema conformance tests use `pip install -e .[schema-test]`.

```bash
PYTHONPATH=src python -m unittest discover -s tests -v
PYTHONPATH=src python -m icc validate-bundle --input examples/approved_sample_bundle.json
PYTHONPATH=src python -m icc analyze --input examples/approved_sample_bundle.json
PYTHONPATH=src python -m icc compile \
  --input examples/approved_sample_bundle.json \
  --btm-control examples/btm_rigorous_narrow.json \
  --target generic \
  --output /tmp/icc_prompt.md
```

## What the Python reference code implements

- Structural validation for Problem Box, axis set, evidence records, assessment records, and optional satellite-map records/references.
- Problem Box / axis version linkage and human-approval metadata checks.
- Non-compensatory feasibility status calculation for critical axes and hard constraints.
- PASS checks require linked declared `VERIFIED` + `SUPPORT` evidence; linked contradiction blocks an unqualified PASS. The module cannot authenticate evidence sources itself.
- Formal gate readiness additionally requires a trusted Host-supplied `approval_verifier` callback; approval strings in JSON alone do not count.
- Evidence independence-group counting without treating repeated dependent sources as independent.
- BTM v0.2.0 task-control subset validation and deterministic process-guidance mapping.
- Conservative state-transition checks.
- Specialist prompt compilation with task JSON explicitly marked as untrusted data.
- CLI for validation, analysis, and prompt compilation.

The standalone CLI has no identity/authentication service. Therefore `icc analyze` can validate and report the bundle but intentionally leaves formal approval gates unverified. A production Host must provide a trusted `approval_verifier` function to the Python API after validating the human approval event.

## What remains prompt guidance / future work

- Natural-language problem interpretation and semantic scope detection are performed by the target LLM, not deterministically by this Python package.
- This package does not implement a general evidence-acquisition system, external source verification, statistical uncertainty calibration, an optimizer, physical simulation, or automatic experiment planning.
- Full append-only storage, cryptographic approval signatures, host adapters, and runtime enforcement are not included.
- Phase records and handoff capsules are specified as formats/workflows; persistent lifecycle management is host-side.
- Domain-specific modules and standards adapters are not included.

See `docs/IMPLEMENTATION_STATUS.md` before relying on any feature.


See `docs/OBSERVATION_ORBIT_AND_PROBLEM_SEPARATION.md` for the v0.2.0 satellite and problem-separation design. `examples/satellite_map.template.json` is an optional starter template.

Local test evidence for this version: `docs/TEST_REPORT_v0.2.0.md`.
