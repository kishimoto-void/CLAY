# Changelog

## 0.2.0 — Observation Orbit + Problem Separation

- Added optional Satellite Observation Map, linked to a specific Problem Box version.
- Added observation coverage ledger to make blind spots visible without treating breadth as confidence.
- Added typed satellite relations and causal-hypothesis fields for mechanism, time scope, evidence, alternatives, and disconfirmers.
- Added subproblem partitions and a default KEEP_SEPARATE / LINK_ONLY policy to limit LLM context blending.
- Added actor goal/action/resource/outcome separation to avoid treating public statements as proof of intent.
- Added deterministic structural and reference validation for the optional satellite map.
- Updated Japanese and English operating prompts for a ChatGPT-friendly scan, separation, linkage, and contamination-audit workflow.
- Preserved the core Problem Box, axis, CRITICAL, HARD, approval, evidence, and BTM boundaries.

## 0.1.0 — Initial specialist package

- Established ICC as a distinct CLAYLink specialist module built on BTM v0.2.0.
- Added Problem Box and axis-set contracts with human approval metadata.
- Added critical-axis / hard-constraint non-compensation analysis.
- Added evidence provenance, relation, uncertainty, and independence-group records.
- Added BTM v0.2.0 task-control compatibility mapping.
- Added state-transition guard, CLI, schemas, examples, tests, and specialist operating prompt.
- Explicitly excluded runtime execution, permission enforcement, autonomous evidence acquisition, domain certification, and destructive testing.
