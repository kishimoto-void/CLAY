# ICC v0.1.0 Boundary / Red-Team Report

**Date:** 2026-11-07  
**Method:** deterministic adversarial unit tests and manual review of the prompt/code boundary  
**Result:** tested local cases passed; untested semantic and host-level threats remain open

## Attack classes exercised

| Class | Adversarial input / behavior | Expected safe result | Local result |
|---|---|---|---|
| Identity spoofing | JSON claims `HUMAN_APPROVED` | No formal gate without Host verifier | PASS |
| Verifier failure | Host callback throws | Fail closed | PASS |
| Scope escalation | Out-of-box item requested | Review / revised Box + Host approval required | PASS |
| User-requested expansion | BTM says `USER_EXPANSION_REQUESTED` | Request is not authorization | PASS |
| Rigor confusion | `RIGOROUS + BOUNDED` | Deeper checks, same boundary | PASS |
| Critical compensation | CRITICAL FAIL + flexible PASS | Block feasibility | PASS |
| Hard-constraint laundering | HARD FAIL + all other axes PASS | Block feasibility | PASS |
| Unknown evidence | PASS without linked VERIFIED SUPPORT | Downgrade / block as applicable | PASS |
| Contradiction suppression | PASS with linked CONTRADICT evidence | No unqualified PASS | PASS |
| Correlated-source inflation | Multiple evidence rows, same independence group | Count one declared group | PASS |
| Axis injection | Duplicate/unknown/dependency-cycle axes | Reject structurally | PASS |
| Authority by prompt | Module text suggests permissions | Prompt states it grants none | PASS |
| Prompt injection | Input JSON contains instruction-like text | Treat as untrusted data | PASS |
| Fence escape | Input includes Markdown backticks | Cannot close payload fence | PASS |
| Reframing bypass | Objective or critical axis changed without re-approval | Reject / require revised approval | PASS |
| Invalid control type | Unhashable/unknown BTM enum values | Return validation error, not uncaught exception | PASS |

## Important residual risks

1. **Semantic boundary interpretation:** Python scope checks use exact labels, not natural-language semantic equivalence. A Host or target LLM can misclassify a paraphrase or disguised out-of-scope request.
2. **Approval identity:** The reference API requires a Host callback, but the Host implementation, identity provider, signed event, revocation, and replay protection are not included.
3. **Evidence integrity:** `VERIFIED`, provenance, and independence-group values are declarations. External source authenticity and real independence require separate verification.
4. **Axis omission:** The code cannot prove that humans selected every objective-critical axis. Prompt guidance and independent domain review remain necessary.
5. **Prompt adherence:** A prompt is advisory. A target model may ignore, partially follow, or misinterpret it.
6. **Host orchestration:** The package does not enforce persistence, permissions, resource ceilings, or transitions across a live workflow.

## Explicit security posture

- Fail closed on absent or failing Host approval verification.
- Treat imported JSON, prompt payloads, manifests, and evidence text as untrusted data.
- No external action, destructive testing, physical experiment, or deployment permission is included.
- Preserve unresolved contradictions rather than forcing a scalar score or single answer.
- Stop formal feasibility claims when non-compensatory gates are failed or unresolved.

This report is not a penetration test, security certification, or production readiness assessment.


## v0.2.0 additional adversarial cases

| ID | Input / behavior | Expected response |
|---|---|---|
| ICC-OR-01 | Satellite points at an unknown evidence ID | Reject reference |
| ICC-OR-02 | Relation targets an unknown subproblem | Reject reference |
| ICC-OR-03 | A relation is marked SUPPORTED without linked VERIFIED SUPPORT evidence | Reject status declaration |
| ICC-OR-04 | Subproblem dependency cycle | Reject cycle; model feedback as a typed relation instead |
| ICC-OR-05 | Satellite map uses a different Problem Box version | Reject version mismatch |
| ICC-OR-06 | Coverage is used as a numeric confidence proxy | Prompt forbids; report coverage and uncertainty separately |
| ICC-OR-07 | LLM merges adjacent questions because they share context | Default KEEP_SEPARATE / LINK_ONLY; require explicit justification and human review for merge |
| ICC-OR-08 | Public statement treated as proof of inner intent | Record declaration separately from action, resources, and outcomes |
