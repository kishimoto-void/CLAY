# BTM v0.2.0 Integration Contract

## Relationship
ICC consumes BTM's task-level control metadata as an input and applies it to ICC's own specialist workflow. It does not copy BTM's instruction registry, replace the BTM prompt compiler, or grant itself higher authority.

## Accepted fields
- `requested_rigor`: QUICK / STANDARD / RIGOROUS
- `cognitive_direction`: AUTO / CONVERGENCE / DIFFUSION
- `scope_policy`: BOUNDED / CONSULT_BEFORE_EXPANSION / USER_EXPANSION_REQUESTED
- optional `objective`, `critical_outcomes`, `hard_constraints`, `flexible_constraints`, `stop_condition`

## Mapping

| BTM value | ICC process effect | Does not mean |
|---|---|---|
| QUICK | Minimize process overhead; retain essential gates | Skip safety/critical gates |
| STANDARD | Normal problem framing and validation | Assume exhaustive coverage |
| RIGOROUS | Deeper checks, counterevidence, dependencies, traceability | Expand scope automatically |
| CONVERGENCE | Focus current approved object and dependencies | Ignore relevant contradiction |
| DIFFUSION | Explore relevant alternatives/hypotheses | Unlimited exploration |
| AUTO | LLM interprets task semantics with bounded default | Python classifier or automatic broad search |
| BOUNDED | No expansion beyond approved Problem Box | Host-side permission check |
| CONSULT_BEFORE_EXPANSION | Propose scope change and wait | Permission to continue |
| USER_EXPANSION_REQUESTED | Record expansion intent; prepare a revised Box proposal and wait for human approval | Proceed outside the currently approved Problem Box |

## Contract rule
Rigor, cognitive direction, and scope policy remain orthogonal. `RIGOROUS + BOUNDED` is a valid and important combination: rigor increases depth inside the current box without widening the box.

## Versioning
This package targets BTM `>=0.2.0` serialized field semantics. It currently validates a compatible subset locally and has no runtime dependency on BTM's Python package. Future breaking BTM field changes require a versioned adapter and compatibility tests.
