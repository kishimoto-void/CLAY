# ICC 基本仕様書 v0.1.0（日本語）

**状態：初期専門モジュール実装／作業仕様。** 本書は設計対話記録 v0.1 と BTM v0.2.0 を基にした初回の実装可能な整理であり、最終確定仕様・本番認証ではない。

## 1. 目的と専門性

ICC（Iterative Coordinate Convergence）は、単なる汎用チャット人格や一般的な思考強化プロンプトではない。人間が設定した問題を有限の Problem Box として定義し、その問題に必要な評価座標を設計し、根拠・反証・不確実性・残差を整理しながら、現在の条件下で成立する暫定基準点を更新するための専門的な問題工学モジュールである。

専門性の中心は、特定分野の知識を自称することではなく、次の工程を一貫した契約で管理することにある。

1. Problem Formation / Problem Box
2. Coordinate / Axis Design and Human Approval
3. Macro-to-Micro Phase Refinement
4. Observation / Evidence / Counterevidence Management
5. Adaptive Diffusion and Convergence
6. Non-compensatory Critical Evaluation
7. Purpose-preserving Recovery / Reframing
8. Honest Reporting / Human Handoff

ICCは問題解決プロセスを専門化する。医療・法律・金融・建築構造・電気・化学・航空・自動車・サイバーセキュリティ等の専門資格・専門的妥当性を自動的に備えるわけではない。

## 2. BTM v0.2.0との分離

| 領域 | BTM | ICC |
|---|---|---|
| 指示の忠実性・寿命・競合 | 主担当 | BTMに従う |
| 要求された厳密さ | 一般制御 | BTMの値を専門工程へ反映 |
| 一般的な拡散／収縮方針 | 主担当 | ICC固有の問題状態に適用 |
| 探索範囲の一般制御 | 主担当 | Problem Boxに照らして境界を検査 |
| Problem Box | 非担当 | 主担当 |
| 座標軸の設計・承認管理 | 非担当 | 主担当 |
| 重要軸の非代償ゲート | 一般原則のみ | 明示的な軸メタデータと評価を担当 |
| Evidence / Independence / Residual | 非担当 | 主担当 |
| Phase Record / Handoff Capsule | 一般原則のみ | 専門記録形式を定義 |

ICCはBTMの代替でも、BTMへ統合された機能の再実装でもない。BTM v0.2.0の `requested_rigor`、`cognitive_direction`、`scope_policy` を受け取り、ICCの工程運用へ翻訳する。BTMのメタデータも実行権限ではなく、Hostの許可・実行制御を置き換えない。

## 3. Problem Box

正式な座標設計の前に、最低限以下を定義する。

- `purpose`：何を達成するのか
- `target`：何を対象にするのか
- `domain`：どの領域の問題か
- `scope.in_scope / out_of_scope`：含む範囲と除外範囲
- `constraints`：HARD / SOFT、交渉可能性
- `success_criteria`：成立・成功を判定する条件と検証方法
- `failure_conditions`：不成立・停止・再設計の条件
- `assumptions`：前提と検証状態
- `approval`：人間承認の記録

### Problem Formation Gate

目的整合性、境界整合性、内部整合性、成立可能性、評価可能性、認識一致性、外部整合性を別々に確認する。人間とLLMが同意しても客観的妥当性が証明されたわけではない。

Problem Boxの承認は人間が行う。JSON上の `HUMAN_APPROVED` は承認を記録したデータであり、本人性・真正性を暗号学的に保証しない。Hostは実際の承認者と権限を別途検証しなければならない。

## 4. 座標・軸の管理

軸の数と種類は問題依存とする。過去の設計記録にある初期3軸は出発時のヒューリスティックであり、必須数ではない。必要な最小数を人間とLLMで提案し、人間が承認する。

各軸に次を持たせる。

- `kind`：CRITICAL / CONDITIONAL / FLEXIBLE / EXPLORATORY
- `priority`：P0 / P1 / P2 / P3
- `negotiability`：LOCKED / HUMAN_REAPPROVAL / FLEXIBLE
- 定義、目的との接続、測定方法、PASS条件、依存先

優先度と交渉可能性を混同しない。CRITICAL軸はFLEXIBLEにできない。CRITICAL軸の失敗、またはHARD制約の失敗は、他の軸の良い評価で相殺できない。

`Coordinate Resolution` は既存軸の細分化。`Coordinate / Observation Expansion` は新しい評価方向・観測経路の追加。新しい軸を追加する場合、Problem Boxとの関係、既存軸との重複、測定可能性、複雑化コストを示し、人間の承認を得る。

## 5. 評価と暫定収束

評価は二段階に分ける。

1. CRITICAL軸とHARD制約の非代償ゲート
2. ゲートを通過した候補間でのFLEXIBLE項目の比較

重要軸が未実施・不明・判断不能なら「成立」としない。根拠が矛盾するなら矛盾を残し、無理に単一解へ収束しない。ICCのコードは真理値や最適解を証明せず、登録された評価状態の整合性を確認する。

## 6. 根拠と独立性

Evidenceは主張単位で記録し、出典・来歴・対象軸・SUPPORT / CONTRADICT / PARTIAL / UNKNOWN・独立性グループ・適用範囲・不確実性・検証状態を保持する。同一の原資料に依存する複数文書は、独立した複数根拠として数えない。

`PASS` は、リンクされた `VERIFIED` かつ `SUPPORT` のEvidenceを必要とする。リンクされた反証がある場合、無条件PASSとして扱わない。これは構造上の保守的ルールであり、Evidenceの真偽や関連性をコードが保証するものではない。

## 7. 拡散・収縮

拡散は要求・不確実性・問題状態・承認範囲に応じて行う。初期のProblem Formationは比較的広くてもよいが、Box承認後はその範囲を守る。収縮は候補を無理に一つにする操作ではなく、根拠・反証・未解決事項を整理して次の基準点を作る操作。

RIGOROUSは検証深度を高める指定であり、探索範囲の拡張を意味しない。範囲変更が必要なら、提案のみを出し、人間の承認を待つ。

## 8. 回復・再企画

失敗した手段と目的そのものの失敗を区別する。目的を維持した代替手段を提案できるが、目的・Box境界・HARD制約・重要軸の意味を変更するには人間の再承認と新バージョンが必要。過去記録を上書きせず、変更理由と影響範囲を記録する。

## 9. フェーズ記録と引き継ぎ

Dictionary、Phase Record、Handoff Capsuleの3層を推奨する。過去の確定事項は履歴として保持し、新しい根拠での変更はREVALIDATED / REVISEDイベントとして残す。HandoffにはBox・軸の版、承認状態、根拠、反証、残差、未解決事項、次の最小行動、必要な人間承認を含める。

## 10. 実行・権限境界

ICCコードはローカルのデータ検証、状態整理、プロンプト生成を行うだけである。ネットワーク、外部データ取得、ツール実行、物理試験、設備操作、デプロイ、永続保存、権限付与は行わない。Hostが権限を管理し、人間が重大な判断を承認する。

## 11. 破壊試験の分離

破壊型・限界探索型の試験実行はICC Coreに含めない。別モジュールとして、対象所有者の許可、対象・方法・環境・負荷・期間、隔離、安全、法令・契約、停止条件、監査記録を独立に定義しなければならない。ICCは試験設計上のリスクや境界を整理できるが、破壊行為の実行許可を出さない。

## 12. 実装成熟度

実装済み：構造バリデータ、基本状態分析、Critical/Hardの非代償判定、Evidence独立グループ集計、BTM制御値との互換検証、状態遷移ガード、CLI、プロンプト生成。

仕様・プロンプト上：自然言語のProblem Formation、意味的な軸妥当性評価、専門家との共同判断、フェーズ履歴の運用、再企画、実世界根拠の真正性判断。

未実装：外部Evidence取得、実行ランタイム、永続ストレージ、暗号学的承認、最適化ソルバー、分野別専門アダプター、自動試験実行。
