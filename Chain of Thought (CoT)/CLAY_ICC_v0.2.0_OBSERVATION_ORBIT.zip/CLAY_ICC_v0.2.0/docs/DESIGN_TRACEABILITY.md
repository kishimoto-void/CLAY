# Design Traceability — Conversation Memo to ICC v0.1.0

This table maps the 2026-11-06 CLAYLink/ICC working memo and later design decisions into this package. A mapped item may be implemented, prompt-specified, or explicitly deferred.

| Design concept | v0.1.0 location | Status |
|---|---|---|
| BTM is common baseline; ICC is a specialist CLAYLink module | `docs/BTM_INTEGRATION.md`, `manifest.json` | Implemented contract / prompt |
| Problem Formation precedes axis definition | `prompts/ICC_SYSTEM_PROMPT_JA.md`, `docs/ICC_SPEC_JA.md` | Prompt-specified |
| Problem Box has objective, target, scope, exclusions, constraints, validity/failure conditions | `schemas/problem-box.schema.json`, `validation.py` | Structural implementation |
| Human approval is separate from LLM agreement | `analysis.py` Host approval callback; boundary docs | Implemented fail-closed gate; Host authentication still external |
| Initial axes are problem-specific; no universal mandatory three | `axis-set.schema.json`, prompt, spec | Implemented variable-size schema; semantic selection human/LLM guided |
| Criticality, priority, negotiability are separate | Axis schema, validators, analyzer | Implemented |
| Critical-axis and HARD-constraint non-compensation | `analysis.py` | Implemented |
| Coordinate Resolution vs Coordinate Expansion | `boundaries.py`, `axis-set.schema.json`, prompt | Structural classification + prompt guidance |
| Macro-to-micro phase refinement | `docs/WORKFLOW_AND_RECORDS.md`, prompt, phase schema | Prompt / record format; no autonomous phase runner |
| Diffusion / convergence adapts to task state and request | BTM mapping, prompt D0-D4 | Prompt guidance; no NLP classifier |
| RIGOROUS does not imply broad scope | `policy.py`, tests, BTM integration spec | Implemented mapping |
| Evidence relations SUPPORT / CONTRADICT / PARTIAL / UNKNOWN | Evidence schema, validation, analyzer | Implemented structural/status handling |
| Evidence independence grouping | `analysis.py` | Implemented metadata grouping; source dependence itself must be assessed externally |
| Residuals and provisional convergence | Analyzer statuses / prompt | Basic statuses implemented; no numerical optimizer |
| Purpose-preserving recovery / reframing | Prompt and boundary compare utilities | Prompt guidance + structural change detection |
| History should not be silently overwritten | Version references, docs, templates | Specified; append-only storage not implemented |
| Honest PASS / FAIL / NOT_EXECUTED / INCONCLUSIVE / PARTIAL | Schemas, analyzer, prompt | Implemented status vocabulary |
| Human handoff / Handoff Capsule | `examples/handoff_capsule.template.json` | Template only; Host persists it |
| Separate destructive-testing module | `docs/BOUNDARIES_AND_NON_GOALS.md`, prompt | Explicitly excluded from ICC Core |

## Important evolution from the working memo

The working memo described an initial three-axis pattern. In the later design discussion this was generalized to a problem-dependent number and type of axes. This package follows the later direction: **no fixed count**, while retaining the initial-three concept as a possible starting heuristic only.

The D0-D4 diffusion scale is also retained as provisional planning vocabulary. No deterministic thresholds or automatic classifier are claimed.


## v0.2.0 additions
- Satellite observation map and coverage ledger -> `schemas/satellite-map.schema.json`, `docs/OBSERVATION_ORBIT_AND_PROBLEM_SEPARATION.md`.
- Problem partitioning / non-merging default -> subproblem records + Separation Firewall prompt.
- Actor declaration/action/outcome distinction -> optional motive_profile plus corresponding prompt rules.
- These additions remain observational; core axes and approval gates are unchanged.
