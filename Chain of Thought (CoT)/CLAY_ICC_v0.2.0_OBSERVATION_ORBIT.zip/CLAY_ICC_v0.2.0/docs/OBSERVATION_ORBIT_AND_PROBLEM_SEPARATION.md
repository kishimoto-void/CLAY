# ICC Observation Orbit and Problem Separation Layer — v0.2.0

## Purpose

ICC v0.2.0 adds an observation layer around the approved Problem Box and coordinate axes. It is designed to widen the set of observable factors without multiplying or weakening the core evaluation axes. The feature also adds explicit separation of adjacent or entangled problems, because LLMs can blend contextually related questions, assumptions, entities, and causal stories.

## Architecture

- **Core Problem Box:** what is being solved, its target, boundaries, constraints, and success/failure conditions.
- **Core Coordinates:** approved evaluation axes. CRITICAL axes and HARD constraints remain non-compensatory.
- **Satellite Observation Map:** surrounding stakeholders, declared goals, actions, outcomes, incentives, resources, institutions, time, information/technology, external forces, feedback, and blind spots. Satellites are not automatically axes or causes.
- **Subproblem partitions:** atomic questions with their own boundaries, axes, dependencies, and links to shared satellite factors.
- **Relation graph:** typed links from satellites to the core problem, other satellites, subproblems, and axes. A causal link is a hypothesis with a mechanism and counterevidence path, not a fact merely because it is written as an edge.

## Breadth versus confidence

Observation coverage is recorded categorically (`SCANNED`, `PARTIAL`, `NOT_SCANNED`, `NOT_APPLICABLE`). Confidence is not computed from coverage. A broad scan can reveal more unknowns; it cannot by itself increase certainty. Keep coverage gaps, source quality, independence, uncertainty, and claim status as separate fields.

## Causality discipline

Relation types distinguish `CAUSES`, `ENABLES`, `CONSTRAINS`, `MEDIATES`, `MODERATES`, `CORRELATES_WITH`, `INDICATES`, `REACTS_TO`, `COMPETES_WITH`, `FEEDBACK_TO`, and `SHARES_DEPENDENCY_WITH`. Causal hypotheses must include a plausible mechanism, relevant time scope, evidence references, alternative explanations, and disconfirmers. Correlation and chronology do not establish causation.

## Actor-goal discipline

For a stakeholder/actor, keep declared goals, observed actions, resource allocation, observed outcomes, and plausible incentives separate. Public statements are evidence of what was said, not proof of inner intent. Inconsistency may be explained by deception, but also by capability limits, external constraints, time lag, changed priorities, mixed goals, or unintended outcomes. Record several hypotheses where warranted; do not infer mental states as facts or invent motive scores.

## Problem Separation Firewall

When a task contains multiple goals, entities, time horizons, or standards, split it into atomic subproblems first. The default is `KEEP_SEPARATE` or `LINK_ONLY`. Shared factors can have common satellite IDs while each subproblem retains its own evidence ledger and conclusion. Cross-problem transfer requires an explicit relation and evidence; it is not allowed merely because the topics are adjacent in text. Merging is a proposal, and any change to approved scope/objective/critical criteria requires human re-approval and a new Problem Box version.

## ChatGPT operating sequence

1. **Pin the core:** restate the central question, target, entity, time horizon, and success condition.
2. **Partition:** list subquestions and mark which must remain separate.
3. **Orbit scan:** scan relevant satellite categories broadly; mark unobserved areas. Do not fill irrelevant categories for completeness theatre.
4. **Link:** add typed relations and explicit causal mechanisms; mark unproven links as hypotheses.
5. **Compare:** for actors, compare declarations, actions, resources, outcomes, and plausible objectives.
6. **Deepen selectively:** refine only material or decision-relevant factors. Observation expansion is distinct from coordinate resolution.
7. **Contamination audit:** check whether an assumption, source, time horizon, or conclusion leaked from one subproblem to another.
8. **Converge conditionally:** state findings, counterevidence, remaining gaps, and the next discriminating observation. Do not force one explanation.

## Data contract

The optional `satellite_map` in an ICC bundle is descriptive/analytical metadata. It is linked to one Problem Box version and may reference approved axes and evidence records. It cannot authorize scope expansion, change a critical axis, satisfy a critical gate by itself, authenticate a source, or approve itself. Unknown references and version mismatches are rejected by the deterministic validator.

## Non-goals

This layer does not read hidden motives, discover all causal factors, prove causal links, guarantee exhaustive observation, calculate calibrated probability, or prevent all LLM context errors. The prompt instructs separation and audits; Python validates schema/reference integrity only. Live ChatGPT behavior remains untested.
