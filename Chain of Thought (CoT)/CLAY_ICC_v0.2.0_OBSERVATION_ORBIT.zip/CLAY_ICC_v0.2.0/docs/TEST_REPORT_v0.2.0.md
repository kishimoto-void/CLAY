# ICC v0.2.0 Test Report

**Test date:** 2026-11-07  
**Runtime:** Python 3.13.5  
**Package state:** specialist reference implementation / working design draft  
**Test scope:** local structural validation, schema conformance, prompt compilation, satellite-map references, and CLI checks

## Results

| Check | Result |
|---|---|
| Unit and integration tests | PASS — 72 tests (including v0.2.0 satellite/separation tests) |
| Python bytecode compilation (`compileall`) | PASS |
| Existing approved sample bundle validation | PASS |
| Satellite-map example bundle validation | PASS |
| JSON Schema conformance | PASS — all packaged schemas checked by the test suite |
| Japanese prompt compilation | PASS |
| English prompt compilation | PASS |
| Optional satellite map summary | PASS — coverage categories remain separate from confidence |
| BTM v0.2.0 control compatibility | PASS — inherited tests retained |

## v0.2.0 properties exercised

- Satellite-map IDs, enums, and references are checked against the current Problem Box, axis set, and evidence records.
- A satellite map bound to another Problem Box version is rejected.
- A causal relation marked `SUPPORTED` requires linked `VERIFIED` + `SUPPORT` evidence metadata.
- Subproblem self-dependencies and dependency cycles are rejected. Feedback loops belong in the typed relation graph, not in the subproblem dependency DAG.
- Malformed/unhashable cross-references fail closed rather than raising an uncaught exception.
- Coverage summary reports `SCANNED`, `PARTIAL`, `NOT_SCANNED`, and `NOT_APPLICABLE` counts without converting them to certainty or completeness scores.
- Japanese and English prompts include satellite observation, the Problem Separation Firewall, causality safeguards, and actor declaration/action/resource/outcome separation.

## Important limitations

- No live ChatGPT or other target-LLM behavioral test was run. The prompt can guide separation but cannot guarantee the model will never blend issues.
- The Python reference implementation validates record structure and references; it does not prove that observations are true, causal links are valid, or sources are independent.
- The satellite coverage ledger is user/model-declared metadata; it does not prove exhaustive observation.
- Actor-goal records compare statements, actions, resources, and outcomes. They do not reveal private intent or mental states.
- No production Host authentication, signed approvals, persistent event store, external evidence retrieval, statistical calibration, or autonomous orchestration is implemented.

**Conclusion:** the updated reference package passes its local structural and schema test suite. This does not establish target-LLM compliance, factual correctness, causal validity, professional certification, or production readiness.
