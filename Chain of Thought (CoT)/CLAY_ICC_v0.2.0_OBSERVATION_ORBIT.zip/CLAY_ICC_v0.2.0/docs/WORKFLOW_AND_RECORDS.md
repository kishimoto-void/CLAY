# ICC Workflow and Record Model

## Proposed lifecycle

`INTAKE -> BOX_FORMATION -> BOX_REVIEW -> AXIS_PROPOSAL -> AXIS_REVIEW -> PLANNING -> DIFFUSION / EVALUATION / CONVERGENCE -> RECOVERY / REFRAMING -> HANDOFF`

This is a reference workflow, not an autonomous orchestration runtime. The state-transition guard checks allowed edges and approval prerequisites; the Host owns persistent state and user interaction.

## Phase discipline

Move from macro to micro only when justified:
1. Concept / Problem Formation
2. Architecture
3. Specification
4. Implementation / Verification

These are adjustable working stages, not mandatory fixed phases for every task. Maintain local refinement where defects are local and revalidate dependent areas when changes propagate.

## Axis record

Every axis includes:
- stable axis ID and versioned axis-set reference;
- definition and explicit exclusions;
- objective / success-criterion linkage;
- kind: CRITICAL, CONDITIONAL, FLEXIBLE, EXPLORATORY;
- priority: P0-P3;
- negotiability: LOCKED, HUMAN_REAPPROVAL, FLEXIBLE;
- measurement method, pass condition, dependencies;
- human approval status.

Priority describes importance. Negotiability describes change control. These must not be collapsed into one score.

## Evidence record

Each record maps an atomic claim to an axis and records source, provenance, relation, independence group, scope, uncertainty, verification status, and optional observation time. The `independence_group_id` identifies evidence sharing an underlying source or dependency. A group count is a metadata summary, not an assessment of source quality.

## Evaluation logic

1. Structural validity and Problem Box/axis approval.
2. Critical axes and hard constraints.
3. Flexible/conditional criteria among candidates that pass non-compensatory gates.
4. Contradictions, missing measures, uncertainty, and residuals.
5. Provisional convergence or human handoff.

No arithmetic average is used to override a critical gate. This reference implementation does not rank all candidate designs or compute an optimum.

## Versioning and revision

Do not overwrite an approved Problem Box or axis set when the objective/boundary/critical structure changes. Create a new version, record the reason and dependency impact, and obtain human re-approval. Historical records should remain attributable to the version that produced them.

## Handoff capsule template

See `examples/handoff_capsule.template.json`. The minimum handoff states: Problem Box and axis versions; approvals; current phase; findings; evidence and counterevidence; critical and hard-gate states; assumptions; unresolved questions; residuals; not-executed checks; minimum next action; human approvals required.

## Provisional diffusion scale

The prompt defines D0-D4 as working labels: D0 direct/narrow check; D1 adjacent causes; D2 related dependency region/alternatives; D3 multiple perspectives across the approved box; D4 broad or cross-domain exploration still inside the approved box. These are not deterministic thresholds or a fixed classifier. The target LLM must explain why the breadth is appropriate, and no level authorizes out-of-box work.
