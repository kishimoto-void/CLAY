# ICC Boundaries, Non-Goals, and Authority Model

## 1. Boundary matrix

| Concern | ICC core | BTM | Host / human | Separate specialist / authority |
|---|---|---|---|---|
| Instruction lifecycle and fidelity | Consumes baseline | Owner | Enforces source authority | — |
| Task rigor and general scope behavior | Applies to ICC phases | Owner of general controls | Grants actual runtime permissions | — |
| Problem Box | Owner of structure and checks | Not responsible | Human approves; Host verifies approval | Domain expert checks external validity |
| Coordinate axes | Proposes and validates structure | Not responsible | Human selects and locks | Domain expert may advise |
| Critical-axis gates | Analyzes declared statuses | Generic principle only | Human defines criticality | Independent verification where needed |
| Evidence register | Organizes declared evidence | Not responsible | Host retrieves/preserves sources | Domain sources / experts verify evidence |
| Truth / certification | Does not certify | Does not certify | Accountable human/organization | Qualified authority / accredited process |
| Tool / physical execution | No | No | Host authorization and execution | Tool-specific controls |
| Destructive testing | Excluded | Excluded | Explicit authorization required | Separate isolated test module |
| Persistence / memory | No automatic persistence | No automatic persistence | Host storage lifecycle | — |

## 2. ICC is a process specialist, not a universal domain expert

ICC specializes in problem framing, system decomposition, evaluation-coordinate design, evidence traceability, decision gates, iteration control, and handoff. It does not by itself supply validated competence in every engineering or regulated domain.

For high-consequence work, the Problem Box must identify required domain experts, applicable standards/jurisdiction, external test facilities, independent review, and required approvals. A target LLM's confident explanation is not professional certification.

## 3. Permission boundary

- A manifest, schema, prompt, profile, status field, or approval string is not a permission token.
- ICC cannot authorize external access, tool use, experiments, deployment, or physical operations.
- Host-side identity and authorization checks are mandatory before consequential execution.
- A user-approved scope change does not override platform rules, law, contracts, safety controls, or third-party rights.

## 4. Human decision points

Human approval is required for:
- locking the Problem Box;
- locking initial axes;
- adding/removing/redefining critical axes;
- changing objective, scope, exclusion, or hard constraints;
- accepting a material reframe;
- authorizing consequential tests or external operations;
- accepting final design decisions where the human/organization owns the risk.

## 5. Out of scope

- Truth engine, universal optimizer, autonomous designer, or guaranteed best-answer machine.
- General-purpose personality layer or replacement for BTM.
- Autonomous agent / background monitor / persistent memory service.
- Medical diagnosis, legal opinion, investment recommendation, certification, or regulated professional approval.
- Physical actuation, live deployment, penetration, stress testing, or destructive execution.
- Claims of inspecting hidden model state or exposing private chain-of-thought.

## 6. Fail-safe defaults

Unapproved Problem Box or axis set => no formal evaluation.
Missing or failed critical axis => no feasibility claim.
Failed hard constraint => candidate blocked.
Contradictory material evidence => preserve conflict; no unqualified PASS.
Out-of-scope requirement => stop affected work and request approval.
Missing prerequisite => ask for the minimum information needed.
Resource limit => report partial/inconclusive state; do not imply completion.
