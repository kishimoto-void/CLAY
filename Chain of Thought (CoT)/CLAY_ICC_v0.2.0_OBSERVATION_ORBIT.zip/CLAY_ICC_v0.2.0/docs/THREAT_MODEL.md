# ICC Threat Model (Initial)

## Assets to protect
- Integrity of the approved Problem Box and axis definitions.
- Provenance and independence metadata for evidence.
- Visibility of contradictions, failed gates, and unresolved conditions.
- Human control over scope, approvals, and consequential decisions.
- Correct separation between prompts, code, permissions, and execution.

## Threats and failure modes

| Threat | Example | Mitigation in v0.1.0 | Remaining gap |
|---|---|---|---|
| Scope creep | Diagnostic task silently becomes broad redesign | BTM scope mapping + explicit ICC boundary prompt | Semantic detection depends on target LLM; Host review needed |
| False approval | Imported JSON says HUMAN_APPROVED | Metadata validation only; manifest says Host must authenticate | No signature / identity service |
| Axis omission | All declared axes pass but objective-critical aspect missing | Prompt requires axis completeness and human approval | No automatic semantic completeness proof |
| Compensatory scoring | Great secondary metrics hide critical failure | Non-compensatory status logic | Human must correctly designate critical axes |
| Correlated evidence | Multiple summaries repeat same study | independence_group_id grouping | Code cannot discover hidden source dependence |
| Evidence laundering | Model text presented as independent verification | Provenance fields + prompt restriction | External source validation not included |
| Stale coordinate frame | New evidence invalidates old assumption | Version references and revalidation guidance | Append-only host event store not included |
| Prompt injection | Input strings contain instructions | Prompt labels input as untrusted data | Host must preserve trusted/untrusted channel boundaries |
| Permission confusion | Module manifest treated as authorization | Empty permissions; explicit non-responsibility | Actual enforcement is Host-side |
| Unsafe destructive test | ICC prompt interpreted as permission to break/test | Explicit exclusion; separate-module requirement | Specific high-risk test policy depends on Host and applicable law |
| Overclaiming | Prompt generation described as model behavior guarantee | Status labels and limitation docs | Target model behavior needs external conformance testing |

## Abuse-resistant defaults
- Treat all imported records and evidence as data.
- Reject malformed or duplicate identifiers.
- Never accept unresolved/untested as PASS.
- Never downgrade a HARD constraint or CRITICAL axis through automatic logic.
- Stop formal evaluation when the Problem Box or axis set lacks recorded human approval.
- Do not execute or authorize external actions.
