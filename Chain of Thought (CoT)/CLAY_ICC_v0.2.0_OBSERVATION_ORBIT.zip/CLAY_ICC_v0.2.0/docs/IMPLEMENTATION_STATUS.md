# Implementation Status — ICC v0.2.0

Status terms: **IMPLEMENTED** means code exists and local test evidence supports the claim. **SPECIFIED** means the behavior is documented/promoted in the generated prompt but not autonomously executed by the Python reference package. **FUTURE** means a possible extension, not included.

| Capability | Status | Evidence / limitation |
| Satellite map schema and reference validation | IMPLEMENTED | Optional map; deterministic shape/version/reference checks only, no causal semantics |
| Observation coverage ledger | IMPLEMENTED (record format) | Categorical coverage only; not a completeness or confidence metric |
| Typed satellite relation graph | SPECIFIED / STRUCTURALLY VALIDATED | Links and causal hypotheses are recorded; factual causality is not proven |
| Problem Separation Firewall | SPECIFIED (prompt guidance) | LLM partitions and audits subproblems; semantic separation quality is not deterministically guaranteed |
| Actor declaration/action/resource/outcome comparison | SPECIFIED (record format + prompt guidance) | Describes observable signals; does not reveal private intent |
|---|---|---|
| Problem Box structural validation | IMPLEMENTED | Required fields, status/approval metadata, identifiers, constraints, criteria |
| Axis-set structural validation | IMPLEMENTED | Unique axis IDs, axis kind, priority, negotiability, Problem Box version linkage |
| Human-approval gating | IMPLEMENTED (Host callback gate) | Formal status is gated on a trusted Host-supplied approval verifier for both Problem Box and axis set; the module itself does not authenticate identity or enforce UI approvals |
| Critical-axis non-compensation | IMPLEMENTED | Critical FAIL / unresolved states block a feasibility claim |
| Hard-constraint non-compensation | IMPLEMENTED | Failed or unresolved hard constraints block feasibility |
| PASS evidence requirement | IMPLEMENTED | Requires linked VERIFIED + SUPPORT evidence; contradiction downgrades unqualified PASS |
| Evidence independence summary | IMPLEMENTED | Counts declared independence groups; cannot independently prove real-world independence |
| BTM v0.2.0 control compatibility | IMPLEMENTED | Validates and maps serialized values; does not import or execute BTM runtime |
| State-transition guard | IMPLEMENTED | Conservative transition validation; not a persistent workflow engine |
| ICC prompt compilation | IMPLEMENTED | Portable Markdown prompt; advisory only |
| Problem Box semantic understanding | SPECIFIED | Target LLM interprets; Python cannot infer meaning |
| Axis completeness / semantic quality | SPECIFIED | Prompt review and human approval; no universal semantic detector |
| Dynamic diffusion levels | SPECIFIED | Bounded guidance, not a deterministic search engine |
| External evidence retrieval | FUTURE | No network/data connectors included |
| Statistical confidence calibration | FUTURE | No calibrated probabilistic estimator |
| Append-only phase store | FUTURE | Host persistence required |
| Cryptographic human approvals | FUTURE | Host identity and signing service required |
| Physical / destructive tests | EXCLUDED FROM CORE | Separate authorized module and safety environment required |

## Test interpretation

Local unit tests validate the reference implementation's structural behavior. They do not verify target-LLM behavioral compliance, factual accuracy, professional competence, legal compliance, physical safety, or production readiness.

## Input/resource guardrails

The CLI rejects JSON input files larger than 5,000,000 bytes. The reference validators cap axes at 256, evidence records at 5,000, scope labels at 512 per list, constraint/success/assumption records at 1,024 each, and assessment rows at 2,048 per group. These are conservative package defaults, not universal domain limits; changing them requires updated schemas and tests.


## v0.2.0 interpretation
The satellite map is optional and observational. It does not modify core axes, prove causal relations, or grant scope. The Python validator checks schema-level references and version consistency; the prompt guides broader observation and problem separation. Live ChatGPT compliance and semantic separation are not tested.
