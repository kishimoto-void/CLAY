# ICC Test Plan v0.2.0

## Unit / structural tests
- Schema shape, required fields, enums, unique identifiers, and safe types.
- Problem Box approval metadata and axis-set version linkage.
- Hard-constraint and critical-axis incompatibility checks.
- Evidence and assessment cross-reference integrity.
- PASS evidence requirements and contradiction handling.
- Independence-group de-duplication.
- BTM v0.2.0 enum compatibility, omitted-field defaults, and rigor/scope orthogonality.
- State transitions and re-approval requirements.
- Scope-change and axis-change re-approval flags.
- Japanese/English prompt compilation and untrusted-input marking.

## Red-team / destructive-input cases

| ID | Attack / malformed condition | Expected behavior |
|---|---|---|
| ICC-RT-01 | Duplicate axis IDs | Reject structurally |
| ICC-RT-02 | Unknown axis reference in evidence | Reject structurally |
| ICC-RT-03 | Unknown evidence reference in assessment | Reject structurally |
| ICC-RT-04 | CRITICAL axis marked FLEXIBLE | Reject structurally |
| ICC-RT-05 | HARD constraint marked FLEXIBLE | Reject structurally |
| ICC-RT-06 | Locked axes while Problem Box is draft | Reject structurally |
| ICC-RT-07 | Critical axis FAIL while flexible axes PASS | Block candidate; no compensation |
| ICC-RT-08 | Critical axis NOT_EXECUTED | Feasibility not established |
| ICC-RT-09 | PASS without VERIFIED SUPPORT evidence | Downgrade to INCONCLUSIVE |
| ICC-RT-10 | Linked CONTRADICT evidence with PASS | Downgrade unqualified PASS |
| ICC-RT-11 | Multiple records share one independence group | Count as one declared independent group |
| ICC-RT-12 | `RIGOROUS + BOUNDED` BTM control | Increase verification depth only; do not expand scope |
| ICC-RT-13 | USER_EXPANSION_REQUESTED | Require revised human-approved Problem Box before out-of-box work |
| ICC-RT-14 | Reframing without human re-approval | Reject transition |
| ICC-RT-15 | Prompt data contains instruction-like injection text | Keep it inside marked untrusted JSON data section |
| ICC-RT-16 | Approval string claims HUMAN_APPROVED | Treat as metadata only; Host authentication remains mandatory |
| ICC-RT-17 | Invalid/unhashable control enum | Return validation error, no exception escape |
| ICC-RT-18 | No CRITICAL axis declared | Refuse to claim feasibility; raise human review issue |

## Not covered by local tests

- Natural-language semantic accuracy of an LLM.
- Whether a model follows the generated prompt in live operation.
- Real-world evidence authenticity or true source independence.
- Actual human identity/approval authentication.
- Domain expert correctness, standards conformance, legal compliance, or physical safety.
- Host permission enforcement, persistent event storage, or production deployment.


## v0.2.0 satellite / separation tests
- Optional satellite-map schema, unique IDs, required fields, and enums.
- Problem Box ID/version linkage.
- Satellite-to-evidence, satellite-to-axis, subproblem-to-satellite, and relation endpoint reference integrity.
- SUPPORTED causal relation requires linked evidence references.
- Unknown references and self-dependencies fail closed.
- Observation breadth is reported categorically and never converted to a confidence score.
- Prompt compilation contains the Problem Separation Firewall, causality caution, and actor statement/action/outcome distinction in Japanese and English.
- Malformed/unhashable satellite, subproblem, and relation references fail closed without uncaught exceptions.
