# Open Design Questions — Deliberately Not Frozen in v0.1.0

These items were not silently converted into mandatory architecture. They remain candidates for later design and testing.

1. **Coordinate mathematics:** how to distinguish purely evaluative axes from mathematically independent dimensions when a task needs a numeric coordinate model.
2. **Sweet Spot / tolerance region:** how to represent a feasible region, bounds, uncertainty, and non-convex or empty intersections without creating false numerical precision.
3. **Residual vector:** how to normalize residuals across axes with different units and measurement scales.
4. **Evidence calibration:** how to estimate evidence reliability and independence using validated, domain-specific methods rather than relying only on declared metadata.
5. **Hypothesis mutation / Error Recycling:** what rules safely derive the next candidate hypothesis from failure or residual data.
6. **Meta-Observer roles:** whether Anchor, Independence, Contradiction, Dynamics, and Resource observers should be separate submodules or review passes.
7. **Branching Cognition:** how many parallel hypotheses or branches are justified under a resource budget.
8. **D0-D4 calibration:** how to map uncertainty, scope, complexity, and risk into diffusion levels; current labels are provisional and not computed by the code.
9. **Phase granularity:** whether Concept / Architecture / Specification / Implementation is enough or should be problem-adaptive.
10. **Append-only history:** event-store contract, revision identifiers, rollback semantics, and retention policy.
11. **Host approval attestation:** signature format and the exact `approval_verifier` contract for a production CLAY Host.
12. **Domain adapters:** specialized adapters for physical AI, control systems, software assurance, and other domains require independent review and evidence calibration.
13. **Stop/resource governor:** budgets for token use, time, iteration count, human review load, and tool costs.
14. **Independent model review:** how to use multiple LLMs without treating model count or majority agreement as truth.

Any later adoption should state the problem it solves, implementation cost, new failure modes, evidence needed, and whether human approval is required. No feature in this list is implied to exist in v0.1.0.
