# ICC v0.1.0 Test Report

**Test date:** 2026-11-07  
**Runtime:** Python 3.13.5  
**Package state:** specialist reference implementation / working design draft  
**Test scope:** local structural, policy, analysis, prompt-compilation, and JSON Schema tests

## Results

| Check | Result |
|---|---|
| Unit and integration tests | PASS — 60 tests |
| Python bytecode compilation (`compileall`) | PASS |
| Example bundle structural validation | PASS |
| Japanese prompt compilation | PASS |
| English prompt compilation | PASS |
| BTM v0.2.0 control profile validation | PASS |
| Example analysis generation | PASS — formal evaluation correctly remains blocked without Host approval verifier |
| JSON Schema conformance tests | PASS — included in the 60-test suite |
| CLI command registration/help | PASS |

## Tested properties

- Problem Box and axis-set records reject malformed fields, invalid enums, duplicate IDs, broken dependencies, and version mismatches.
- Locked axes require a human-approved Problem Box.
- CRITICAL axes and HARD constraints cannot be marked FLEXIBLE.
- A missing critical axis prevents feasibility claims.
- CRITICAL failure and HARD constraint failure are non-compensatory.
- PASS requires linked declared VERIFIED + SUPPORT evidence; contradiction prevents an unqualified PASS.
- Evidence records sharing an independence group are not counted as independent confirmations.
- Approval metadata alone does not satisfy formal approval gates; both Problem Box and axis-set approvals require Host callback verification.
- A Host verifier exception fails closed.
- BTM v0.2.0 rigor and scope controls remain orthogonal: RIGOROUS + BOUNDED increases checking depth without authorizing broader scope.
- USER_EXPANSION_REQUESTED still requires a revised, human-approved Problem Box before out-of-box work.
- Coordinate Resolution and Coordinate Expansion are distinguished by parent-axis linkage.
- Reframing, objective changes, and critical-axis edits require re-approval.
- Prompt compilation keeps input payloads in an explicitly untrusted data section; embedded backticks cannot terminate the Markdown fence.
- Invalid BTM profiles and unsupported languages are rejected.

## Example interpretation

`examples/approved_sample_bundle.json` is invented demonstration data. Its `HUMAN_APPROVED` values are explicitly demo metadata, not real approval events. The standalone CLI does not have a Host identity/approval service; therefore `examples/analysis_preview.json` correctly reports `NOT_READY_FOR_FORMAL_EVALUATION` with both approval gates `DECLARED_NOT_HOST_VERIFIED`.

## Not tested / not claimed

- No live ChatGPT, Claude, Gemini, or other provider behavior test was run.
- No guarantee is made that a target LLM will follow the generated prompt.
- No natural-language semantic Problem Box or axis-completeness benchmark was run.
- No external evidence authenticity, factual correctness, source independence, or uncertainty calibration was established.
- No production Host authentication, signed approval, permission enforcement, persistent event store, tool runner, experiment engine, or deployment was implemented.
- No domain expert certification, engineering safety certification, legal review, or regulated-use approval is claimed.

**Conclusion:** the local reference package passed its deterministic test suite. This establishes only the tested structural and control behavior of this implementation in the stated environment, not general reasoning quality, model compliance, factual correctness, or production readiness.
