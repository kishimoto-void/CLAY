# MODULE — CLAY Iterative Coordinate Convergence (ICC)

## Identity
- Module ID: `clay.specialist.icc`
- Version: `0.2.0`
- Type: `specialist_thinking_module`
- Status: reference implementation / working design draft
- BTM baseline: `clay.basic-thinking >= 0.2.0`

## Responsibility
ICC provides specialist process structure for finite problem formation, human-approved problem-specific axes, critical-axis and hard-constraint gates, coordinate resolution/expansion, evidence organization, bounded cognitive dynamics, provisional convergence, purpose-preserving recovery, phase records, and human handoff.

## Non-responsibility
ICC does not certify truth, infer all user intent deterministically, provide domain-specific professional certification, grant permissions, execute tools or experiments, run destructive tests, control hidden model state, guarantee external model compliance, or persist records automatically.

## Inputs
- `problem_box`: `schemas/problem-box.schema.json`
- `axis_set`: `schemas/axis-set.schema.json`
- `evidence_records`: `schemas/evidence-record.schema.json`
- `assessments`: `schemas/assessments.schema.json`
- optional `satellite_map`: `schemas/satellite-map.schema.json`
- optional `btm_thinking_control`: BTM v0.2.0 serialized task control subset
- optional phase history / handoff metadata in host-owned storage

## Outputs
- validation issues
- provisional axis / hard-constraint status analysis
- evidence-independence summary
- optional satellite coverage / relation summary
- compiled ICC specialist prompt
- handoff capsule content for host persistence

## Python API
```python
from icc.validation import validate_problem_box, validate_axis_set, validate_bundle
from icc.analysis import analyze_bundle
from icc.policy import validate_btm_control, derive_process_guidance
from icc.prompt_compiler import compile_prompt
from icc.state_machine import validate_transition
```

## Authority
A recorded approval field is data, not proof of identity or authorization. The Host must verify the approving actor and enforce all permissions. ICC cannot approve its own Problem Box or axes. No manifest or prompt grants authority.

## Safe default
If the Problem Box or axis set is not human-approved, do not perform formal convergence. If a critical axis or hard constraint is untested or inconclusive, feasibility is not established. If a requested change crosses the approved boundary, stop the affected work and return a human-approval request.

## v0.2.0 observation layer
The optional Satellite Observation Map records surrounding factors and subproblem partitions. It broadens observation without changing the approved core axes. The default merge policy is to keep distinct questions separate or link them without merging.
