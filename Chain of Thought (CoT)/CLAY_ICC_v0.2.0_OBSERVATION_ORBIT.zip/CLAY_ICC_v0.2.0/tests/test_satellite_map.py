import json
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]

class SatelliteMapTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.bundle = json.loads((ROOT / "examples" / "satellite_map_bundle.json").read_text(encoding="utf-8"))
        cls.map = cls.bundle["satellite_map"]

    def test_valid_template_references(self):
        from icc.validation import validate_bundle
        self.assertEqual(validate_bundle(self.bundle), [])

    def test_unknown_evidence_reference_rejected(self):
        from icc.validation import validate_bundle
        bad = json.loads(json.dumps(self.bundle))
        bad["satellite_map"]["satellites"][0]["evidence_ids"] = ["EV-NOT-THERE"]
        self.assertTrue(any("unknown evidence reference" in e for e in validate_bundle(bad)))

    def test_unknown_relation_target_rejected(self):
        from icc.validation import validate_bundle
        bad = json.loads(json.dumps(self.bundle))
        bad["satellite_map"]["relations"][0]["to_id"] = "SUB-MISSING"
        self.assertTrue(any("unknown subproblem reference" in e for e in validate_bundle(bad)))

    def test_supported_causal_relation_requires_evidence(self):
        from icc.validation import validate_bundle
        bad = json.loads(json.dumps(self.bundle))
        bad["satellite_map"]["relations"][0]["hypothesis_status"] = "SUPPORTED"
        self.assertTrue(any("SUPPORTED relation requires linked VERIFIED SUPPORT evidence" in e for e in validate_bundle(bad)))

    def test_problem_version_mismatch_rejected(self):
        from icc.validation import validate_bundle
        bad = json.loads(json.dumps(self.bundle))
        bad["satellite_map"]["problem_box_version"] = "0.0.0"
        self.assertTrue(any("does not match Problem Box version" in e for e in validate_bundle(bad)))

    def test_subproblem_dependency_cycle_rejected(self):
        from icc.validation import validate_bundle
        bad = json.loads(json.dumps(self.bundle))
        bad["satellite_map"]["subproblems"].append({
            "subproblem_id": "SUB-SECOND", "label": "Second", "question": "A second question?",
            "boundary": "A separate boundary.", "relationship_to_core": "CONTEXT_ONLY",
            "merge_policy": "KEEP_SEPARATE", "linked_satellite_ids": [],
            "linked_axis_ids": [], "depends_on": ["SUB-MAINT"]
        })
        bad["satellite_map"]["subproblems"][0]["depends_on"] = ["SUB-SECOND"]
        self.assertTrue(any("dependency cycle" in e for e in validate_bundle(bad)))

    def test_unhashable_cross_references_fail_closed_without_exception(self):
        from icc.validation import validate_bundle
        bad = json.loads(json.dumps(self.bundle))
        bad["satellite_map"]["satellites"][0]["evidence_ids"] = [{"not": "an-id"}]
        bad["satellite_map"]["relations"][0]["from_satellite_id"] = ["SAT-SUPPLIER"]
        bad["satellite_map"]["subproblems"][0]["depends_on"] = [{"not": "an-id"}]
        errors = validate_bundle(bad)
        self.assertTrue(any("unknown evidence reference" in e for e in errors))
        self.assertTrue(any("unknown satellite reference" in e for e in errors))
        self.assertTrue(any("unknown reference" in e for e in errors))

    def test_analysis_reports_coverage_not_confidence(self):
        from icc.analysis import analyze_bundle
        result = analyze_bundle(self.bundle)
        summary = result["satellite_map_summary"]
        self.assertEqual(summary["coverage_counts"]["SCANNED"], 1)
        self.assertIn("not measure certainty", summary["interpretation"])

    def test_prompt_contains_separation_firewall_ja_and_en(self):
        from icc.prompt_compiler import compile_prompt
        ja = compile_prompt(self.bundle, language="ja")
        en = compile_prompt(self.bundle, language="en")
        self.assertIn("問題分離ファイアウォール", ja)
        self.assertIn("Problem Separation Firewall", en)
        self.assertIn("declared goals", en)

if __name__ == "__main__":
    unittest.main()
