import json
from pathlib import Path
import unittest

try:
    from jsonschema import Draft202012Validator
    from referencing import Registry, Resource
except ImportError:  # optional development dependency
    Draft202012Validator = None
    Registry = Resource = None

ROOT = Path(__file__).resolve().parents[1]


@unittest.skipIf(Draft202012Validator is None, "install clay-icc[schema-test] to run JSON Schema tests")
class SchemaTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.schemas = {p.name: json.loads(p.read_text(encoding="utf-8")) for p in (ROOT / "schemas").glob("*.json")}
        registry = Registry()
        for schema in cls.schemas.values():
            Draft202012Validator.check_schema(schema)
            if "$id" in schema:
                registry = registry.with_resource(schema["$id"], Resource.from_contents(schema))
        cls.registry = registry
        cls.bundle = json.loads((ROOT / "examples" / "approved_sample_bundle.json").read_text(encoding="utf-8"))

    def test_sample_bundle_schema(self):
        errors = list(Draft202012Validator(self.schemas["icc-bundle.schema.json"], registry=self.registry).iter_errors(self.bundle))
        self.assertEqual(errors, [])

    def test_component_schemas(self):
        pairs = [
            ("problem-box.schema.json", self.bundle["problem_box"]),
            ("axis-set.schema.json", self.bundle["axis_set"]),
            ("assessments.schema.json", self.bundle["assessments"]),
            ("satellite-map.schema.json", self.bundle.get("satellite_map", json.loads((ROOT / "examples" / "satellite_map.template.json").read_text(encoding="utf-8")))) ,
            ("btm-control-compat.schema.json", json.loads((ROOT / "examples" / "btm_rigorous_narrow.json").read_text(encoding="utf-8")))
        ]
        for name, data in pairs:
            with self.subTest(schema=name):
                self.assertEqual(list(Draft202012Validator(self.schemas[name]).iter_errors(data)), [])
        for evidence in self.bundle["evidence_records"]:
            self.assertEqual(list(Draft202012Validator(self.schemas["evidence-record.schema.json"]).iter_errors(evidence)), [])

    def test_bundle_accepts_optional_satellite_map(self):
        bundle = json.loads(json.dumps(self.bundle))
        satellite_map = json.loads((ROOT / "examples" / "satellite_map.template.json").read_text(encoding="utf-8"))
        satellite_map["satellites"][0]["axis_ids"] = [bundle["axis_set"]["axes"][0]["axis_id"]]
        satellite_map["subproblems"][0]["linked_axis_ids"] = [bundle["axis_set"]["axes"][0]["axis_id"]]
        bundle["satellite_map"] = satellite_map
        errors = list(Draft202012Validator(self.schemas["icc-bundle.schema.json"], registry=self.registry).iter_errors(bundle))
        self.assertEqual(errors, [])

    def test_satellite_map_bundle_schema(self):
        bundle = json.loads((ROOT / "examples" / "satellite_map_bundle.json").read_text(encoding="utf-8"))
        errors = list(Draft202012Validator(self.schemas["icc-bundle.schema.json"], registry=self.registry).iter_errors(bundle))
        self.assertEqual(errors, [])

    def test_analysis_result_schema_with_satellite_summary(self):
        from icc.analysis import analyze_bundle
        bundle = json.loads((ROOT / "examples" / "satellite_map_bundle.json").read_text(encoding="utf-8"))
        result = analyze_bundle(bundle)
        errors = list(Draft202012Validator(self.schemas["analysis-result.schema.json"], registry=self.registry).iter_errors(result))
        self.assertEqual(errors, [])

    def test_analysis_result_schema(self):
        from icc.analysis import analyze_bundle
        result = analyze_bundle(self.bundle)
        self.assertEqual(list(Draft202012Validator(self.schemas["analysis-result.schema.json"]).iter_errors(result)), [])

    def test_human_approval_requires_identity_metadata_fields(self):
        bad = json.loads(json.dumps(self.bundle["problem_box"]))
        bad["approval"] = {"status": "HUMAN_APPROVED"}
        errors = list(Draft202012Validator(self.schemas["problem-box.schema.json"]).iter_errors(bad))
        self.assertTrue(errors)

    def test_hard_constraint_cannot_be_flexible_in_schema(self):
        bad = json.loads(json.dumps(self.bundle["problem_box"]))
        bad["constraints"][0]["negotiability"] = "FLEXIBLE"
        errors = list(Draft202012Validator(self.schemas["problem-box.schema.json"]).iter_errors(bad))
        self.assertTrue(errors)

    def test_critical_axis_cannot_be_flexible_in_schema(self):
        bad = json.loads(json.dumps(self.bundle["axis_set"]))
        bad["axes"][0]["negotiability"] = "FLEXIBLE"
        errors = list(Draft202012Validator(self.schemas["axis-set.schema.json"]).iter_errors(bad))
        self.assertTrue(errors)


if __name__ == "__main__":
    unittest.main()
