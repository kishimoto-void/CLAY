# Implementation Notes — v0.1.0

## Deliberately not implemented yet

- Actual web search or business/provider retrieval.
- Official-source quality scoring or freshness guarantees.
- Mobile signal prediction at an exact building or room.
- Cost calculator for complex promotions, financing or multi-year contracts.
- OCR/document parsing and source-image verification.
- Jurisdiction-aware emergency and consumer-support directory.
- Persistent user preference storage.
- Any tool that contacts a third party or executes a transaction.

## Next recommended development sequence

1. **v0.1.1 — Output/evidence contract:** validate all evidence references in a `DecisionBrief`; ensure each material claim points to evidence or is marked as an assumption/unknown.
2. **v0.2.0 — Cost and condition model:** normalized one-time, recurring, introductory, optional and conditional costs; explicit comparison horizon.
3. **v0.3.0 — Retrieval adapters:** web/source adapter contracts with retrieval timestamp, source type, geographic scope and coverage limits.
4. **v0.4.0 — Domain test packs:** mobile, home appliances, lessons, subscriptions and high-pressure contracts.
5. **v0.5.0 — Adversarial evaluation:** vague goals, conflicting preferences, missing facts, misleading oral claims, promotional pricing, overconfident model inferences, and action-pressure prompts.

Do not add execution capability merely because retrieval works. If execution is ever considered, keep it as a separate optional extension with explicit preview and confirmation, and keep the information-only mode available.
