# 01 — Architecture

## 1. Three-part design contract

### Code: explicit and testable
- Data structures for goals, constraints, options, evidence and decision briefs.
- Workflow states and domain-specific material variables.
- Policy gates for evidence provenance and external side effects.
- Validation that can be tested without relying on natural-language interpretation.
- Decision-brief checks for human decision ownership, unique option IDs, evidence references and required status-quo alternatives.

### Prompt: conversational and adaptive
- How to understand the user's stated aim.
- How to ask one useful question at a time.
- How to explain technical terms in context.
- How to present trade-offs without steering.
- How to adapt depth and format to the user's level and request.

### Markdown: rationale and model-facing context
- Why each rule exists.
- What problem a rule is intended to prevent.
- What the system should do when information is incomplete.
- Which boundaries are design choices rather than universal truths.

The Markdown rationale is explanatory. It does not override code-level policy. The prompt is an instruction layer, not proof that a behavior is enforced. Code validators only enforce the fields and conditions they actually inspect.

## 2. Component view

```text
Conversation input
      │
      ▼
Intent & goal interpreter (LLM)
      │  structured Goal / context
      ▼
Workflow planner (code)
      ├── progressive clarification
      ├── domain profile selection
      ├── search requirement decision
      └── escalation / handoff decision
      │
      ▼
Information adapters (future integration)
      ├── official web/source search
      ├── document and quote extraction
      ├── local coverage / availability data
      └── public support directory
      │
      ▼
Evidence registry (code schema)
      │
      ▼
Option analysis & comparison (LLM + structured checks)
      │
      ▼
Decision Brief (JSON schema)
      │
      ▼
Human decision
```

## 3. Separation of concerns

- **Goal**: what the user wants to achieve.
- **Priority**: what the user values most (price, convenience, quality, support, style, etc.).
- **Constraint**: a condition that options must or should satisfy.
- **Context**: where and how the option will be used.
- **Evidence**: where a claim came from and how well it is verified.
- **Option**: a candidate, including benefits, drawbacks, conditions, costs and unknowns.
- **Decision brief**: the information presented back to the user.

Do not collapse these into a single opaque "preference score". A numerical fit score may hide value judgments and must not be introduced without an explicit, user-visible rubric.

## 4. Search strategy

Search current information when current facts materially affect the choice: prices, plans, coverage, availability, eligibility, warranties, cancellation terms, support channels, product specifications, class schedules, or local services.

Prefer primary sources for official terms. Use independent sources for context, not as substitutes for contract documents. State when source coverage is incomplete or stale.

## 5. Adapter boundary

Adapters are not implemented in v0.1.0. A future adapter must declare:
- source/provider and retrieval time;
- geographic and product/service scope;
- fields returned and fields not available;
- known coverage limitations;
- whether a result is official, user-provided, or third-party.

No adapter may silently turn an information request into an external side effect.
