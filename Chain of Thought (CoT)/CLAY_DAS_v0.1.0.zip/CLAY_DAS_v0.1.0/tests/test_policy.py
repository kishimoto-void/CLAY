import unittest

from clay_das.models import (
    ActionKind, DecisionBrief, Evidence, EvidenceKind, EvidenceStatus, Option
)
from clay_das.policy import (
    ActionRequest, PolicyViolation, validate_action_request,
    validate_decision_brief, validate_evidence
)


class PolicyTests(unittest.TestCase):
    def test_oral_claim_cannot_be_marked_corroborated(self):
        evidence = Evidence(
            evidence_id="E1",
            kind=EvidenceKind.ORAL_CLAIM,
            claim="The salesperson said cancellation is free.",
            status=EvidenceStatus.CORROBORATED,
        )
        with self.assertRaises(PolicyViolation):
            validate_evidence(evidence)

    def test_model_inference_cannot_be_marked_corroborated(self):
        evidence = Evidence(
            evidence_id="E2",
            kind=EvidenceKind.MODEL_INFERENCE,
            claim="This option is probably suitable.",
            status=EvidenceStatus.CORROBORATED,
        )
        with self.assertRaises(PolicyViolation):
            validate_evidence(evidence)

    def test_unrequested_action_is_rejected(self):
        request = ActionRequest(kind=ActionKind.RESERVATION)
        with self.assertRaises(PolicyViolation):
            validate_action_request(request)

    def test_action_without_preview_is_rejected(self):
        request = ActionRequest(
            kind=ActionKind.CONTACT,
            explicitly_requested_by_user=True,
            exact_action_previewed=False,
            separate_confirmation_received=True,
        )
        with self.assertRaises(PolicyViolation):
            validate_action_request(request)

    def test_action_requires_separate_confirmation(self):
        request = ActionRequest(
            kind=ActionKind.PURCHASE,
            explicitly_requested_by_user=True,
            exact_action_previewed=True,
            separate_confirmation_received=False,
        )
        with self.assertRaises(PolicyViolation):
            validate_action_request(request)

    def test_fully_confirmed_action_request_passes_gate_only(self):
        request = ActionRequest(
            kind=ActionKind.CANCELLATION,
            explicitly_requested_by_user=True,
            exact_action_previewed=True,
            separate_confirmation_received=True,
        )
        validate_action_request(request)  # This is a gate check, not an execution call.

    def test_decision_owner_must_be_user(self):
        brief = DecisionBrief(goal_statement="Choose a plan", options=(), decision_owner="system")
        with self.assertRaises(PolicyViolation):
            validate_decision_brief(brief)

    def test_commercial_comparison_can_require_status_quo(self):
        brief = DecisionBrief(
            goal_statement="Compare plans",
            options=(Option(option_id="A", name="Plan A"),),
        )
        with self.assertRaises(PolicyViolation):
            validate_decision_brief(brief, require_status_quo=True)

    def test_option_evidence_reference_must_exist(self):
        brief = DecisionBrief(
            goal_statement="Compare plans",
            options=(Option(option_id="A", name="Plan A", evidence_ids=("E404",)),),
        )
        with self.assertRaises(PolicyViolation):
            validate_decision_brief(brief)


if __name__ == "__main__":
    unittest.main()
