import unittest

from clay_das.models import Goal, RiskLevel, SessionState
from clay_das.workflow import plan_next_step


class WorkflowTests(unittest.TestCase):
    def test_no_goal_asks_for_goal(self):
        plan = plan_next_step(SessionState())
        self.assertEqual(plan.stage, "clarify_goal")
        self.assertTrue(plan.ask_one_question)

    def test_urgent_routes_before_clarification(self):
        plan = plan_next_step(SessionState(risk_level=RiskLevel.URGENT, missing_materials=("location",)))
        self.assertEqual(plan.stage, "urgent_handoff")
        self.assertFalse(plan.ask_one_question)
        self.assertTrue(plan.handoff)

    def test_only_one_missing_material_is_asked(self):
        state = SessionState(
            goal=Goal(statement="Find a cheaper mobile plan", domain="mobile_plan"),
            missing_materials=("coverage_at_home", "monthly_data_usage", "device_compatibility"),
        )
        plan = plan_next_step(state)
        self.assertEqual(plan.stage, "progressive_clarification")
        self.assertIn("coverage at home", plan.ask_one_question)
        self.assertNotIn("monthly data usage", plan.ask_one_question)

    def test_mobile_comparison_requires_current_retrieval_when_requested(self):
        state = SessionState(
            goal=Goal(statement="Compare cheap mobile plans", domain="mobile_plan"),
            user_asked_for_comparison=True,
        )
        plan = plan_next_step(state)
        self.assertTrue(plan.search_required)
        self.assertIn("official_coverage_map_for_user_locations", plan.search_targets)

    def test_goal_without_current_fact_need_can_explore_without_search(self):
        state = SessionState(goal=Goal(statement="I am thinking about learning flower arrangement", domain="lesson_or_class"))
        plan = plan_next_step(state)
        self.assertEqual(plan.stage, "explore_options")
        self.assertFalse(plan.search_required)


if __name__ == "__main__":
    unittest.main()
