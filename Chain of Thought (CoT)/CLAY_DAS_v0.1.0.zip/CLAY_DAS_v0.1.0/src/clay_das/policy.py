"""Policy gates for invariants represented explicitly in code."""

from dataclasses import dataclass

from .models import ActionKind, DecisionBrief, Evidence, EvidenceKind, EvidenceStatus


class PolicyViolation(ValueError):
    """Raised when a proposed structure violates a CLAY-DAS invariant."""


@dataclass(frozen=True)
class ActionRequest:
    kind: ActionKind
    explicitly_requested_by_user: bool = False
    exact_action_previewed: bool = False
    separate_confirmation_received: bool = False


def validate_evidence(evidence: Evidence) -> None:
    """Prevent an oral report from being silently represented as verified contract fact."""
    if evidence.kind is EvidenceKind.ORAL_CLAIM and evidence.status is EvidenceStatus.CORROBORATED:
        # Corroboration belongs to the evidence set, not to the oral statement alone.
        raise PolicyViolation(
            "An oral claim cannot itself be marked corroborated; add the written/official evidence separately."
        )
    if evidence.kind is EvidenceKind.MODEL_INFERENCE and evidence.status is EvidenceStatus.CORROBORATED:
        raise PolicyViolation(
            "A model inference is not a primary source. Keep it labelled as an inference."
        )


def validate_action_request(request: ActionRequest) -> None:
    """Gate future external side effects; v0.1.0 contains no execution adapter."""
    if not request.explicitly_requested_by_user:
        raise PolicyViolation("External action requires a distinct, explicit user request.")
    if not request.exact_action_previewed:
        raise PolicyViolation("The exact action and its details must be previewed before confirmation.")
    if not request.separate_confirmation_received:
        raise PolicyViolation("A separate confirmation is required after the preview.")


def validate_decision_brief(
    brief: DecisionBrief,
    *,
    evidence: tuple[Evidence, ...] = (),
    require_status_quo: bool = False,
) -> None:
    """Validate decision ownership, option identity and evidence references."""
    if brief.decision_owner != "user":
        raise PolicyViolation("The final decision owner must remain the user.")

    option_ids = [option.option_id for option in brief.options]
    if len(option_ids) != len(set(option_ids)):
        raise PolicyViolation("Option IDs must be unique within a decision brief.")

    if require_status_quo and not any(option.is_status_quo for option in brief.options):
        raise PolicyViolation("This comparison must include a status-quo / no-change option.")

    known_evidence_ids = {item.evidence_id for item in evidence}
    for item in evidence:
        validate_evidence(item)
    for option in brief.options:
        missing = set(option.evidence_ids) - known_evidence_ids
        if missing:
            raise PolicyViolation(
                f"Option '{option.option_id}' references unknown evidence IDs: {sorted(missing)}"
            )
