"""Interfaces for future information adapters; no network implementation here."""

from dataclasses import dataclass
from typing import Protocol, Tuple

from .models import Evidence


@dataclass(frozen=True)
class SearchRequest:
    query: str
    jurisdiction: str = ""
    geographic_scope: str = ""
    source_preference: str = "official_first"


@dataclass(frozen=True)
class SearchResult:
    evidence: Tuple[Evidence, ...]
    provider: str
    retrieved_at: str
    coverage_limitations: Tuple[str, ...] = ()


class SearchAdapter(Protocol):
    def search(self, request: SearchRequest) -> SearchResult:
        """Return source-labelled evidence and explicit retrieval limitations."""
        ...


class DocumentExtractionAdapter(Protocol):
    def extract(self, document_reference: str) -> Tuple[Evidence, ...]:
        """Return extracted claims, preserving uncertainty and original references."""
        ...


class PublicSupportDirectory(Protocol):
    def lookup(self, topic: str, jurisdiction: str) -> Tuple[Evidence, ...]:
        """Return jurisdiction-specific public support information from verified sources."""
        ...
