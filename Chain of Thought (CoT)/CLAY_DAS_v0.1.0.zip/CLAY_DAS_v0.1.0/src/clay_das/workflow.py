"""Deterministic first-pass workflow planning."""

from .models import RiskLevel, SessionState, WorkflowPlan
from .profiles import DOMAIN_PROFILES


def plan_next_step(state: SessionState) -> WorkflowPlan:
    """Return a small next-step plan; the LLM still interprets natural language."""
    if state.immediate_danger_indicated or state.risk_level is RiskLevel.URGENT:
        return WorkflowPlan(
            stage="urgent_handoff",
            handoff="Contact the appropriate emergency service for the user's jurisdiction now; follow the dispatcher's instructions.",
            explanation="Immediate safety takes priority over ordinary comparison. Do not delay with a long intake.",
        )

    if state.goal is None or not state.goal.statement.strip():
        return WorkflowPlan(
            stage="clarify_goal",
            ask_one_question="What are you hoping to achieve?",
            explanation="Do not invent a goal from an ambiguous or passing remark.",
        )

    domain = state.goal.domain if state.goal.domain in DOMAIN_PROFILES else "general"
    profile = DOMAIN_PROFILES[domain]

    if state.missing_materials:
        # Only the first material gap is raised. The conversation can then continue iteratively.
        first_gap = state.missing_materials[0].replace("_", " ")
        return WorkflowPlan(
            stage="progressive_clarification",
            ask_one_question=f"To compare this properly, could you tell me about {first_gap}?",
            compare_axes=tuple(profile["comparison_axes"]),
            explanation="Ask one material question at a time; do not turn the profile into a compulsory checklist.",
        )

    search_required = state.current_information_required or state.user_asked_for_comparison
    return WorkflowPlan(
        stage="retrieve_and_compare" if search_required else "explore_options",
        search_required=search_required,
        search_targets=tuple(profile["search_targets"]) if search_required else (),
        compare_axes=tuple(profile["comparison_axes"]),
        explanation=(
            "Retrieve current information and compare against the user's stated purpose and context."
            if search_required
            else "Explore relevant directions without assuming a commitment or forcing a formal comparison."
        ),
    )
