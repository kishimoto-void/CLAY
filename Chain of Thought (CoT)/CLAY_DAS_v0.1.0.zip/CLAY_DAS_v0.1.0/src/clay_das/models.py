"""Core data structures. Keep user intent, facts and model interpretation separate."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Mapping, Optional, Tuple


class Priority(str, Enum):
    MUST = "must"
    PREFER = "prefer"
    OPTIONAL = "optional"


class RiskLevel(str, Enum):
    ORDINARY = "ordinary"
    MATERIAL = "material"
    HIGH_STAKES = "high_stakes"
    URGENT = "urgent"


class EvidenceKind(str, Enum):
    OFFICIAL_SOURCE = "official_source"
    WRITTEN_TERM = "written_term"
    ORAL_CLAIM = "oral_claim"
    USER_OBSERVATION = "user_observation"
    THIRD_PARTY_REPORT = "third_party_report"
    MODEL_INFERENCE = "model_inference"


class EvidenceStatus(str, Enum):
    UNVERIFIED = "unverified"
    CORROBORATED = "corroborated"
    CONTRADICTED = "contradicted"
    UNKNOWN = "unknown"


class ActionKind(str, Enum):
    CONTACT = "contact"
    RESERVATION = "reservation"
    PURCHASE = "purchase"
    CONTRACT = "contract"
    CANCELLATION = "cancellation"
    DATA_SHARING = "data_sharing"


@dataclass(frozen=True)
class Requirement:
    name: str
    value: str
    priority: Priority = Priority.PREFER
    rationale: str = ""


@dataclass(frozen=True)
class Goal:
    statement: str
    desired_outcome: str = ""
    domain: str = "general"
    priorities: Tuple[str, ...] = ()
    requirements: Tuple[Requirement, ...] = ()
    context: Mapping[str, str] = field(default_factory=dict)
    # A user goal is not consent to execute an external action.


@dataclass(frozen=True)
class Evidence:
    evidence_id: str
    kind: EvidenceKind
    claim: str
    source_name: str = ""
    source_reference: str = ""
    retrieved_at: Optional[str] = None
    status: EvidenceStatus = EvidenceStatus.UNKNOWN
    notes: str = ""


@dataclass(frozen=True)
class Option:
    option_id: str
    name: str
    summary: str = ""
    benefits: Tuple[str, ...] = ()
    disadvantages: Tuple[str, ...] = ()
    costs: Tuple[str, ...] = ()
    conditions: Tuple[str, ...] = ()
    support_details: Tuple[str, ...] = ()
    fit_notes: Tuple[str, ...] = ()
    evidence_ids: Tuple[str, ...] = ()
    unknowns: Tuple[str, ...] = ()
    is_status_quo: bool = False


@dataclass(frozen=True)
class DecisionBrief:
    goal_statement: str
    options: Tuple[Option, ...]
    comparison_axes: Tuple[str, ...] = ()
    known_facts: Tuple[str, ...] = ()
    assumptions: Tuple[str, ...] = ()
    unresolved_questions: Tuple[str, ...] = ()
    mismatches: Tuple[str, ...] = ()
    next_steps: Tuple[str, ...] = ()
    decision_owner: str = "user"


@dataclass(frozen=True)
class SessionState:
    goal: Optional[Goal] = None
    risk_level: RiskLevel = RiskLevel.ORDINARY
    missing_materials: Tuple[str, ...] = ()
    user_asked_for_comparison: bool = False
    current_information_required: bool = False
    jurisdiction: str = ""
    immediate_danger_indicated: bool = False


@dataclass(frozen=True)
class WorkflowPlan:
    stage: str
    ask_one_question: str = ""
    search_required: bool = False
    search_targets: Tuple[str, ...] = ()
    compare_axes: Tuple[str, ...] = ()
    handoff: str = ""
    explanation: str = ""
