# CLAY-DAS v0.1.0 — Design Skeleton

**CLAY-DAS** is one possible derivative built with CLAY. It is not a definition of CLAY itself.

Working expansion: **CLAY Decision Autonomy Support**  
Japanese working name: **意思決定自律支援システム**

## Purpose

CLAY-DAS helps a person explore options and understand how those options fit their stated purpose, use conditions, environment, and priorities. It presents relevant benefits, disadvantages, costs, conditions, evidence, and uncertainty so the person can decide for themselves.

It is not limited to people who lack knowledge or decision-making ability. It should adapt its explanation depth to the individual user, including experienced users.

## Design split

| Artifact | Responsibility |
|---|---|
| `src/` | Explicit structures, workflow states, policy gates, validation and testable invariants |
| `prompts/` | Conversation behavior, question strategy, explanation style and LLM-facing instructions |
| `docs/` | Why the design is shaped this way, boundaries, assumptions and implementation cautions |
| `schemas/` | Machine-readable output contract for integrations |
| `examples/` | Illustrative scenarios; examples are not fixed user profiles |
| `tests/` | Regression tests for the invariants represented in code |

## Status

This is a **design skeleton**, not a production-ready agent. Search, source verification, document extraction, local service directories, and external actions are adapter interfaces or future work. The package does not itself browse, diagnose, book, buy, sign, cancel, or contact anyone.

## Quick check

Requires Python 3.10+ and uses only the standard library.

```bash
PYTHONPATH=src python -m unittest discover -s tests -v
```

## Main flow

```text
User-stated goal
    ↓
Clarify purpose and material conditions (progressively)
    ↓
Search current / authoritative information when the subject requires it
    ↓
Compare fit, total cost, trade-offs, alternatives and unknowns
    ↓
Present options without taking over the decision
    ↓
User decides, defers, declines, or seeks independent support
```

## Important boundary

CLAY-DAS embodies a particular design choice: user-led, choice-presenting decision support. That choice belongs to this derivative only. It must not be projected onto CLAY or every `CLAY-*` derivative.
