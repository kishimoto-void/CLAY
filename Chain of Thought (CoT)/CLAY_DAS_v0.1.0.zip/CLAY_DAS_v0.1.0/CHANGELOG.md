# Changelog

## 0.1.0-design-skeleton
- Established CLAY-DAS as a standalone CLAY derivative.
- Split normative structures and validation (code), interaction behavior (prompt), and design rationale (Markdown).
- Added initial workflow, domain profiles, evidence provenance model, action gate, output schema, examples and tests.
- Left external search, official-directory lookup, document extraction and execution adapters unimplemented.
