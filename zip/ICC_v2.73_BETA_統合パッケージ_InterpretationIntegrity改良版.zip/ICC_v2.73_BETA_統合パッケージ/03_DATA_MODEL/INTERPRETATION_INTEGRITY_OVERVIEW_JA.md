# ICC v2.73 Interpretation Integrity Layer — 実装ガイド

## 1. 目的と範囲

Interpretation Integrity Layer（解釈整合性レイヤー）は、ユーザー入力を解釈・要約・構造化する際に、元の表現とモデル側の解釈を混同しないための補助層である。ICCの新しい思考軸・認知モード・正式評価ゲートではなく、固定された逐次パイプラインでもない。必要性に応じて適用する。

6つの制御対象：

1. **Input Preservation** — 元の表現と用語を保持する。
2. **Semantic Fidelity** — ユーザー明示・モデル推定・提案・外部主張を区別する。
3. **Uncertainty Preservation** — 曖昧・暫定・未確認を確定化しない。
4. **Premature Structuring Control** — 未確認の体系を完成済みとして提示しない。
5. **Correction Propagation** — 訂正対象に依存する下流レコードを再確認対象にする。
6. **Assumption Provenance** — 前提の出所と確認状態を記録する。

## 2. データモデル

Schema: `schemas/icc-interpretation-record.schema.json`

主要フィールド：

- `verbatim_excerpt`：ソースの原文抜粋。要約・解釈で置換しない。
- `interpretation`：モデル側の解釈。
- `assertion_type`：USER_STATED / MODEL_INFERENCE / MODEL_HYPOTHESIS / MODEL_PROPOSAL等。
- `epistemic_status`：STATED / USER_CONFIRMED / PROVISIONAL / AMBIGUOUS / UNVERIFIED等。
- `fidelity_status`：NOT_ASSESSED / PRESERVED / POSSIBLE_DRIFT / CORRECTED。
- `structure_status`：UNSTRUCTURED / PROVISIONAL / USER_CONFIRMED / DEFERRED。
- `depends_on_record_ids`：この記録が明示的に依存する先行記録。
- `assumptions`：前提の文言、出所、確認状態。

`structure_status=USER_CONFIRMED`には`confirmation_ref`を必須とする。参照IDは確認の証拠を指すデータであり、本人性・権限の認証はHost責任である。

## 3. Python API

```python
from icc.interpretation_integrity import (
    create_interpretation_record,
    create_user_correction_record,
    append_interpretation_record,
    validate_interpretation_records,
)
```

- `create_interpretation_record(session, records, ...)`：元文・解釈・来歴・不確実性・構造状態を分離した新規レコードを作る。入力配列へは追加しない。
- `create_user_correction_record(session, records, target_record_id=..., corrected_text=..., reason=...)`：旧レコードを残したまま訂正レコードを作成する。`depends_on_record_ids`に明記された推移的な下流依存を再確認対象として列挙する。
- `append_interpretation_record(session, events, records, record)`：レコードを追加し、`INTERPRETATION_RECORDED`または`USER_CORRECTION_RECORDED`のCognitive Trace Eventを追記した新しい値を返す。
- `validate_interpretation_records(records, session=None)`：Schema、順序、参照先、セッション・枝、訂正対象と下流依存の整合性を検証する。

## 4. 訂正の波及

依存関係は呼び出し側が`depends_on_record_ids`へ明示する。訂正イベントは対象レコード、依存グラフから算出した下流レコード、再確認対象を記録する。旧レコードを上書きせず、再確認が済むまで下流結論を有効とみなすかどうかは利用側が判断する。

この計算は、明示された依存関係だけを対象とする。LLMの暗黙の推論依存を自動発見する機能ではない。依存リンクの記載漏れがあれば、影響範囲を取りこぼす可能性がある。

## 5. 明示的な限界

- 自然言語から意味の一致・不一致を自動判定する機能ではない。
- プロンプトは行動指針であり、対象LLMの遵守を保証しない。
- `PRESERVED`や`USER_CONFIRMED`は記録された状態であり、意味的正しさをコードが証明するものではない。
- Schema／Validatorが検査するのは構造・明示参照・順序・依存リンクであり、事実の真偽や暗黙の依存関係の完全性ではない。
- レコード作成はオプトインであり、全発話の自動保存や過去アーカイブ検索は行わない。
- DB永続化、同時書き込み、認証、署名付き監査ログ、Host検索制御は実装していない。

## 6. 検証

`tests/test_interpretation_integrity.py`では、元文と解釈の分離、不確実状態の保持、ユーザー確認参照の必須化、訂正の非破壊性、推移的な依存再確認、Cognitive Trace Event追記、不正な前方参照・影響範囲の拒否を検査する。

これらは決定論的なデータ処理テストであり、実際のLLMが意味を正確に理解することを示す実対話試験ではない。
