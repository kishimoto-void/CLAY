# v2.73 Data Model — 読み方と構造上の制約

## 1. 位置づけ

このフォルダーのJSON Schemaは、v2.73の会話モード・分岐・思考履歴をHostで扱う場合の**設計提案**である。CLAY_ICC v0.2.5の既存validator、CLI、prompt compilerへ接続していない。JSON Schemaの検証に合格しても、永続化・権限・履歴の追記専用性・自動検索の抑止が実装されたことにはならない。

## 2. ファイル

- `icc-cognitive-session.schema.json`：セッション全体の現在モード、枝一覧、未解決課題、正式評価状態、アーカイブ参照方針。
- `icc-trace-event.schema.json`：モード変更、枝作成、ロールバック、仮説・認識軸候補・証拠・評価・課題・解釈記録・ユーザー訂正の変化を記録するイベント。
- `icc-interpretation-record.schema.json`：原文抜粋とモデル解釈、主張の出所、不確実性、構造状態、前提の来歴、訂正の依存関係を分けて記録するオプトイン形式。
- `ICC_Cognitive_Trace_Archive_Template.md`：人間が保管・選別するMarkdown形式のセッション記録。
- `examples/`：構造理解とschema検証用の架空データ。

## 3. Schemaだけでは強制できない不変条件

Host実装では、JSON Schemaに加えて以下の意味的制約を検証する。

1. `active_branch_id`は`branches`内に存在し、そのstatusは`ACTIVE`である。
2. 1セッションにつき`ACTIVE`な枝は原則1つだけとする。
3. `parent_branch_id`と`origin_event_id`は同じセッション内の既存記録を参照し、branch graphに循環を作らない。
4. eventの`sequence`はセッション内で一意かつ単調増加する。
5. 過去イベントの訂正・撤回はレコード上書きではなく新しいイベントで表現する。
6. `formal_evaluation_state=ACTIVE`の場合、Problem Boxとaxis-setの参照が存在し、両方が必要な人間承認を通過していることをHostが確認する。
7. `cognitive_mode=EXPLORATION`は、正式評価状態を消去しない。正式評価を中断している場合は`PAUSED`等で保持する。
8. `archive_policy=MANUAL_ONLY`および`autoload_archived_traces=false`をHostが実際の検索・取得経路で守る。
9. ユーザーが指定していないアーカイブは、検索候補生成・embedding retrieval・背景ロードの対象にしない。
10. CLAY personalizationとCognitive Trace Archiveを別の参照ポリシー・保存領域として扱う。

## 4. データ最小化

イベントには必要な要約・参照IDを優先して保存し、完全な会話ログ・個人情報・巨大な資料本文を重複して埋め込まない。元資料は別ファイルで人間が管理し、trace eventから参照する。ユーザーが全文保存を依頼した場合のみ、保存範囲を明示して扱う。

## 5. 将来実装の注意

追記型イベントは「上書きしない」という運用ルールを示すが、暗号学的な改ざん防止を保証しない。必要ならHost側でアクセス制御、監査ログ、バージョン管理、バックアップ、保持期間、削除手続きを別途定義する。

## 6. v0.2.7 Cognitive Trace参照実装との接続（2026-11-15更新）

`06_IMPLEMENTATION_CLAY_ICC_v0.2.7/` に、このSchemaを扱うローカル参照実装を追加した。Session/Eventの構造検証に加え、active branch一意性、branch graph循環、event順序・参照整合、branch操作、open issue更新、明示指定されたJSONだけのMarkdown exportを実装している。

この接続はローカルの純粋ロジックとCLIに限る。HostのDB永続化、同時書込み制御、承認者認証、archive search/embedding retrievalの禁止、CLAY personalizationとの保存領域分離はまだ実装していない。Session/Event Schemaの妥当性やローカルテストPASSを、Host連携済み・独立対話検証済みと解釈しない。


## 7. Interpretation Integrity Layer（v2.73追加）

`icc-interpretation-record.schema.json`は、ユーザー入力の原文抜粋とLLM解釈を別フィールドで保持し、`assertion_type`、`epistemic_status`、`fidelity_status`、`structure_status`、`assumptions`を通じて出所・不確実性・構造の確定状態を区別する。ユーザー訂正は旧レコードを上書きせず、新しい訂正記録として表現する。下流の再確認対象は、明示的に記載された`depends_on_record_ids`から算出する。

このSchemaは意味の正しさを判定しない。暗黙の依存関係を発見する機能もない。自動的な全会話記録は行わず、利用側が明示的にレコードを作成した場合のみ使用する。Trace Eventには`INTERPRETATION_RECORDED`と`USER_CORRECTION_RECORDED`を追加。参照実装は`06_IMPLEMENTATION_CLAY_ICC_v0.2.7/`を参照。
