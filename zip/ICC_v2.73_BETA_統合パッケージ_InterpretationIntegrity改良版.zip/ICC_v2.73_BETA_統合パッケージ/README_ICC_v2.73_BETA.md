# ICC v2.73 Beta — 統合改良パッケージ

**状態：** Beta／仕様統合＋実装Phase 2（純粋ロジック）＋Interpretation Integrity Layer追加まで完了
**更新日：** 2026-11-15
**基準：** ICC v2.71、ICC v2.72 Beta、CLAY_ICC v0.2.5
**追加実装：** CLAY_ICC v0.2.7（v2.73 Cognitive Trace＋Interpretation Integrity参照実装候補）

## このパッケージの目的

ICC v2.7系の既存設計、v2.72の改良候補、CLAY_ICC v0.2.5の実装構造を引き継ぎ、自由探索／正式評価の認知モード、モード切替意図、思考ロールバックと分岐、未解決課題、抽象認識軸の具体化、双方向因果、対称的仮説評価、多視点、法的・倫理的整合性、思考履歴アーカイブ、人間主導の再投入、最小文脈、段階的開発を統合する。

v2.73に、CLAY_ICC v0.2.6のCognitive Trace純粋ロジックを追加し、今回の限定改良ではv0.2.7としてInterpretation Integrity Layerを追加した。既存v0.2.5は基準実装として変更せず保存している。

## 重要な版番号の区別

| 版 | 意味 |
|---|---|
| ICC v2.73 Beta | 会話運用・思考設計の統合仕様 |
| CLAY_ICC v0.2.5 | 既存Python基準実装。ベースラインとして保持 |
| CLAY_ICC v0.2.6 | v2.73 Cognitive Traceの純粋ロジック参照実装候補（前版） |
| CLAY_ICC v0.2.7 | Interpretation Integrity Layerを追加した更新実装候補 |
| Host integration | 永続化・認証・権限・検索制御。未実装 |

## 主な成果物

- `01_SPEC/` — v2.73統合仕様
- `02_PROMPTS/` — 統合システムプロンプト、モード切替・ロールバック運用表
- `03_DATA_MODEL/` — Cognitive Session / Trace Event / Interpretation Integrity JSON Schema、使用例、Markdown Archive template
- `04_IMPLEMENTATION_PLAN/` — v2.5との互換性、Phase 2の実装結果、Host連携計画
- `05_VERIFICATION/` — ケースベース整合性チェック、実行済みテストと未検証項目
- `06_IMPLEMENTATION_CLAY_ICC_v0.2.7/` — 既存ICC実装を保持したv2.73用追加コード、CLI、テスト
- `07_DISTRIBUTION/` — インストール用Python wheel
- `00_BASELINE_v2.72_BETA/` — v2.72 Beta資料とCLAY_ICC v0.2.5を変更せず保持

## 中心となる設計判断

1. 認知モードは既存の拡散／収縮、厳密度、scope、6ダイヤルと別レイヤー。
2. 自由探索では正式なProblem Box／axis gateを強制しない。
3. 正式評価では既存の人間承認・Critical／HARD gateを維持する。
4. 正式評価中も必要なら探索へ戻り、旧枝を残して新枝を作れる。
5. 抽象認識軸と具体評価項目、視点、思考重心を区別する。
6. 思考アーカイブは人間が管理し、明示されたファイル以外を自動参照しない。
7. 現在の課題に必要な情報を優先し、不要な文脈を自動投入しない。
8. 大きな改良は仕様・純粋ロジック・Host連携・行動検証に分ける。

## 今回実装した範囲

`06_IMPLEMENTATION_CLAY_ICC_v0.2.7/` に次を追加した。

- v2.73 Session / Trace Event schemaの参照実装パッケージへの収録
- active branchの一意性・active pointer一致・親枝参照・循環検出
- Event sequence、related event、session/branch/issue参照の意味的検証
- 明示指定による認知モード変更（自然言語分類は行わない）
- branch fork / resume / rollback-to-exploration
- open issueの作成・状態更新とイベント追記
- 明示指定済みJSONだけを扱うMarkdown export
- CLIコマンドと回帰・不変条件テスト
- 既存の詳細な日本語／英語ランタイムpromptを保持し、v2.73 AddendumをJA/ENの両方でprompt compilerに追加

既存のProblem Box、axis、Evidence、分析、BTM制御、既存state machine、prompt compiler、外部レビュー機能は維持している。

## 検証結果と限界

CLAY_ICC v0.2.7パッケージで `PYTHONPATH=src python -m pytest -q` を実行し、**121 passed、11 subtests passed**。前版の112 testsにInterpretation Integrity Layerの9 testsを追加した結果である。

wheel buildも成功し、cognitive_trace、interpretation_integrity、3つのSchema、日本語／英語Addendumのwheel収録を確認した。これはローカルコード経路の検証であり、LLMの独立5ターン対話品質、自然言語モード判定、Host永続化、承認者認証、アーカイブ検索遮断、改ざん防止、外部LLM連携を検証したものではない。

## 次段階

次はPhase 3としてHost側の保存・認証・権限・手動アーカイブ再投入制御を設計し、その後Phase 4で5ターン以上の独立対話検証を行う。v2.73プロンプト単独でHostやプロバイダー側の記憶・検索を制御できるとは主張しない。


## Interpretation Integrity Layer（今回の限定改良）

今回の変更は、入力保持・意味忠実性・不確実性保持・早すぎる構造化の抑制・訂正の波及・前提の来歴だけに限定した。これは新しい思考軸や会話モードではなく、状況に応じて適用する補助層である。原文とモデル解釈を分けるオプトインの記録形式と、明示依存関係に基づく訂正影響計算を追加した。意味的な正しさや暗黙の依存関係の完全性を自動判定するものではない。
