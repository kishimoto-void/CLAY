# ICC v2.73 Beta — File Index

Total packaged files (including this index and SHA256SUMS): **217**

## Top-level contents

- `00_BASELINE_v2.72_BETA/` — 113 files
- `01_SPEC/` — 1 files
- `02_PROMPTS/` — 2 files
- `03_DATA_MODEL/` — 10 files
- `04_IMPLEMENTATION_PLAN/` — 1 files
- `05_VERIFICATION/` — 2 files
- `06_IMPLEMENTATION_CLAY_ICC_v0.2.7/` — 81 files
- `07_DISTRIBUTION/` — 2 files
- `CHANGELOG_ICC_v2.73_BETA.md` — 1 file
- `README_ICC_v2.73_BETA.md` — 1 file
- `VERSION_AND_STATUS.md` — 1 file

## Recommended reading / implementation entry points

1. `README_ICC_v2.73_BETA.md` — package scope, versions, status, and known limitations.
2. `01_SPEC/ICC_v2.73_BETA_統合仕様案.md` — canonical v2.73 specification; Interpretation Integrity is section 15.
3. `02_PROMPTS/ICC_v2.73_BETA_統合システムプロンプト_JA.md` — consolidated Japanese prompt.
4. `03_DATA_MODEL/INTERPRETATION_INTEGRITY_OVERVIEW_JA.md` — targeted layer guide and record semantics.
5. `06_IMPLEMENTATION_CLAY_ICC_v0.2.7/docs/INTERPRETATION_INTEGRITY_JA.md` — implementation boundaries and usage.
6. `06_IMPLEMENTATION_CLAY_ICC_v0.2.7/src/icc/interpretation_integrity.py` — record creation, validation, correction propagation.
7. `06_IMPLEMENTATION_CLAY_ICC_v0.2.7/tests/test_interpretation_integrity.py` — focused regression tests.
8. `07_DISTRIBUTION/clay_icc-0.2.7-py3-none-any.whl` — installable Python wheel.

## Scope reminder

The Interpretation Integrity extension is limited to source/input preservation, semantic fidelity labels, uncertainty and structure states, explicit assumption provenance, and correction propagation over declared dependencies. It does not alter thinking axes, cognitive modes, formal gates, or Host integration. It does not automatically detect semantic drift or implicit dependencies, persist records, or enforce actual LLM behavior.

`00_BASELINE_v2.72_BETA/` is retained as the archived baseline and was not edited as part of this targeted update.
