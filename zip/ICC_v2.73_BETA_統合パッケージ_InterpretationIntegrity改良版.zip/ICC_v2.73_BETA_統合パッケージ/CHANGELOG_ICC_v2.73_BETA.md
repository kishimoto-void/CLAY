# CHANGELOG — ICC v2.73 Beta

## v2.73 Beta — 2026-11-14 (Stage 1)

### Added
- Integrated upper principles: Collaborative Fidelity, human agency, non-forced convergence, legal and ethical integrity.
- Separated cognitive mode from thinking direction, rigor, scope, recognition axes, and six weighting dials.
- Added natural-language trigger rules for Exploration and Formal Evaluation.
- Added rollback/branch preservation and unresolved issue states.
- Integrated abstract recognition axis to contextual evaluation item traceability.
- Integrated symmetric hypothesis evaluation, bidirectional causal evaluation, iterative hypothesis reassessment, multi-perspective and external LLM principles.
- Added Human-Governed Knowledge Retrieval and Minimal Context Principle.
- Added Cognitive Session and Trace Event JSON Schema proposals and Markdown Archive template.
- Added compatibility mapping and staged implementation roadmap.

### Not changed
- CLAY_ICC v0.2.5 Python runtime code, CLI, existing schemas, and prompt compiler.
- ICC v2.71 and v2.72 source baselines.

### Not yet verified
- New behavior in actual LLM conversation, Host-level archive exclusion, session persistence, branch runtime, and external multi-model behavior.


## v2.73 Beta — 2026-11-15 (Stage 2: local reference implementation)

### Added
- Added CLAY_ICC v0.2.6 candidate while preserving the v0.2.5 baseline unchanged.
- Connected v2.73 Cognitive Session / Trace Event schemas to a semantic validator and local CLI.
- Added mode transition, branch fork/resume, rollback-to-exploration, open-issue lifecycle, and explicit Markdown trace export.
- Integrated Japanese and English v2.73 prompt addenda into the existing prompt compiler without replacing its specialist evaluation contract.
- Added semantic invariants, API/CLI tests, and a corrected multi-event example.

### Verification
- Local test result: 112 passed, 11 subtests passed.
- CLI smoke tests: session/event validation, fork, revalidation, and Markdown export passed.
- Python wheel build and package-data inspection passed.

### Not implemented / not executed
- Host persistence, authentication, authorization, archive retrieval enforcement, cryptographic tamper resistance, and concurrent-write safety.
- Independent five-turn LLM behavior test and external LLM review.


## v2.73 Beta — 2026-11-15 (Stage 3: Interpretation Integrity)

### Added
- Added a narrowly scoped Interpretation Integrity Layer: Input Preservation, Semantic Fidelity, Uncertainty Preservation, Premature Structuring Control, Correction Propagation, and Assumption Provenance.
- Clarified that the layer is not a new thinking axis, cognitive mode, formal gate, or mandatory sequential pipeline.
- Added opt-in interpretation records separating verbatim source excerpts from model interpretations.
- Added explicit provenance, epistemic/uncertainty states, fidelity states, structure confirmation references, and assumption-origin metadata.
- Added append-only user-correction records and downstream recheck lists derived from declared dependencies.
- Added interpretation/correction trace event types and 9 deterministic regression tests.

### Verification
- Full regression test run: 121 passed, 11 subtests passed.
- Semantic fidelity, live LLM adherence, implicit dependency discovery, and Host persistence remain unverified / not implemented.
