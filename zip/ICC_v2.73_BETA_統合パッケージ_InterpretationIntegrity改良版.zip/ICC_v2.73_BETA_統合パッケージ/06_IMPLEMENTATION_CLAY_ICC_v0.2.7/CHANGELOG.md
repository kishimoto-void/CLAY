# Changelog

## 0.2.7 — Interpretation Integrity Layer (ICC v2.73 Beta)

- Added an opt-in interpretation record schema that separates verbatim source excerpts from model interpretations.
- Added explicit assertion provenance, epistemic status, fidelity status, and provisional/user-confirmed structure status.
- Added assumption-origin metadata and confirmation references for user-confirmed structures.
- Added append-only correction records with transitive recheck lists derived from explicitly declared record dependencies.
- Added Cognitive Trace events for interpretation records and user corrections.
- Added deterministic validators and regression tests; semantic accuracy and target-LLM adherence remain unverified.
- Kept all existing ICC axes, cognitive modes, formal gates, and v2.72 baseline behavior unchanged.

## 0.2.5 — External Independent Review (intermediate release)

- Added manual ZIP-based external LLM review packet preparation.
- Added source archive SHA-256 binding, per-file target manifest, and packet-wide integrity manifest.
- Added Japanese and English reviewer protocols with explicit memory/context disclosure and untrusted-input guidance.
- Added structured review coverage, executed-check declarations, drift assessment, findings, and human-gated axis proposals.
- Added deterministic report intake validation for target identity, source digest, path/line references, duplicate IDs, and axis approval constraints.
- Kept external model execution, provider-side memory control, API orchestration, MAS runtime, and automatic finding/axis adoption out of scope.
- Added a Japanese design-process record, decision log, workflow guide, and version-specific test report.


## 0.2.0 — Observation Orbit + Problem Separation

- Added optional Satellite Observation Map, linked to a specific Problem Box version.
- Added observation coverage ledger to make blind spots visible without treating breadth as confidence.
- Added typed satellite relations and causal-hypothesis fields for mechanism, time scope, evidence, alternatives, and disconfirmers.
- Added subproblem partitions and a default KEEP_SEPARATE / LINK_ONLY policy to limit LLM context blending.
- Added actor goal/action/resource/outcome separation to avoid treating public statements as proof of intent.
- Added deterministic structural and reference validation for the optional satellite map.
- Updated Japanese and English operating prompts for a ChatGPT-friendly scan, separation, linkage, and contamination-audit workflow.
- Preserved the core Problem Box, axis, CRITICAL, HARD, approval, evidence, and BTM boundaries.

## 0.1.0 — Initial specialist package

- Established ICC as a distinct CLAYLink specialist module built on BTM v0.2.0.
- Added Problem Box and axis-set contracts with human approval metadata.
- Added critical-axis / hard-constraint non-compensation analysis.
- Added evidence provenance, relation, uncertainty, and independence-group records.
- Added BTM v0.2.0 task-control compatibility mapping.
- Added state-transition guard, CLI, schemas, examples, tests, and specialist operating prompt.
- Explicitly excluded runtime execution, permission enforcement, autonomous evidence acquisition, domain certification, and destructive testing.

## 0.2.6 — ICC v2.73 Cognitive Trace (implementation candidate)

- Added v2.73 cognitive session and trace-event schemas to the implementation package.
- Added semantic validation for active-branch uniqueness, active branch pointer consistency, branch parent references and cycles, issue references, event sequence order, event ancestry, and session/branch binding.
- Added explicit mode transition recording without a natural-language classifier or automatic formal-gate activation.
- Added branch fork, branch resume, and rollback-to-exploration operations while preserving prior branches and formal-evaluation history.
- Added branch-scoped unresolved-issue creation and status lifecycle events.
- Added Markdown export from explicitly supplied session/event JSON only; no archive scanning or automatic retrieval.
- Added CLI commands and focused tests while retaining the v0.2.5 implementation and regression suite.
- Corrected the v2.73 sample session's active-branch pointer/status mismatch and added a coherent multi-event example.
- Host persistence, authentication/approval verification, tamper resistance, automatic archive exclusion, and live LLM behavioral testing remain outside this release.
