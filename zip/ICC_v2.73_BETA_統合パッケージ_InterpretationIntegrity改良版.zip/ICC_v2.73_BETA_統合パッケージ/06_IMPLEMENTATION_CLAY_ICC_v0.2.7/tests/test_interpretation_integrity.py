import copy
import json
from pathlib import Path
import unittest

from icc.cognitive_trace import validate_cognitive_session, validate_trace_events
from icc.interpretation_integrity import (
    append_interpretation_record,
    create_interpretation_record,
    create_user_correction_record,
    validate_interpretation_records,
)

PROJECT_ROOT = Path(__file__).resolve().parents[1]
DATA_ROOT = PROJECT_ROOT / "examples"


def load_fixture():
    session = json.loads((DATA_ROOT / "cognitive-session.v2.73.json").read_text(encoding="utf-8"))
    events = json.loads((DATA_ROOT / "cognitive-trace-events.v2.73.json").read_text(encoding="utf-8"))
    return session, events


class InterpretationIntegrityTests(unittest.TestCase):
    def _source_record(self, session, records):
        return create_interpretation_record(
            session, records,
            source_type="USER_INPUT", source_ref="turn-001",
            verbatim_excerpt="パーソナライゼーションは、その人に関する思考材料を提供する。",
            interpretation="ユーザーはパーソナライゼーションの役割を定義した。",
            assertion_type="USER_STATED", epistemic_status="STATED",
            record_kind="SOURCE_CAPTURE", actor="HUMAN",
            fidelity_status="PRESERVED", record_id="ir-source-1",
            timestamp="2026-11-15T03:00:00Z",
        )

    def _interpretation_record(self, session, records, source_id="ir-source-1"):
        return create_interpretation_record(
            session, records,
            source_type="MODEL_OUTPUT", source_ref="analysis-step-1",
            verbatim_excerpt="この仕組みは、誰と考えるかを決める。",
            interpretation="パーソナライゼーションが対話相手を選ぶ機能である可能性。",
            assertion_type="MODEL_INFERENCE", epistemic_status="PROVISIONAL",
            record_kind="INTERPRETATION", actor="LLM",
            fidelity_status="POSSIBLE_DRIFT", structure_status="PROVISIONAL",
            depends_on_record_ids=[source_id], record_id="ir-inference-1",
            timestamp="2026-11-15T03:01:00Z",
        )

    def test_source_and_interpretation_preserve_provenance_and_uncertainty(self):
        session, _ = load_fixture()
        source = self._source_record(session, [])
        interpretation = self._interpretation_record(session, [source])
        records = [source, interpretation]
        self.assertEqual(validate_interpretation_records(records, session), [])
        self.assertEqual(source["verbatim_excerpt"], "パーソナライゼーションは、その人に関する思考材料を提供する。")
        self.assertEqual(interpretation["epistemic_status"], "PROVISIONAL")
        self.assertEqual(interpretation["structure_status"], "PROVISIONAL")
        self.assertNotEqual(source["verbatim_excerpt"], interpretation["interpretation"])

    def test_user_confirmed_structure_requires_confirmation_reference(self):
        session, _ = load_fixture()
        source = self._source_record(session, [])
        bad = copy.deepcopy(source)
        bad["record_id"] = "ir-bad-confirmation"
        bad["sequence"] = 2
        bad["structure_status"] = "USER_CONFIRMED"
        errors = validate_interpretation_records([source, bad], session)
        self.assertTrue(any("confirmation_ref" in e for e in errors))

    def test_correction_preserves_history_and_marks_transitive_dependents(self):
        session, _ = load_fixture()
        source = self._source_record(session, [])
        inference = self._interpretation_record(session, [source])
        synthesis = create_interpretation_record(
            session, [source, inference],
            source_type="MODEL_OUTPUT", source_ref="analysis-step-2",
            verbatim_excerpt="上記の定義から、利用者ごとの状況情報を構造化する機能と考えられる。",
            interpretation="パーソナライゼーションが思考材料を供給するという理解。",
            assertion_type="MODEL_HYPOTHESIS", epistemic_status="PROVISIONAL",
            record_kind="INTERPRETATION", actor="LLM",
            fidelity_status="NOT_ASSESSED", structure_status="PROVISIONAL",
            depends_on_record_ids=["ir-inference-1"], record_id="ir-synthesis-1",
            timestamp="2026-11-15T03:02:00Z",
        )
        existing = [source, inference, synthesis]
        original = copy.deepcopy(existing)
        correction = create_user_correction_record(
            session, existing, target_record_id="ir-source-1",
            corrected_text="パーソナライゼーションは、利用者に関する情報を思考材料として提供する。",
            reason="元の定義をより正確に明示した。",
            timestamp="2026-11-15T03:03:00Z", record_id="ir-correction-1",
        )
        self.assertEqual(existing, original)
        self.assertEqual(correction["affected_record_ids"], ["ir-source-1", "ir-inference-1", "ir-synthesis-1"])
        self.assertEqual(correction["recheck_required_record_ids"], ["ir-inference-1", "ir-synthesis-1"])
        self.assertEqual(correction["recheck_status"], "REQUIRED")
        self.assertEqual(validate_interpretation_records(existing + [correction], session), [])

    def test_correction_without_declared_dependents_does_not_require_recheck(self):
        session, _ = load_fixture()
        source = self._source_record(session, [])
        correction = create_user_correction_record(
            session, [source], target_record_id="ir-source-1",
            corrected_text="修正後の定義。", reason="明確化。",
            timestamp="2026-11-15T03:00:30Z", record_id="ir-correction-no-dependents",
        )
        self.assertEqual(correction["affected_record_ids"], ["ir-source-1"])
        self.assertEqual(correction["recheck_required_record_ids"], [])
        self.assertEqual(correction["recheck_status"], "NOT_REQUIRED")
        self.assertEqual(validate_interpretation_records([source, correction], session), [])

    def test_append_interpretation_record_emits_trace_event(self):
        session, events = load_fixture()
        records = []
        source = self._source_record(session, records)
        updated_session, updated_events, updated_records = append_interpretation_record(
            session, events, records, source,
        )
        self.assertEqual(updated_records, [source])
        self.assertEqual(updated_events[-1]["event_type"], "INTERPRETATION_RECORDED")
        self.assertEqual(validate_interpretation_records(updated_records, updated_session), [])
        self.assertEqual(validate_cognitive_session(updated_session, updated_events), [])
        self.assertEqual(validate_trace_events(updated_events, updated_session), [])

    def test_append_correction_emits_impacted_record_ids(self):
        session, events = load_fixture()
        source = self._source_record(session, [])
        inference = self._interpretation_record(session, [source])
        records = [source, inference]
        correction = create_user_correction_record(
            session, records, target_record_id="ir-source-1",
            corrected_text="修正後のユーザー定義。", reason="意味のずれを訂正。",
            timestamp="2026-11-15T03:04:00Z", record_id="ir-correction-2",
        )
        updated_session, updated_events, updated_records = append_interpretation_record(
            session, events, records, correction,
        )
        event = updated_events[-1]
        self.assertEqual(event["event_type"], "USER_CORRECTION_RECORDED")
        self.assertEqual(event["details"]["recheck_required_record_ids"], ["ir-inference-1"])
        self.assertEqual(validate_interpretation_records(updated_records, updated_session), [])
        self.assertEqual(validate_trace_events(updated_events, updated_session), [])

    def test_future_dependency_is_rejected(self):
        session, _ = load_fixture()
        source = self._source_record(session, [])
        bad = copy.deepcopy(source)
        bad["record_id"] = "ir-bad-future-ref"
        bad["sequence"] = 2
        bad["depends_on_record_ids"] = ["not-yet-created"]
        errors = validate_interpretation_records([source, bad], session)
        self.assertTrue(any("missing or non-prior record" in e for e in errors))

    def test_unhashable_dependency_values_are_rejected_without_crashing(self):
        session, _ = load_fixture()
        source = self._source_record(session, [])
        malformed = copy.deepcopy(source)
        malformed["record_id"] = "ir-malformed-dependency"
        malformed["sequence"] = 2
        malformed["depends_on_record_ids"] = [{"not": "a reference"}]
        errors = validate_interpretation_records([source, malformed], session)
        self.assertTrue(any("items must be non-empty strings" in e for e in errors))

    def test_invalid_correction_dependency_set_is_rejected(self):
        session, _ = load_fixture()
        source = self._source_record(session, [])
        inference = self._interpretation_record(session, [source])
        correction = create_user_correction_record(
            session, [source, inference], target_record_id="ir-source-1",
            corrected_text="訂正", reason="意味の修正。",
            timestamp="2026-11-15T03:05:00Z", record_id="ir-correction-3",
        )
        correction["recheck_required_record_ids"] = []
        errors = validate_interpretation_records([source, inference, correction], session)
        self.assertTrue(any("recheck_required_record_ids" in e for e in errors))
        correction["recheck_required_record_ids"] = ["ir-inference-1"]
        correction["recheck_status"] = "NOT_REQUIRED"
        errors = validate_interpretation_records([source, inference, correction], session)
        self.assertTrue(any("recheck_status must be REQUIRED" in e for e in errors))


if __name__ == "__main__":
    unittest.main()
