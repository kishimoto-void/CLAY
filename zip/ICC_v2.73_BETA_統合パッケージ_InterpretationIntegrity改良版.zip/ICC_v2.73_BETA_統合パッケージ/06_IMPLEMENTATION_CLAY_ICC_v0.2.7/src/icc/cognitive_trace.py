"""Runtime helpers for ICC v2.73 cognitive sessions and append-oriented traces.

This module provides deterministic, local data-structure operations only. It does
not authenticate humans, persist data, classify natural-language intent, search
archives, or enforce Host permissions. Callers must explicitly supply the
session and event records they want to validate, modify, or export.
"""
from __future__ import annotations

from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable
import json
import uuid


COGNITIVE_MODES = {"EXPLORATION", "FORMAL_EVALUATION"}
MODE_REASONS = {
    "USER_EXPLICIT_REQUEST",
    "USER_INTENT_CLEAR",
    "USER_REQUESTED_ROLLBACK",
    "RESTORED_FROM_USER_SELECTED_STATE",
}
FORMAL_STATES = {
    "NOT_STARTED", "PREPARING", "BOX_PENDING_APPROVAL",
    "AXIS_PENDING_APPROVAL", "ACTIVE", "PAUSED", "HANDOFF_REQUIRED", "CLOSED",
}
ISSUE_STATES = {"OPEN", "PARKED", "RESOLVED", "REOPENED", "SUPERSEDED"}
ACTORS = {"HUMAN", "LLM", "HOST"}
EVENT_TYPES = {
    "MODE_CHANGED", "BRANCH_FORKED", "BRANCH_RESUMED", "ROLLBACK_STARTED",
    "HYPOTHESIS_PROPOSED", "HYPOTHESIS_UPDATED", "AXIS_CANDIDATE_PROPOSED",
    "EVALUATION_ITEM_PROPOSED", "EVIDENCE_ADDED", "EVALUATION_RECORDED",
    "OPEN_ISSUE_CREATED", "OPEN_ISSUE_UPDATED", "METHOD_SUCCEEDED",
    "METHOD_FAILED", "FINDING_RECORDED", "FORMAL_GATE_STATUS_CHANGED",
    "TRACE_EXPORTED", "INTERPRETATION_RECORDED", "USER_CORRECTION_RECORDED", "OTHER",
}
OUTCOMES = {
    "PROPOSED", "OBSERVED", "ACCEPTED_FOR_EXPLORATION", "APPROVED",
    "REJECTED", "DEFERRED", "SUPERSEDED", "NOT_APPLICABLE",
}


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")


def _parse_time(value: Any) -> datetime | None:
    if not isinstance(value, str):
        return None
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None
    if parsed.tzinfo is None:
        return None
    return parsed


def _copy(value: Any) -> Any:
    """Copy JSON-compatible data without retaining mutable caller references."""
    return deepcopy(value)


def _new_id(prefix: str) -> str:
    return f"{prefix}-{uuid.uuid4().hex[:12]}"


def _schema_errors(instance: Any, schema_name: str) -> list[str]:
    """Use optional jsonschema conformance when installed; manual checks still run."""
    try:
        from jsonschema import Draft202012Validator, FormatChecker
    except ImportError:
        return []
    schema_path = Path(__file__).resolve().parent / "schemas" / schema_name
    try:
        schema = json.loads(schema_path.read_text(encoding="utf-8"))
        Draft202012Validator.check_schema(schema)
        validator = Draft202012Validator(schema, format_checker=FormatChecker())
        errors = []
        for error in sorted(validator.iter_errors(instance), key=lambda item: list(map(str, item.path))):
            location = ".".join(str(part) for part in error.path) or "$"
            errors.append(f"{schema_name} at {location}: {error.message}")
        return errors
    except (OSError, json.JSONDecodeError, ValueError) as exc:
        return [f"could not load or apply {schema_name}: {exc}"]


def validate_trace_events(events: Any, session: dict[str, Any] | None = None) -> list[str]:
    """Validate trace-event schemas and cross-event/session references.

    Event arrays must be supplied in ascending sequence order. Sequences need
    not be contiguous, but they must be unique and strictly increasing.
    """
    errors: list[str] = []
    if not isinstance(events, list):
        return ["events must be a JSON array"]
    known_branches = set()
    session_id = None
    if session is not None:
        if not isinstance(session, dict):
            return ["session must be a JSON object"]
        known_branches = {
            b.get("branch_id") for b in session.get("branches", [])
            if isinstance(b, dict) and isinstance(b.get("branch_id"), str)
        }
        session_id = session.get("session_id")

    event_ids: set[str] = set()
    sequences: set[int] = set()
    previous_sequence = 0
    previous_ids: set[str] = set()
    for index, event in enumerate(events):
        prefix = f"events[{index}]"
        if not isinstance(event, dict):
            errors.append(f"{prefix} must be an object")
            continue
        errors.extend(f"{prefix}: {message}" for message in _schema_errors(event, "icc-trace-event.schema.json"))

        event_id = event.get("event_id")
        sequence = event.get("sequence")
        if not isinstance(event_id, str) or not event_id:
            errors.append(f"{prefix}.event_id must be a non-empty string")
        elif event_id in event_ids:
            errors.append(f"duplicate event_id: {event_id}")
        if isinstance(event_id, str):
            event_ids.add(event_id)

        if isinstance(sequence, bool) or not isinstance(sequence, int) or sequence < 1:
            errors.append(f"{prefix}.sequence must be a positive integer")
        else:
            if sequence in sequences:
                errors.append(f"duplicate event sequence: {sequence}")
            if sequence <= previous_sequence:
                errors.append(f"{prefix}.sequence must be strictly increasing in event-array order")
            sequences.add(sequence)
            previous_sequence = sequence

        if session_id is not None and event.get("session_id") != session_id:
            errors.append(f"{prefix}.session_id does not match the supplied session")
        if session is not None and event.get("branch_id") not in known_branches:
            errors.append(f"{prefix}.branch_id does not exist in the supplied session")

        timestamp = _parse_time(event.get("timestamp"))
        if timestamp is None:
            errors.append(f"{prefix}.timestamp must be an ISO-8601 date-time with timezone")

        related = event.get("related_event_ids", [])
        if isinstance(related, list):
            for related_id in related:
                if related_id not in previous_ids:
                    errors.append(f"{prefix} references missing or non-prior related event: {related_id}")

        if isinstance(event_id, str):
            previous_ids.add(event_id)

    return errors


def validate_cognitive_session(
    session: Any,
    events: list[dict[str, Any]] | None = None,
) -> list[str]:
    """Validate v2.73 session structure plus semantic branch/issue invariants.

    If a branch or issue contains an event reference, `events` must be supplied
    to verify that reference. This is structural validation, not proof that a
    human approval was authentic or authorized.
    """
    if not isinstance(session, dict):
        return ["session must be a JSON object"]
    errors = _schema_errors(session, "icc-cognitive-session.schema.json")

    branches = session.get("branches")
    if not isinstance(branches, list):
        return errors + ["branches must be an array"]
    branch_map: dict[str, dict[str, Any]] = {}
    for index, branch in enumerate(branches):
        if not isinstance(branch, dict):
            errors.append(f"branches[{index}] must be an object")
            continue
        branch_id = branch.get("branch_id")
        if not isinstance(branch_id, str) or not branch_id:
            errors.append(f"branches[{index}].branch_id must be a non-empty string")
            continue
        if branch_id in branch_map:
            errors.append(f"duplicate branch_id: {branch_id}")
        branch_map[branch_id] = branch
        if _parse_time(branch.get("created_at")) is None:
            errors.append(f"branch {branch_id} has an invalid created_at timestamp")

    active_ids = [bid for bid, branch in branch_map.items() if branch.get("status") == "ACTIVE"]
    if len(active_ids) != 1:
        errors.append(f"exactly one ACTIVE branch is required; found {len(active_ids)}")
    if session.get("active_branch_id") not in branch_map:
        errors.append("active_branch_id does not exist in branches")
    elif branch_map[session["active_branch_id"]].get("status") != "ACTIVE":
        errors.append("active_branch_id must reference the branch whose status is ACTIVE")

    # Parent links must remain inside this session and form an acyclic graph.
    for branch_id, branch in branch_map.items():
        parent_id = branch.get("parent_branch_id")
        if parent_id is not None and parent_id not in branch_map:
            errors.append(f"branch {branch_id} references missing parent branch: {parent_id}")
        if parent_id == branch_id:
            errors.append(f"branch {branch_id} cannot be its own parent")
    for start_id in branch_map:
        seen: set[str] = set()
        current = start_id
        while current in branch_map:
            if current in seen:
                errors.append(f"branch graph contains a cycle involving {current}")
                break
            seen.add(current)
            parent = branch_map[current].get("parent_branch_id")
            if parent is None or parent not in branch_map:
                break
            current = parent

    created_at = _parse_time(session.get("created_at"))
    updated_at = _parse_time(session.get("updated_at"))
    if created_at is None:
        errors.append("created_at must be an ISO-8601 date-time with timezone")
    if updated_at is None:
        errors.append("updated_at must be an ISO-8601 date-time with timezone")
    if created_at is not None and updated_at is not None and updated_at < created_at:
        errors.append("updated_at cannot be earlier than created_at")

    if session.get("cognitive_mode") not in COGNITIVE_MODES:
        errors.append("cognitive_mode is not a supported v2.73 mode")
    if session.get("mode_reason") not in MODE_REASONS:
        errors.append("mode_reason is not a supported v2.73 reason")
    if session.get("formal_evaluation_state") not in FORMAL_STATES:
        errors.append("formal_evaluation_state is not supported")
    if session.get("formal_evaluation_state") == "ACTIVE":
        if not session.get("problem_box_ref") or not session.get("axis_set_ref"):
            errors.append("ACTIVE formal evaluation requires problem_box_ref and axis_set_ref")

    issues = session.get("open_issues", [])
    if not isinstance(issues, list):
        errors.append("open_issues must be an array")
        issues = []
    issue_ids: set[str] = set()
    for index, issue in enumerate(issues):
        if not isinstance(issue, dict):
            errors.append(f"open_issues[{index}] must be an object")
            continue
        issue_id = issue.get("issue_id")
        if not isinstance(issue_id, str) or not issue_id:
            errors.append(f"open_issues[{index}].issue_id must be a non-empty string")
        elif issue_id in issue_ids:
            errors.append(f"duplicate issue_id: {issue_id}")
        if isinstance(issue_id, str):
            issue_ids.add(issue_id)
        if issue.get("branch_id") not in branch_map:
            errors.append(f"issue {issue_id} references missing branch: {issue.get('branch_id')}")
        if issue.get("status") not in ISSUE_STATES:
            errors.append(f"issue {issue_id} has an unsupported status")

    if events is not None:
        event_errors = validate_trace_events(events, session)
        errors.extend(event_errors)
        event_ids = {
            event.get("event_id") for event in events if isinstance(event, dict)
        }
        for branch_id, branch in branch_map.items():
            origin_id = branch.get("origin_event_id")
            if origin_id is not None and origin_id not in event_ids:
                errors.append(f"branch {branch_id} references missing origin event: {origin_id}")
        for issue in issues:
            if not isinstance(issue, dict):
                continue
            for key in ("origin_event_id", "resolution_event_id"):
                ref = issue.get(key)
                if ref is not None and ref not in event_ids:
                    errors.append(f"issue {issue.get('issue_id')} references missing {key}: {ref}")
    else:
        has_refs = any(
            isinstance(b, dict) and b.get("origin_event_id") is not None for b in branches
        ) or any(
            isinstance(i, dict) and (i.get("origin_event_id") is not None or i.get("resolution_event_id") is not None)
            for i in issues
        )
        if has_refs:
            errors.append("events must be supplied to verify branch/issue event references")

    return errors


def _validate_pair(session: Any, events: Any) -> None:
    errors = validate_cognitive_session(session, events)
    if errors:
        raise ValueError("; ".join(errors))


def _build_event(
    session: dict[str, Any], events: list[dict[str, Any]], *, branch_id: str,
    event_type: str, summary: str, actor: str = "HOST", timestamp: str | None = None,
    event_id: str | None = None, related_event_ids: Iterable[str] | None = None,
    issue_refs: Iterable[str] | None = None, assumption_delta: Iterable[str] | None = None,
    details: dict[str, Any] | None = None, outcome: str = "OBSERVED",
) -> dict[str, Any]:
    if event_type not in EVENT_TYPES:
        raise ValueError(f"unsupported event_type: {event_type}")
    if actor not in ACTORS:
        raise ValueError(f"unsupported actor: {actor}")
    if outcome not in OUTCOMES:
        raise ValueError(f"unsupported outcome: {outcome}")
    existing_branch_ids = {b["branch_id"] for b in session["branches"]}
    if branch_id not in existing_branch_ids and event_type != "BRANCH_FORKED":
        raise ValueError(f"unknown branch_id: {branch_id}")
    event_id = event_id or _new_id("event")
    if any(item.get("event_id") == event_id for item in events):
        raise ValueError(f"event_id already exists: {event_id}")
    seqs = [item.get("sequence", 0) for item in events if isinstance(item.get("sequence"), int)]
    timestamp = timestamp or _now()
    if _parse_time(timestamp) is None:
        raise ValueError("timestamp must be an ISO-8601 date-time with timezone")
    event: dict[str, Any] = {
        "schema_version": "1.0",
        "event_id": event_id,
        "sequence": max(seqs, default=0) + 1,
        "session_id": session["session_id"],
        "branch_id": branch_id,
        "timestamp": timestamp,
        "actor": actor,
        "event_type": event_type,
        "summary": summary,
        "record_policy": "APPEND_NEW_EVENT_FOR_CORRECTIONS",
        "outcome": outcome,
    }
    if related_event_ids:
        event["related_event_ids"] = list(related_event_ids)
    if issue_refs:
        event["issue_refs"] = list(issue_refs)
    if assumption_delta:
        event["assumption_delta"] = list(assumption_delta)
    if details:
        event["details"] = _copy(details)
    schema_errors = _schema_errors(event, "icc-trace-event.schema.json")
    if schema_errors:
        raise ValueError("; ".join(schema_errors))
    return event


def _append_event(
    session: dict[str, Any], events: list[dict[str, Any]], event: dict[str, Any],
) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    new_session = _copy(session)
    new_events = _copy(events) + [_copy(event)]
    new_session["updated_at"] = event["timestamp"]
    return new_session, new_events


def set_cognitive_mode(
    session: dict[str, Any], events: list[dict[str, Any]], *, mode: str, reason: str,
    actor: str = "HUMAN", timestamp: str | None = None,
) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    """Set a mode only from an explicit caller decision; no NLP inference occurs."""
    _validate_pair(session, events)
    if mode not in COGNITIVE_MODES:
        raise ValueError(f"unsupported cognitive mode: {mode}")
    if reason not in MODE_REASONS:
        raise ValueError(f"unsupported mode reason: {reason}")
    if mode == session["cognitive_mode"]:
        raise ValueError("requested mode is already active; no transition was recorded")
    branch_id = session["active_branch_id"]
    event = _build_event(
        session, events, branch_id=branch_id, event_type="MODE_CHANGED",
        summary=f"認知モードを {session['cognitive_mode']} から {mode} に変更した。",
        actor=actor, timestamp=timestamp,
        details={"from_mode": session["cognitive_mode"], "to_mode": mode, "reason": reason},
    )
    new_session, new_events = _append_event(session, events, event)
    new_session["cognitive_mode"] = mode
    new_session["mode_reason"] = reason
    if mode == "EXPLORATION" and new_session.get("formal_evaluation_state") == "ACTIVE":
        new_session["formal_evaluation_state"] = "PAUSED"
    return new_session, new_events


def fork_branch(
    session: dict[str, Any], events: list[dict[str, Any]], *, branch_id: str,
    summary: str, changed_assumptions: Iterable[str] = (), actor: str = "HUMAN",
    timestamp: str | None = None,
) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    """Fork from the active branch, preserving the parent as PAUSED."""
    _validate_pair(session, events)
    if not branch_id or any(b.get("branch_id") == branch_id for b in session["branches"]):
        raise ValueError("branch_id must be non-empty and unique within the session")
    if not isinstance(summary, str) or not summary.strip():
        raise ValueError("summary must be a non-empty string")
    timestamp = timestamp or _now()
    parent_id = session["active_branch_id"]
    event_id = _new_id("event")
    assumptions = list(changed_assumptions)
    event = _build_event(
        session, events, branch_id=branch_id, event_type="BRANCH_FORKED",
        summary=f"新しい思考枝 {branch_id} を作成した。", actor=actor,
        timestamp=timestamp, event_id=event_id, assumption_delta=assumptions,
        details={"parent_branch_id": parent_id, "summary": summary},
        outcome="PROPOSED",
    )
    new_session, new_events = _append_event(session, events, event)
    for branch in new_session["branches"]:
        if branch["branch_id"] == parent_id:
            branch["status"] = "PAUSED"
    new_session["branches"].append({
        "branch_id": branch_id,
        "parent_branch_id": parent_id,
        "origin_event_id": event_id,
        "status": "ACTIVE",
        "created_at": timestamp,
        "summary": summary,
        "changed_assumptions": assumptions,
        "related_issue_ids": [],
    })
    new_session["active_branch_id"] = branch_id
    errors = validate_cognitive_session(new_session, new_events)
    if errors:
        raise ValueError("fork would violate session invariants: " + "; ".join(errors))
    return new_session, new_events


def rollback_to_new_branch(
    session: dict[str, Any], events: list[dict[str, Any]], *, branch_id: str,
    summary: str, changed_assumptions: Iterable[str] = (), actor: str = "HUMAN",
    timestamp: str | None = None,
) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    """Start a new exploration branch while retaining formal evaluation history."""
    _validate_pair(session, events)
    timestamp = timestamp or _now()
    parent_id = session["active_branch_id"]
    current_mode = session["cognitive_mode"]
    work_session = _copy(session)
    work_events = _copy(events)
    if current_mode != "EXPLORATION":
        rollback_event = _build_event(
            work_session, work_events, branch_id=parent_id, event_type="ROLLBACK_STARTED",
            summary="正式評価の履歴を保持したまま、探索へのロールバックを開始した。",
            actor=actor, timestamp=timestamp,
            details={"from_mode": current_mode, "to_mode": "EXPLORATION"},
        )
        work_session, work_events = _append_event(work_session, work_events, rollback_event)
        mode_event = _build_event(
            work_session, work_events, branch_id=parent_id, event_type="MODE_CHANGED",
            summary="ロールバック要求により自由探索へ戻った。", actor=actor,
            timestamp=timestamp,
            related_event_ids=[rollback_event["event_id"]],
            details={"from_mode": current_mode, "to_mode": "EXPLORATION", "reason": "USER_REQUESTED_ROLLBACK"},
        )
        work_session, work_events = _append_event(work_session, work_events, mode_event)
        work_session["cognitive_mode"] = "EXPLORATION"
        work_session["mode_reason"] = "USER_REQUESTED_ROLLBACK"
    if work_session.get("formal_evaluation_state") == "ACTIVE":
        work_session["formal_evaluation_state"] = "PAUSED"
    return fork_branch(
        work_session, work_events, branch_id=branch_id, summary=summary,
        changed_assumptions=changed_assumptions, actor=actor, timestamp=timestamp,
    )


def resume_branch(
    session: dict[str, Any], events: list[dict[str, Any]], *, branch_id: str,
    actor: str = "HUMAN", timestamp: str | None = None,
) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    """Resume a previous PAUSED or ARCHIVED branch without deleting other branches."""
    _validate_pair(session, events)
    branches = {b["branch_id"]: b for b in session["branches"]}
    if branch_id not in branches:
        raise ValueError(f"unknown branch_id: {branch_id}")
    if branch_id == session["active_branch_id"]:
        raise ValueError("requested branch is already active")
    previous_status = branches[branch_id].get("status")
    if previous_status not in {"PAUSED", "ARCHIVED"}:
        raise ValueError(f"branch cannot be resumed from status {previous_status}")
    old_active = session["active_branch_id"]
    event = _build_event(
        session, events, branch_id=branch_id, event_type="BRANCH_RESUMED",
        summary=f"既存の思考枝 {branch_id} を再開した。", actor=actor,
        timestamp=timestamp,
        details={"previous_active_branch_id": old_active, "previous_status": previous_status},
    )
    new_session, new_events = _append_event(session, events, event)
    for branch in new_session["branches"]:
        if branch["branch_id"] == old_active:
            branch["status"] = "PAUSED"
        elif branch["branch_id"] == branch_id:
            branch["status"] = "ACTIVE"
    new_session["active_branch_id"] = branch_id
    errors = validate_cognitive_session(new_session, new_events)
    if errors:
        raise ValueError("resume would violate session invariants: " + "; ".join(errors))
    return new_session, new_events


def create_open_issue(
    session: dict[str, Any], events: list[dict[str, Any]], *, issue_id: str,
    title: str, impact: str = "", next_check: str = "", actor: str = "HUMAN",
    timestamp: str | None = None,
) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    """Create a branch-scoped unresolved issue and record its creation event."""
    _validate_pair(session, events)
    if not issue_id or any(i.get("issue_id") == issue_id for i in session.get("open_issues", [])):
        raise ValueError("issue_id must be non-empty and unique")
    if not isinstance(title, str) or not title.strip():
        raise ValueError("title must be a non-empty string")
    branch_id = session["active_branch_id"]
    event_id = _new_id("event")
    event = _build_event(
        session, events, branch_id=branch_id, event_type="OPEN_ISSUE_CREATED",
        summary=f"未解決課題を追加した: {title}", actor=actor, timestamp=timestamp,
        event_id=event_id, issue_refs=[issue_id], details={"title": title, "impact": impact, "next_check": next_check},
    )
    new_session, new_events = _append_event(session, events, event)
    new_session["open_issues"].append({
        "issue_id": issue_id, "branch_id": branch_id, "title": title,
        "status": "OPEN", "impact": impact, "next_check": next_check,
        "origin_event_id": event_id, "resolution_event_id": None,
    })
    return new_session, new_events


def update_open_issue_status(
    session: dict[str, Any], events: list[dict[str, Any]], *, issue_id: str,
    status: str, summary: str | None = None, actor: str = "HUMAN",
    timestamp: str | None = None,
) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    """Change an issue state by appending a new event; prior events remain intact."""
    _validate_pair(session, events)
    if status not in ISSUE_STATES:
        raise ValueError(f"unsupported issue status: {status}")
    issue = next((i for i in session.get("open_issues", []) if i.get("issue_id") == issue_id), None)
    if issue is None:
        raise ValueError(f"unknown issue_id: {issue_id}")
    previous_status = issue["status"]
    if previous_status == status:
        raise ValueError("issue already has the requested status")
    event_id = _new_id("event")
    event = _build_event(
        session, events, branch_id=issue["branch_id"], event_type="OPEN_ISSUE_UPDATED",
        summary=summary or f"課題 {issue_id} の状態を {previous_status} から {status} に変更した。",
        actor=actor, timestamp=timestamp, event_id=event_id,
        issue_refs=[issue_id], details={"from_status": previous_status, "to_status": status},
    )
    new_session, new_events = _append_event(session, events, event)
    new_issue = next(i for i in new_session["open_issues"] if i["issue_id"] == issue_id)
    new_issue["status"] = status
    if status == "RESOLVED":
        new_issue["resolution_event_id"] = event_id
    return new_session, new_events


def render_markdown_archive(session: dict[str, Any], events: list[dict[str, Any]]) -> str:
    """Render only explicitly supplied records; never discovers or loads archives."""
    _validate_pair(session, events)
    lines = [
        f"# ICC Cognitive Trace — {session['session_id']}",
        "",
        "> このファイルは、呼び出し元が明示的に渡したSessionとTrace Eventだけから生成。会話全文ではない。",
        "",
        "## Session", "",
        f"- ICC spec: `{session['icc_spec_version']}`",
        f"- Cognitive mode: `{session['cognitive_mode']}`",
        f"- Mode reason: `{session['mode_reason']}`",
        f"- Active branch: `{session['active_branch_id']}`",
        f"- Formal evaluation state: `{session['formal_evaluation_state']}`",
        f"- Archive policy: `{session['archive_policy']}`",
        f"- Archived trace autoload: `{session['autoload_archived_traces']}`",
        "", "## Branches", "",
        "| Branch | Status | Parent | Summary |", "|---|---|---|---|",
    ]
    for branch in session["branches"]:
        summary = str(branch.get("summary", "")).replace("|", "\\|").replace("\n", " ")
        lines.append(
            f"| `{branch['branch_id']}` | {branch['status']} | "
            f"{branch.get('parent_branch_id') or '—'} | {summary} |"
        )
    lines += ["", "## Open Issues", ""]
    if session.get("open_issues"):
        lines += ["| ID | Branch | Status | Title |", "|---|---|---|---|"]
        for issue in session["open_issues"]:
            title = str(issue.get("title", "")).replace("|", "\\|").replace("\n", " ")
            lines.append(f"| `{issue['issue_id']}` | `{issue['branch_id']}` | {issue['status']} | {title} |")
    else:
        lines.append("未解決課題は記録されていない。")
    lines += ["", "## Trace Events", ""]
    if events:
        for event in events:
            lines += [
                f"### {event['sequence']}. {event['event_type']} — {event['event_id']}",
                "",
                f"- Time: {event['timestamp']}",
                f"- Branch: `{event['branch_id']}`",
                f"- Actor: {event['actor']}",
                f"- Outcome: {event.get('outcome', 'NOT_APPLICABLE')}",
                "",
                event["summary"],
                "",
            ]
            if event.get("assumption_delta"):
                lines.append("- Changed assumptions: " + "; ".join(event["assumption_delta"]))
                lines.append("")
    else:
        lines.append("イベントは記録されていない。")
    lines += ["", "## Limits", "", "- このExportは構造化記録であり、完全な会話ログではない。",
              "- 記録上の承認値は、本人性・権限・承認の真正性を証明しない。",
              "- 追記型の形式は暗号学的な改ざん防止を保証しない。", ""]
    return "\n".join(lines)


def load_json_file(path: str | Path) -> Any:
    """Read one explicitly named JSON file with a 5 MB limit."""
    path = Path(path)
    if path.stat().st_size > 5_000_000:
        raise ValueError("input file exceeds 5,000,000 byte safety limit")
    return json.loads(path.read_text(encoding="utf-8"))


def write_json_file(path: str | Path, value: Any) -> None:
    """Write an explicit output file. Persistence/permissions remain Host-owned."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
