"""Interpretation-integrity records for ICC v2.73.

This module preserves source wording, separates statement provenance from
model interpretation, records uncertainty/structure status, and computes the
explicitly declared downstream records affected by a user correction.

It is an opt-in local data helper. It does not infer semantic equivalence,
automatically store every turn, classify natural-language intent, or prove
that a model has faithfully understood a user's meaning.
"""
from __future__ import annotations

from copy import deepcopy
from datetime import datetime, timezone
from typing import Any, Iterable
import json
import uuid

from .cognitive_trace import _append_event, _build_event, _parse_time, _schema_errors

RECORD_KINDS = {"SOURCE_CAPTURE", "INTERPRETATION", "STRUCTURE_DECISION", "CORRECTION"}
SOURCE_TYPES = {"USER_INPUT", "USER_CORRECTION", "ATTACHMENT", "EXTERNAL_SOURCE", "MODEL_OUTPUT"}
ASSERTION_TYPES = {
    "USER_STATED", "DIRECT_OBSERVATION", "MODEL_INFERENCE",
    "MODEL_HYPOTHESIS", "MODEL_PROPOSAL", "EXTERNAL_CLAIM",
}
EPISTEMIC_STATUSES = {
    "STATED", "USER_CONFIRMED", "PROVISIONAL", "AMBIGUOUS",
    "UNVERIFIED", "REJECTED", "SUPERSEDED",
}
FIDELITY_STATUSES = {"NOT_ASSESSED", "PRESERVED", "POSSIBLE_DRIFT", "CORRECTED"}
STRUCTURE_STATUSES = {"UNSTRUCTURED", "PROVISIONAL", "USER_CONFIRMED", "DEFERRED"}
RECHECK_STATUSES = {"NOT_REQUIRED", "REQUIRED", "COMPLETED"}


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")


def _new_id() -> str:
    return f"interpretation-{uuid.uuid4().hex[:12]}"


def _copy(value: Any) -> Any:
    return deepcopy(value)


def _schema_errors_for_record(record: Any) -> list[str]:
    """Run JSON Schema checks when available plus dependency-free core checks."""
    errors = _schema_errors(record, "icc-interpretation-record.schema.json")
    if not isinstance(record, dict):
        return errors + ["interpretation record must be a JSON object"]
    required = {
        "schema_version", "record_id", "sequence", "session_id", "branch_id",
        "timestamp", "actor", "record_kind", "source_type", "source_ref",
        "verbatim_excerpt", "interpretation", "assertion_type", "epistemic_status",
        "fidelity_status", "structure_status", "depends_on_record_ids",
        "supersedes_record_ids", "affected_record_ids", "recheck_required_record_ids",
        "recheck_status", "assumptions", "record_policy",
    }
    for key in sorted(required - record.keys()):
        errors.append(f"missing required field: {key}")
    enum_fields = {
        "actor": {"HUMAN", "LLM", "HOST"},
        "record_kind": RECORD_KINDS,
        "source_type": SOURCE_TYPES,
        "assertion_type": ASSERTION_TYPES,
        "epistemic_status": EPISTEMIC_STATUSES,
        "fidelity_status": FIDELITY_STATUSES,
        "structure_status": STRUCTURE_STATUSES,
        "recheck_status": RECHECK_STATUSES,
    }
    for key, allowed in enum_fields.items():
        if key in record and (not isinstance(record[key], str) or record[key] not in allowed):
            errors.append(f"{key} has unsupported value")
    for key in ("record_id", "session_id", "branch_id", "source_ref", "verbatim_excerpt", "interpretation"):
        if key in record and (not isinstance(record[key], str) or not record[key].strip()):
            errors.append(f"{key} must be a non-empty string")
    if record.get("schema_version") != "1.0":
        errors.append("schema_version must be 1.0")
    if record.get("record_policy") != "APPEND_NEW_RECORD_FOR_CORRECTIONS":
        errors.append("record_policy must be APPEND_NEW_RECORD_FOR_CORRECTIONS")
    for key in ("depends_on_record_ids", "supersedes_record_ids", "affected_record_ids", "recheck_required_record_ids", "assumptions"):
        if key in record and not isinstance(record[key], list):
            errors.append(f"{key} must be an array")
    seq = record.get("sequence")
    if isinstance(seq, bool) or not isinstance(seq, int) or seq < 1:
        errors.append("sequence must be a positive integer")
    if record.get("timestamp") is not None and _parse_time(record.get("timestamp")) is None:
        errors.append("timestamp must be an ISO-8601 date-time with timezone")
    for key in ("depends_on_record_ids", "supersedes_record_ids", "affected_record_ids", "recheck_required_record_ids"):
        values = record.get(key, [])
        if isinstance(values, list) and any(not isinstance(value, str) or not value for value in values):
            errors.append(f"{key} items must be non-empty strings")
        if isinstance(values, list):
            string_values = [value for value in values if isinstance(value, str)]
            if len(string_values) != len(set(string_values)):
                errors.append(f"{key} must not contain duplicate references")
    assumptions = record.get("assumptions", [])
    if isinstance(assumptions, list):
        for idx, assumption in enumerate(assumptions):
            if not isinstance(assumption, dict):
                errors.append(f"assumptions[{idx}] must be an object")
                continue
            for key in ("assumption_id", "statement", "origin", "status"):
                if key not in assumption:
                    errors.append(f"assumptions[{idx}] missing required field: {key}")
            if not isinstance(assumption.get("assumption_id"), str) or not assumption.get("assumption_id"):
                errors.append(f"assumptions[{idx}].assumption_id must be a non-empty string")
            if not isinstance(assumption.get("statement"), str) or not assumption.get("statement"):
                errors.append(f"assumptions[{idx}].statement must be a non-empty string")
            if assumption.get("origin") not in ("USER_STATED", "MODEL_INFERRED", "EXTERNAL_SOURCE", "UNKNOWN"):
                errors.append(f"assumptions[{idx}].origin has an unsupported value")
            if assumption.get("status") not in ("UNCONFIRMED", "CONFIRMED_BY_USER", "VERIFIED_EXTERNALLY", "REJECTED"):
                errors.append(f"assumptions[{idx}].status has an unsupported value")
    if record.get("structure_status") == "USER_CONFIRMED" and not record.get("confirmation_ref"):
        errors.append("USER_CONFIRMED structure requires confirmation_ref")
    if record.get("record_kind") == "CORRECTION":
        if record.get("source_type") != "USER_CORRECTION" or record.get("actor") != "HUMAN":
            errors.append("CORRECTION records must originate from a human user correction")
        if record.get("fidelity_status") != "CORRECTED":
            errors.append("CORRECTION records must use fidelity_status=CORRECTED")
        if not isinstance(record.get("correction_reason"), str) or not record["correction_reason"].strip():
            errors.append("CORRECTION records require a non-empty correction_reason")
        if record.get("assertion_type") != "USER_STATED":
            errors.append("CORRECTION records must use assertion_type=USER_STATED")
    return errors


def _downstream_record_ids(records: list[dict[str, Any]], target_id: str) -> list[str]:
    """Return transitive dependents in record-sequence order."""
    impacted = {target_id}
    changed = True
    while changed:
        changed = False
        for record in records:
            if not isinstance(record, dict):
                continue
            record_id = record.get("record_id")
            dependencies = record.get("depends_on_record_ids", [])
            if not isinstance(record_id, str) or not isinstance(dependencies, list):
                continue
            valid_dependencies = [dep for dep in dependencies if isinstance(dep, str)]
            if record_id not in impacted and any(dep in impacted for dep in valid_dependencies):
                impacted.add(record_id)
                changed = True
    def _sequence_key(record: dict[str, Any]) -> int:
        sequence = record.get("sequence")
        return sequence if isinstance(sequence, int) and not isinstance(sequence, bool) else -1

    ordered = sorted(
        (r for r in records if isinstance(r, dict) and r.get("record_id") in impacted
         and r.get("record_id") != target_id),
        key=_sequence_key,
    )
    return [r["record_id"] for r in ordered if isinstance(r.get("record_id"), str)]


def validate_interpretation_records(
    records: Any, session: dict[str, Any] | None = None,
) -> list[str]:
    """Validate record schemas and declared provenance/dependency relationships.

    Dependency completeness is not inferable from the records themselves. The
    validator checks only links explicitly recorded by the caller.
    """
    if not isinstance(records, list):
        return ["records must be a JSON array"]

    errors: list[str] = []
    known_ids: set[str] = set()
    record_map: dict[str, dict[str, Any]] = {}
    previous_sequence = 0
    valid_branch_ids: set[str] | None = None
    session_id = None
    if session is not None:
        if not isinstance(session, dict):
            return ["session must be a JSON object"]
        session_id = session.get("session_id")
        branches = session.get("branches", [])
        valid_branch_ids = {
            b.get("branch_id") for b in branches
            if isinstance(branches, list) and isinstance(b, dict)
            and isinstance(b.get("branch_id"), str)
        }

    for index, record in enumerate(records):
        prefix = f"records[{index}]"
        if not isinstance(record, dict):
            errors.append(f"{prefix} must be an object")
            continue
        errors.extend(f"{prefix}: {e}" for e in _schema_errors_for_record(record))

        record_id = record.get("record_id")
        sequence = record.get("sequence")
        if not isinstance(record_id, str) or not record_id:
            errors.append(f"{prefix}.record_id must be a non-empty string")
        elif record_id in known_ids:
            errors.append(f"duplicate record_id: {record_id}")
        if isinstance(record_id, str):
            record_map[record_id] = record

        if isinstance(sequence, bool) or not isinstance(sequence, int) or sequence < 1:
            errors.append(f"{prefix}.sequence must be a positive integer")
        elif sequence <= previous_sequence:
            errors.append(f"{prefix}.sequence must be strictly increasing")
        else:
            previous_sequence = sequence

        if session_id is not None and record.get("session_id") != session_id:
            errors.append(f"{prefix}.session_id does not match supplied session")
        if valid_branch_ids is not None and record.get("branch_id") not in valid_branch_ids:
            errors.append(f"{prefix}.branch_id does not exist in supplied session")
        if _parse_time(record.get("timestamp")) is None:
            errors.append(f"{prefix}.timestamp must be an ISO-8601 date-time with timezone")

        for field in ("depends_on_record_ids", "supersedes_record_ids"):
            refs = record.get(field, [])
            if isinstance(refs, list):
                for ref in refs:
                    if not isinstance(ref, str) or ref not in known_ids:
                        errors.append(f"{prefix}.{field} references missing or non-prior record")

        if record.get("structure_status") == "USER_CONFIRMED" and not record.get("confirmation_ref"):
            errors.append(f"{prefix} USER_CONFIRMED structure requires confirmation_ref")

        if record.get("record_kind") == "CORRECTION":
            supersedes = record.get("supersedes_record_ids", [])
            if not isinstance(supersedes, list) or len(supersedes) != 1 or not isinstance(supersedes[0], str) or supersedes[0] not in known_ids:
                errors.append(f"{prefix} correction must supersede exactly one prior record")
            else:
                target_id = supersedes[0]
                descendants = _downstream_record_ids(records[:index], target_id)
                expected_affected = [target_id, *descendants]
                actual_affected = record.get("affected_record_ids", [])
                actual_recheck = record.get("recheck_required_record_ids", [])
                if actual_affected != expected_affected:
                    errors.append(
                        f"{prefix}.affected_record_ids must list target and declared downstream records in sequence order"
                    )
                if actual_recheck != descendants:
                    errors.append(
                        f"{prefix}.recheck_required_record_ids must list all declared downstream dependents"
                    )
                expected_recheck_status = "REQUIRED" if descendants else "NOT_REQUIRED"
                if record.get("recheck_status") != expected_recheck_status:
                    errors.append(
                        f"{prefix}.recheck_status must be {expected_recheck_status} for the declared impact set"
                    )

        if isinstance(record_id, str):
            known_ids.add(record_id)

    # Check correction link targets exist in the assembled ledger as well.
    for index, record in enumerate(records):
        if not isinstance(record, dict) or record.get("record_kind") != "CORRECTION":
            continue
        affected = record.get("affected_record_ids", [])
        recheck = record.get("recheck_required_record_ids", [])
        if not isinstance(affected, list) or not isinstance(recheck, list):
            continue
        for ref in affected + recheck:
            if not isinstance(ref, str) or ref not in record_map:
                errors.append(f"records[{index}] references unknown affected record")

    return errors


def create_interpretation_record(
    session: dict[str, Any], records: list[dict[str, Any]], *,
    source_type: str, source_ref: str, verbatim_excerpt: str, interpretation: str,
    assertion_type: str, epistemic_status: str,
    record_kind: str = "INTERPRETATION", actor: str = "LLM",
    branch_id: str | None = None, fidelity_status: str = "NOT_ASSESSED",
    structure_status: str = "UNSTRUCTURED", depends_on_record_ids: Iterable[str] = (),
    assumptions: Iterable[dict[str, Any]] = (), confirmation_ref: str | None = None,
    timestamp: str | None = None, record_id: str | None = None,
    notes: Iterable[str] = (),
) -> dict[str, Any]:
    """Create an opt-in interpretation record; does not append or persist it."""
    existing_errors = validate_interpretation_records(records, session)
    if existing_errors:
        raise ValueError("existing interpretation records are invalid: " + "; ".join(existing_errors))
    if not isinstance(session, dict) or not isinstance(session.get("session_id"), str):
        raise ValueError("a valid session with session_id is required")
    if record_kind not in RECORD_KINDS - {"CORRECTION"}:
        raise ValueError("record_kind must be SOURCE_CAPTURE, INTERPRETATION, or STRUCTURE_DECISION")
    if source_type not in SOURCE_TYPES - {"USER_CORRECTION"}:
        raise ValueError("source_type must not be USER_CORRECTION; use create_user_correction_record")
    if actor not in {"HUMAN", "LLM", "HOST"}:
        raise ValueError("unsupported actor")
    branch_id = branch_id or session.get("active_branch_id")
    branches = session.get("branches", [])
    branch_ids = {
        b.get("branch_id") for b in branches
        if isinstance(branches, list) and isinstance(b, dict) and isinstance(b.get("branch_id"), str)
    }
    if branch_id not in branch_ids:
        raise ValueError("branch_id does not exist in session")
    seq = max((r.get("sequence", 0) for r in records), default=0) + 1
    record: dict[str, Any] = {
        "schema_version": "1.0", "record_id": record_id or _new_id(),
        "sequence": seq, "session_id": session["session_id"], "branch_id": branch_id,
        "timestamp": timestamp or _now(), "actor": actor, "record_kind": record_kind,
        "source_type": source_type, "source_ref": source_ref,
        "verbatim_excerpt": verbatim_excerpt, "interpretation": interpretation,
        "assertion_type": assertion_type, "epistemic_status": epistemic_status,
        "fidelity_status": fidelity_status, "structure_status": structure_status,
        "depends_on_record_ids": list(depends_on_record_ids),
        "supersedes_record_ids": [], "affected_record_ids": [],
        "recheck_required_record_ids": [], "recheck_status": "NOT_REQUIRED",
        "assumptions": _copy(list(assumptions)), "record_policy": "APPEND_NEW_RECORD_FOR_CORRECTIONS",
    }
    if confirmation_ref is not None:
        record["confirmation_ref"] = confirmation_ref
    if notes:
        record["notes"] = list(notes)
    errors = validate_interpretation_records(records + [record], session)
    if errors:
        raise ValueError("new interpretation record is invalid: " + "; ".join(errors))
    return record


def create_user_correction_record(
    session: dict[str, Any], records: list[dict[str, Any]], *,
    target_record_id: str, corrected_text: str, reason: str,
    source_ref: str = "CURRENT_TURN", branch_id: str | None = None,
    timestamp: str | None = None, record_id: str | None = None,
) -> dict[str, Any]:
    """Create an append-only correction and list declared downstream records to recheck.

    The function never edits or deletes the target or dependent records. Only
    dependencies explicitly listed in `depends_on_record_ids` are propagated.
    """
    if not isinstance(session, dict) or not isinstance(session.get("session_id"), str):
        raise ValueError("a valid session with session_id is required")
    existing_errors = validate_interpretation_records(records, session)
    if existing_errors:
        raise ValueError("existing interpretation records are invalid: " + "; ".join(existing_errors))
    target = next((r for r in records if r.get("record_id") == target_record_id), None)
    if target is None:
        raise ValueError(f"unknown target_record_id: {target_record_id}")
    if not corrected_text.strip() or not reason.strip():
        raise ValueError("corrected_text and reason must be non-empty")

    descendants = _downstream_record_ids(records, target_record_id)
    affected = [target_record_id, *descendants]
    correction = {
        "schema_version": "1.0", "record_id": record_id or _new_id(),
        "sequence": max((r.get("sequence", 0) for r in records), default=0) + 1,
        "session_id": session["session_id"],
        "branch_id": branch_id or session.get("active_branch_id"),
        "timestamp": timestamp or _now(), "actor": "HUMAN",
        "record_kind": "CORRECTION", "source_type": "USER_CORRECTION",
        "source_ref": source_ref, "verbatim_excerpt": corrected_text,
        "interpretation": corrected_text, "assertion_type": "USER_STATED",
        "epistemic_status": "STATED", "fidelity_status": "CORRECTED",
        "structure_status": "UNSTRUCTURED", "depends_on_record_ids": [],
        "supersedes_record_ids": [target_record_id],
        "affected_record_ids": affected,
        "recheck_required_record_ids": descendants,
        "recheck_status": "REQUIRED" if descendants else "NOT_REQUIRED",
        "correction_reason": reason,
        "assumptions": [], "record_policy": "APPEND_NEW_RECORD_FOR_CORRECTIONS",
    }
    errors = validate_interpretation_records(records + [correction], session)
    if errors:
        raise ValueError("new correction record is invalid: " + "; ".join(errors))
    return correction


def append_interpretation_record(
    session: dict[str, Any], events: list[dict[str, Any]],
    records: list[dict[str, Any]], record: dict[str, Any],
) -> tuple[dict[str, Any], list[dict[str, Any]], list[dict[str, Any]]]:
    """Append a record and its cognitive trace event without mutating inputs."""
    from .cognitive_trace import _validate_pair

    _validate_pair(session, events)
    errors = validate_interpretation_records(records + [record], session)
    if errors:
        raise ValueError("interpretation ledger is invalid: " + "; ".join(errors))
    event_type = "USER_CORRECTION_RECORDED" if record.get("record_kind") == "CORRECTION" else "INTERPRETATION_RECORDED"
    details = {
        "interpretation_record_id": record["record_id"],
        "record_kind": record["record_kind"],
        "epistemic_status": record["epistemic_status"],
        "fidelity_status": record["fidelity_status"],
        "structure_status": record["structure_status"],
    }
    if event_type == "USER_CORRECTION_RECORDED":
        details.update({
            "supersedes_record_ids": record["supersedes_record_ids"],
            "affected_record_ids": record["affected_record_ids"],
            "recheck_required_record_ids": record["recheck_required_record_ids"],
            "correction_reason": record["correction_reason"],
        })
    event = _build_event(
        session, events, branch_id=record["branch_id"], event_type=event_type,
        summary=("ユーザー訂正を記録し、依存関係が明示された下流記録を再確認対象にした。"
                 if event_type == "USER_CORRECTION_RECORDED" else "解釈整合性レコードを記録した。"),
        actor=record["actor"], timestamp=record["timestamp"],
        details=details, outcome="OBSERVED",
    )
    updated_session, updated_events = _append_event(session, events, event)
    updated_records = _copy(records) + [_copy(record)]
    return updated_session, updated_events, updated_records
