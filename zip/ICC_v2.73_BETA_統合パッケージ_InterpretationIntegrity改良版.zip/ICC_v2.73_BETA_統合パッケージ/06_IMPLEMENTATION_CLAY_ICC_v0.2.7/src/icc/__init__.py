"""CLAY ICC v0.2.7 — v2.73 interpretation integrity implementation candidate."""
__version__ = "0.2.7"
