# CLAY_ICC v0.2.7 — Test Report

**Date:** 2026-11-15  
**Scope:** ICC v2.73 Interpretation Integrity Layer and full regression suite  
**Environment:** Python 3.13 / pytest

## Result

- `121 passed`
- `11 subtests passed`

## Added test coverage

- Original source excerpt and model interpretation remain separate fields.
- User-stated content and model inference use distinct provenance labels.
- Provisional epistemic and structure states remain provisional.
- `USER_CONFIRMED` structure requires a confirmation reference.
- User corrections append new records without mutating the supplied history.
- Transitive downstream records are listed for re-examination using declared dependencies.
- Correction and interpretation records emit the expected Cognitive Trace events.
- Malformed non-string dependency values are rejected without crashing the validator.
- Forward/missing dependency references and incorrect correction-impact lists are rejected.

## Regression scope

The existing CLAY_ICC v0.2.5-compatible and v0.2.6 cognitive trace tests were retained and run with the new tests.

## Limitations

The test suite validates deterministic schema/record/relationship behavior only. It does not prove semantic equivalence, complete discovery of implicit reasoning dependencies, factual correctness, actual LLM adherence, or Host persistence/authentication. The new record API is opt-in and does not automatically capture all conversation turns.
