# CLAY Iterative Coordinate Convergence (ICC) v0.2.7

**Status:** reference implementation candidate for ICC v2.73 Beta. Not a production-certified reasoning engine.

ICC is a human-governed specialist module for problem engineering: it structures a finite problem space, proposes problem-specific evaluation axes, preserves critical conditions, organizes evidence and counterevidence, guides bounded diffusion/convergence, tracks residuals, prepares phase handoffs, and packages manual independent reviews. v0.2.7 retains the v0.2.6 cognitive trace capabilities and adds an opt-in Interpretation Integrity Layer: source/interpretation separation, provenance and uncertainty labels, provisional-structure states, and correction-impact tracking based on explicitly declared dependencies.

## Architecture boundary

| Component | Owns | Does not own |
|---|---|---|
| BTM v0.2.0 | Verified Fidelity, instruction lifecycle, request rigor, diffusion/convergence direction, bounded scope | ICC Problem Box, formal coordinate model, evidence graph, phase lifecycle |
| ICC | Problem Box, axes, non-compensatory gates, evidence organization, specialist process guidance, v2.73 session/event structural logic | Host permissions, tool execution, domain certification, autonomous final decisions |
| Host / human | Identity/provenance verification, approvals, persistence, tool execution, external checks, archive retrieval policy | Must not delegate its permissions/approval role merely by loading ICC |

## Compatibility and invariants

- The existing v0.2.5 Problem Box, axis, evidence, analysis, BTM, prompt compiler, and external-review paths are retained.
- `EXPLORATION` / `FORMAL_EVALUATION` remain an outer conversational mode; they are not added to the formal phase state machine.
- Mode change does not approve a Problem Box or axis set, and does not activate the formal gate.
- `CRITICAL` axes and `HARD` constraints remain non-compensatory.
- Forking preserves the old branch as `PAUSED`; resuming preserves all other branches.
- A rollback to exploration pauses, but does not delete, an active formal-evaluation state.
- Archive export processes only explicitly supplied session and event JSON. No archive directory scan or retrieval is implemented.
- Local data updates return new objects and append new event records; this is not a cryptographic append-only store.

## Quick start

Python 3.10+; runtime uses the standard library only. Optional JSON Schema checks/tests use `pip install -e .[schema-test]`.

```bash
PYTHONPATH=src python -m unittest discover -s tests -v
PYTHONPATH=src python -m icc validate-bundle --input examples/approved_sample_bundle.json
PYTHONPATH=src python -m icc analyze --input examples/approved_sample_bundle.json
PYTHONPATH=src python -m icc validate-cognitive-session \
  --input examples/cognitive-session.v2.73.json \
  --events examples/cognitive-trace-events.v2.73.json
PYTHONPATH=src python -m icc validate-trace \
  --session examples/cognitive-session.v2.73.json \
  --events examples/cognitive-trace-events.v2.73.json
```

## v2.73 Interpretation Integrity API

See [`docs/INTERPRETATION_INTEGRITY_JA.md`](docs/INTERPRETATION_INTEGRITY_JA.md) for the record schema, API, correction propagation, and limitations.

Main API: `icc.interpretation_integrity.create_interpretation_record`, `create_user_correction_record`, `append_interpretation_record`, and `validate_interpretation_records`. Record creation is opt-in; no automatic transcript capture is implemented.

## v2.73 cognitive trace API

See [`docs/COGNITIVE_TRACE_IMPLEMENTATION_JA.md`](docs/COGNITIVE_TRACE_IMPLEMENTATION_JA.md) for the Japanese implementation guide, API list, CLI examples, invariants, and explicit limitations.

Main API: `icc.cognitive_trace.validate_cognitive_session`, `validate_trace_events`, `set_cognitive_mode`, `fork_branch`, `rollback_to_new_branch`, `resume_branch`, `create_open_issue`, `update_open_issue_status`, and `render_markdown_archive`.

## Existing core and external review

The v0.2.5 core remains available. Problem Box/axis approval still requires a trusted Host-provided verification boundary. The manual ZIP-based external review packet and report-intake flow remain manual; returned findings are never auto-merged or auto-approved.

## What remains outside this package

- Natural-language mode-intent classification and live target-LLM behavioral compliance.
- Host persistence, database transactions, concurrent-writer locking, cryptographic tamper evidence, identity/authentication, and approval authorization.
- Host-level archive retrieval controls, automatic memory isolation, or provider-side memory control.
- External LLM API calls, provider orchestration, or MAS runtime.
- External evidence retrieval, statistical confidence calibration, domain certification, optimization, and physical/destructive tests.

Local tests establish only the tested deterministic code paths. They do not demonstrate the quality of real multi-turn LLM behavior or production Host integration. See `docs/IMPLEMENTATION_STATUS.md` and `docs/TEST_REPORT_v0.2.7.md`.
