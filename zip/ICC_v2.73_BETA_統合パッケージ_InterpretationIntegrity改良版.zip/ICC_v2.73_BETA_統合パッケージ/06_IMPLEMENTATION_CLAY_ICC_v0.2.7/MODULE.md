# MODULE — CLAY Iterative Coordinate Convergence (ICC)

## Identity
- Module ID: `clay.specialist.icc`
- Version: `0.2.7`
- Type: `specialist_thinking_module`
- Status: reference implementation / working design draft
- BTM baseline: `clay.basic-thinking >= 0.2.0`

## Responsibility
ICC provides specialist process structure for finite problem formation, human-approved problem-specific axes, critical-axis and hard-constraint gates, coordinate resolution/expansion, evidence organization, bounded cognitive dynamics, provisional convergence, purpose-preserving recovery, phase records, and human handoff. v0.2.5 adds manual ZIP-based external LLM review packet preparation and structured review-report intake. v0.2.6 adds local semantic validation and state-transition helpers for v2.73 cognitive traces. v0.2.7 adds opt-in interpretation-integrity records and explicit dependency-based correction propagation.

## Non-responsibility
ICC does not certify truth, infer all user intent deterministically, provide domain-specific professional certification, grant permissions, execute tools or experiments, run destructive tests, control hidden model state, guarantee external model compliance, clear provider-side memory, authenticate external reviewers, execute external LLM calls/MAS orchestration, automatically accept findings/axes, or persist records automatically.

## Inputs
- `problem_box`: `schemas/problem-box.schema.json`
- `axis_set`: `schemas/axis-set.schema.json`
- `evidence_records`: `schemas/evidence-record.schema.json`
- `assessments`: `schemas/assessments.schema.json`
- optional `satellite_map`: `schemas/satellite-map.schema.json`
- optional `btm_thinking_control`: BTM v0.2.0 serialized task control subset
- optional phase history / handoff metadata in host-owned storage
- optional v2.73 cognitive session and trace-event JSON (handled by `icc.cognitive_trace`)
- optional interpretation-integrity records (handled by `icc.interpretation_integrity`)

## Outputs
- validation issues
- provisional axis / hard-constraint status analysis
- evidence-independence summary
- optional satellite coverage / relation summary
- compiled ICC specialist prompt
- handoff capsule content for host persistence
- portable external review packet ZIP
- external review report validation result (pending human triage)
- v2.73 cognitive-session validation, branch/mode/issue transition results, and explicit Markdown trace export
- opt-in interpretation records, provenance/uncertainty validation, and correction impact lists for declared dependencies

## Python API
```python
from icc.validation import validate_problem_box, validate_axis_set, validate_bundle
from icc.analysis import analyze_bundle
from icc.policy import validate_btm_control, derive_process_guidance
from icc.prompt_compiler import compile_prompt
from icc.state_machine import validate_transition
from icc.cognitive_trace import (
    validate_cognitive_session, validate_trace_events, fork_branch,
    resume_branch, rollback_to_new_branch, render_markdown_archive,
)
```

## Authority
A recorded approval field is data, not proof of identity or authorization. The Host must verify the approving actor and enforce all permissions. ICC cannot approve its own Problem Box or axes. No manifest or prompt grants authority.

## Safe default
If the Problem Box or axis set is not human-approved, do not perform formal convergence. If a critical axis or hard constraint is untested or inconclusive, feasibility is not established. If a requested change crosses the approved boundary, stop the affected work and return a human-approval request.

## v0.2.0 observation layer
The optional Satellite Observation Map records surrounding factors and subproblem partitions. It broadens observation without changing the approved core axes. The default merge policy is to keep distinct questions separate or link them without merging.

## v0.2.5 external review

```bash
PYTHONPATH=src python -m icc prepare-review --input project.zip --output review_packet.zip --project-name "Project" --project-version "0.2.5"
PYTHONPATH=src python -m icc validate-review-packet --input review_packet.zip
PYTHONPATH=src python -m icc validate-review-report --packet review_packet.zip --report external_review.json --output intake_validation.json
```

External model memory cannot be cleared or verified by ICC. Reviewers disclose session/memory/prior-context state. Returned findings and proposed axes remain untrusted candidates; a valid intake is `VALIDATED_PENDING_HUMAN_TRIAGE`, never an automatic approval or merge.

## v0.2.7 Interpretation Integrity Layer

This layer preserves the original excerpt separately from the model interpretation, labels assertion origin and epistemic status, distinguishes provisional from user-confirmed structure, and appends user corrections with a declared dependency-impact list. It does not automatically judge semantic fidelity or discover implicit dependencies.
