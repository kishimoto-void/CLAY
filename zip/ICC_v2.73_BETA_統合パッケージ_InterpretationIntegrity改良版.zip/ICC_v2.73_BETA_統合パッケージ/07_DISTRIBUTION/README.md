# CLAY_ICC v0.2.7 — Python wheel

This wheel contains the v2.73-compatible local reference implementation, including the Interpretation Integrity module, its JSON Schema, and Japanese/English prompt addenda.

Install with:

```bash
python -m pip install clay_icc-0.2.7-py3-none-any.whl
```

The wheel was built and installed into an isolated target directory for a smoke test. Local regression tests are documented in `06_IMPLEMENTATION_CLAY_ICC_v0.2.7/docs/TEST_REPORT_v0.2.7.md`.

This package does not implement Host persistence/authentication or automatically detect semantic meaning drift or implicit dependencies.
