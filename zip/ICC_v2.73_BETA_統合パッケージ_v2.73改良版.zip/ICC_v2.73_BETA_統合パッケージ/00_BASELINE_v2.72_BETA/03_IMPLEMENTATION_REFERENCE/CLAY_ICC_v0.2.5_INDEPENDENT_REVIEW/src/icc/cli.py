from __future__ import annotations
import argparse
import json
from pathlib import Path
from .validation import validate_problem_box, validate_axis_set, validate_bundle
from .analysis import analyze_bundle
from .prompt_compiler import compile_prompt
from .policy import validate_btm_control
from .independent_review import prepare_review_packet, validate_review_packet, validate_review_report


MAX_JSON_INPUT_BYTES = 5_000_000


def _load(path: str):
    p = Path(path)
    if p.stat().st_size > MAX_JSON_INPUT_BYTES:
        raise ValueError(f"input file exceeds {MAX_JSON_INPUT_BYTES} byte safety limit")
    with p.open("r", encoding="utf-8") as f:
        return json.load(f)


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(prog="icc", description="CLAY ICC structural reference tools")
    sub = parser.add_subparsers(dest="command", required=True)
    for name in ("validate-problem", "validate-axes", "validate-bundle", "analyze"):
        p = sub.add_parser(name)
        p.add_argument("--input", required=True)
    pr = sub.add_parser("prepare-review", help="prepare a portable packet for an external LLM review")
    pr.add_argument("--input", required=True, help="source project ZIP")
    pr.add_argument("--output", required=True, help="review packet ZIP to create")
    pr.add_argument("--project-name", help="human-readable project name")
    pr.add_argument("--project-version", help="project version (recorded as supplied)")
    vp = sub.add_parser("validate-review-packet", help="verify packet inventory and SHA-256 hashes")
    vp.add_argument("--input", required=True, help="review packet ZIP")
    vr = sub.add_parser("validate-review-report", help="validate an external reviewer JSON report against a packet")
    vr.add_argument("--packet", required=True, help="review packet ZIP")
    vr.add_argument("--report", required=True, help="external reviewer JSON report")
    vr.add_argument("--output", help="optional path for the intake validation record")
    c = sub.add_parser("compile")
    c.add_argument("--input", required=True, help="ICC JSON bundle")
    c.add_argument("--btm-control", help="optional BTM v0.2.0 thinking-control JSON")
    c.add_argument("--target", default="generic")
    c.add_argument("--language", choices=["ja", "en"], default="ja")
    c.add_argument("--output", required=True)
    args = parser.parse_args(argv)
    if args.command == "prepare-review":
        result = prepare_review_packet(args.input, args.output, args.project_name, args.project_version)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    if args.command == "validate-review-packet":
        result = validate_review_packet(args.input)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    if args.command == "validate-review-report":
        result = validate_review_report(args.packet, args.report)
        if args.output:
            out = Path(args.output)
            out.parent.mkdir(parents=True, exist_ok=True)
            out.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0 if result["valid"] else 2
    data = _load(args.input)
    if args.command == "validate-problem":
        errors = validate_problem_box(data)
    elif args.command == "validate-axes":
        errors = validate_axis_set(data)
    elif args.command == "validate-bundle":
        errors = validate_bundle(data)
    elif args.command == "analyze":
        result = analyze_bundle(data)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0 if not any(x["severity"] == "ERROR" for x in result["issues"]) else 2
    else:
        control = _load(args.btm_control) if args.btm_control else None
        control_errors = validate_btm_control(control)
        if control_errors:
            print(json.dumps({"errors": control_errors}, ensure_ascii=False, indent=2))
            return 2
        prompt = compile_prompt(data, control, args.target, args.language)
        Path(args.output).write_text(prompt, encoding="utf-8")
        print(f"Prompt written: {args.output}")
        return 0
    print(json.dumps({"valid": not errors, "errors": errors}, ensure_ascii=False, indent=2))
    return 0 if not errors else 2


if __name__ == "__main__":
    raise SystemExit(main())
