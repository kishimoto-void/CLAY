"""CLAY Iterative Coordinate Convergence (ICC) reference implementation."""
__version__ = "0.2.5"
