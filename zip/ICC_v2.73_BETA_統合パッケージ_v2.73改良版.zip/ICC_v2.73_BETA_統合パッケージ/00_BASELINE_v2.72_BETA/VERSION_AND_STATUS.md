# Version / Status Map

## Version separation

- `ICC v2.72 Beta`: conversational design/specification candidate.
- `CLAY_ICC v0.2.5`: Python reference implementation package, unchanged.
- `ICC v2.71`: preserved baseline package.
- `ICC v2.8`: reference-only materials, not merged into v2.72 Beta.

## Change status

| Area | Status in this package | Notes |
|---|---|---|
| v2.71 baseline documents | PRESERVED | Copied unchanged from the v2.71 archive |
| v2.5-v2.6 history | PRESERVED | Historical reference only |
| v2.8 input-repair proposal | REFERENCE ONLY | Not promoted to v2.72 specification |
| v2.72 design notes | ADDED / DRAFT | Candidate design; requires next-turn review |
| v2.72 prompt addendum | ADDED / DRAFT | Additional prompt layer; not yet merged into the old system prompt |
| External review prompts | ADDED / DRAFT | Manual copy-and-paste workflow; no provider calls |
| CLAY_ICC v0.2.5 Python source | UNCHANGED | No new v2.72 runtime implementation |
| JSON schemas | UNCHANGED | Schema integration deferred |
| Python tests | UNCHANGED | Test suite verifies v0.2.5 reference behavior only |

## Evidence language

- “Included” means present in this ZIP.
- “Specified” means described in an MD or prompt draft.
- “Implemented” means present in executable code and covered by an appropriate test.
- “Validated” means a stated test was actually run and its output recorded.

Do not infer implemented/validated status from a design note or prompt.
