# FILE INDEX — ICC v2.73 Beta

Total files (excluding root FILE_INDEX.md and SHA256SUMS.txt): 206
Top-level directory/file counts: `00_BASELINE_v2.72_BETA`: 116, `01_SPEC`: 1, `02_PROMPTS`: 2, `03_DATA_MODEL`: 7, `04_IMPLEMENTATION_PLAN`: 1, `05_VERIFICATION`: 2, `06_IMPLEMENTATION_CLAY_ICC_v0.2.6`: 74, `CHANGELOG_ICC_v2.73_BETA.md`: 1, `README_ICC_v2.73_BETA.md`: 1, `VERSION_AND_STATUS.md`: 1

## Main navigation
- `README_ICC_v2.73_BETA.md` — package overview, implementation scope, test result, and next steps.
- `VERSION_AND_STATUS.md` — version boundaries and implementation status matrix.
- `CHANGELOG_ICC_v2.73_BETA.md` — changes across Stage 1 and Stage 2.
- `01_SPEC/ICC_v2.73_BETA_統合仕様案.md` — canonical v2.73 design specification.
- `02_PROMPTS/` — Japanese integrated prompt and mode/rollback operating table.
- `03_DATA_MODEL/` — Cognitive Session / Trace Event schemas, examples, and archive template.
- `04_IMPLEMENTATION_PLAN/` — compatibility decisions and staged implementation plan.
- `05_VERIFICATION/` — case checklist and evidence-based verification report.
- `06_IMPLEMENTATION_CLAY_ICC_v0.2.6/` — executable Python reference candidate, CLI, tests, schemas, prompt addenda, examples, and documentation.
- `00_BASELINE_v2.72_BETA/` — preserved v2.72 baseline, including CLAY_ICC v0.2.5 reference implementation and previous source archives.

## Start here for implementation
1. `06_IMPLEMENTATION_CLAY_ICC_v0.2.6/README.md`
2. `06_IMPLEMENTATION_CLAY_ICC_v0.2.6/docs/COGNITIVE_TRACE_IMPLEMENTATION_JA.md`
3. `06_IMPLEMENTATION_CLAY_ICC_v0.2.6/src/icc/cognitive_trace.py`
4. `06_IMPLEMENTATION_CLAY_ICC_v0.2.6/src/icc/cli.py`
5. `06_IMPLEMENTATION_CLAY_ICC_v0.2.6/tests/test_cognitive_trace.py`

## Important boundary
The v0.2.6 module is a deterministic local reference implementation. Host persistence, authentication, authorization, enforced archive retrieval isolation, and independent LLM behavior validation remain outside this package’s completed implementation scope.

## Integrity
`SHA256SUMS.txt` contains SHA-256 hashes for every file in this package except itself. The baseline directory also retains its own original checksum manifest.
