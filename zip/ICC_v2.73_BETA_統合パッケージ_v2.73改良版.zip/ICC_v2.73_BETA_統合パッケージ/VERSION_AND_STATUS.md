# ICC v2.73 Beta — Version and Status

## Version separation
- ICC v2.73 Beta: conversational design/specification and consolidated prompt.
- CLAY_ICC v0.2.5: existing Python reference baseline preserved under `00_BASELINE_v2.72_BETA/`.
- CLAY_ICC v0.2.6: v2.73 cognitive trace reference implementation candidate under `06_IMPLEMENTATION_CLAY_ICC_v0.2.6/`.
- Host integration: persistence, authentication, authorization, and archive retrieval enforcement; not implemented.

## Status matrix

| Area | Status | Detail |
|---|---|---|
| v2.7 core concepts | PRESERVED / INTEGRATED | Problem choice, thinking space, 3 functions, 6 dials |
| v2.72 design candidates | INTEGRATED / REFINED | Collaborative fidelity, axes, hypotheses, causality, multiperspective, legal/ethics |
| Cognitive modes | SPECIFIED + EXPLICIT STATE API | EXPLORATION / FORMAL_EVALUATION; no deterministic NLP classifier |
| Mode triggers | SPECIFIED | Natural-language intent remains target-LLM/Host responsibility |
| Rollback and branches | IMPLEMENTED (local logic) | Fork/resume/rollback with branch history preservation |
| Open issues | IMPLEMENTED (local logic) | Branch-scoped issue state and event updates |
| Session / event schemas | INCLUDED + VALIDATED | Copied into v0.2.6 implementation package and checked by tests |
| Semantic session validator | IMPLEMENTED | Active branch, parent graph, issue/event references, session invariants |
| Event validator | IMPLEMENTED | Schema, unique increasing sequence, prior related-event references |
| Markdown archive export | IMPLEMENTED (local) | Only explicitly supplied records; no archive scanning |
| Consolidated prompt | INCLUDED / DRAFT | v2.73 addendum is composed with the existing specialist prompt by the local prompt compiler; target behavior not independently tested |
| CLAY_ICC Python core | PRESERVED + EXTENDED | v0.2.5 baseline retained; v0.2.6 candidate adds cognitive trace logic |
| Existing schemas / CLI / prompt compiler | COMPATIBLY EXTENDED | Existing paths retained; additive CLI commands |
| Host persistence/retrieval | NOT IMPLEMENTED | No database, permissions, or automatic archive isolation |
| Human approval authentication | NOT IMPLEMENTED | Host must authenticate approver and verify authorization |
| Independent behavioral test | NOT_EXECUTED | Five-turn dialogue test remains planned |

## Verification summary
- v0.2.5 baseline regression suite retained.
- v0.2.6 local test run: 112 passed, 11 subtests passed.
- Python wheel build and package-data inspection: PASS (core module, both v2.73 schemas, JA/EN prompt addenda included).
- New v2.73 invariants tested: active-branch uniqueness, parent cycles, event ordering/references, fork, resume, rollback, mode/gate separation, issue lifecycle, and manual archive policy.
- No external LLM was queried and no Host behavior was tested.

## Evidence language
- INCLUDED: file exists in this package.
- SPECIFIED: described in specification or prompt.
- IMPLEMENTED: present in executable code.
- VALIDATED: relevant local test was actually run.
- NOT_EXECUTED: no claim of test or behavior is made.
