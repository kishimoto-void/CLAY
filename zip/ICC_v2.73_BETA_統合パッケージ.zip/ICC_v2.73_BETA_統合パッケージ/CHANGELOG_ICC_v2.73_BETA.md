# CHANGELOG — ICC v2.73 Beta

## v2.73 Beta — 2026-11-14 (Stage 1)

### Added
- Integrated upper principles: Collaborative Fidelity, human agency, non-forced convergence, legal and ethical integrity.
- Separated cognitive mode from thinking direction, rigor, scope, recognition axes, and six weighting dials.
- Added natural-language trigger rules for Exploration and Formal Evaluation.
- Added rollback/branch preservation and unresolved issue states.
- Integrated abstract recognition axis to contextual evaluation item traceability.
- Integrated symmetric hypothesis evaluation, bidirectional causal evaluation, iterative hypothesis reassessment, multi-perspective and external LLM principles.
- Added Human-Governed Knowledge Retrieval and Minimal Context Principle.
- Added Cognitive Session and Trace Event JSON Schema proposals and Markdown Archive template.
- Added compatibility mapping and staged implementation roadmap.

### Not changed
- CLAY_ICC v0.2.5 Python runtime code, CLI, existing schemas, and prompt compiler.
- ICC v2.71 and v2.72 source baselines.

### Not yet verified
- New behavior in actual LLM conversation, Host-level archive exclusion, session persistence, branch runtime, and external multi-model behavior.
