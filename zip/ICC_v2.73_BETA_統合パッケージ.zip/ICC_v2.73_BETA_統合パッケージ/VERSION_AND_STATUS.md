# ICC v2.73 Beta — Version and Status

## Version separation
- ICC v2.73 Beta: conversational design/specification and prompt integration draft.
- CLAY_ICC v0.2.5: existing Python reference implementation, unchanged.
- CLAY_ICC v0.2.6: possible next implementation version; not created in this package.
- ICC v2.72 Beta: preserved source baseline under `00_BASELINE_v2.72_BETA/`.

## Status matrix

| Area | Status | Detail |
|---|---|---|
| v2.7 core concepts | PRESERVED / INTEGRATED | Problem choice, thinking space, 3 functions, 6 dials |
| v2.72 design candidates | INTEGRATED / REFINED | Collaborative fidelity, axes, hypotheses, causality, multiperspective, legal/ethics |
| Cognitive modes | SPECIFIED | EXPLORATION / FORMAL_EVALUATION; no deterministic NLP classifier |
| Mode triggers | SPECIFIED | Natural-language intent; ambiguity does not cause silent switch |
| Rollback and branches | SPECIFIED | Prior branches retained; new branch on changed premise |
| Open issues | SPECIFIED / SCHEMA DRAFT | IDs and state labels; runtime persistence not implemented |
| Human-governed archive | SPECIFIED / TEMPLATE | Markdown export format and manual-only retrieval policy |
| Minimal context | SPECIFIED | Host enforcement required |
| New JSON Schemas | ADDED / DRAFT | Not wired to existing validators/CLI |
| Consolidated prompt | ADDED / DRAFT | Not installed in Host runtime |
| CLAY_ICC Python code | UNCHANGED | v0.2.5 reference source kept under baseline |
| Existing schemas/CLI | UNCHANGED | No breaking changes |
| Host persistence/retrieval | NOT IMPLEMENTED | Host responsibility |
| Independent behavioral test | NOT EXECUTED | Planned next stage |

## Evidence language

- INCLUDED: file exists in this package.
- SPECIFIED: described in specification or prompt.
- IMPLEMENTED: present in executable code.
- VALIDATED: the relevant test was actually run.
- NOT_EXECUTED: no claim of test or behavior is made.
