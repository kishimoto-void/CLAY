# FILE INDEX — ICC v2.73 Beta

Total files (excluding FILE_INDEX.md and SHA256SUMS.txt): 128

## New v2.73 files
- `01_SPEC/ICC_v2.73_BETA_統合仕様案.md` (27,286 bytes)
- `02_PROMPTS/ICC_v2.73_BETA_モード切替・ロールバック運用表.md` (3,407 bytes)
- `02_PROMPTS/ICC_v2.73_BETA_統合システムプロンプト_JA.md` (13,423 bytes)
- `03_DATA_MODEL/ICC_Cognitive_Trace_Archive_Template.md` (2,831 bytes)
- `03_DATA_MODEL/README_DATA_MODEL.md` (3,040 bytes)
- `03_DATA_MODEL/examples/example-cognitive-session.json` (1,678 bytes)
- `03_DATA_MODEL/examples/example-trace-event.json` (787 bytes)
- `03_DATA_MODEL/icc-cognitive-session.schema.json` (4,790 bytes)
- `03_DATA_MODEL/icc-trace-event.schema.json` (2,893 bytes)
- `04_IMPLEMENTATION_PLAN/v2.73_BETA_実装互換性と段階計画.md` (6,681 bytes)
- `05_VERIFICATION/ICC_v2.73_BETA_ケースベース整合性チェック.md` (3,977 bytes)
- `05_VERIFICATION/ICC_v2.73_BETA_整合性検証レポート.md` (2,873 bytes)

## Root files
- `README_ICC_v2.73_BETA.md`
- `VERSION_AND_STATUS.md`
- `CHANGELOG_ICC_v2.73_BETA.md`
- `FILE_INDEX.md`
- `SHA256SUMS.txt`

## Preserved baseline
- `00_BASELINE_v2.72_BETA/` contains the previous v2.72 Beta package unchanged.
