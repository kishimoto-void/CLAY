# ICC v2.73 Cognitive Trace Runtime — CLAY_ICC v0.2.6

## 1. 位置づけ

本ディレクトリはICC v2.73 Betaのデータモデルを扱うための、CLAY_ICC v0.2.6参照実装候補である。v0.2.5の既存Problem Box／axis／Evidence／分析／外部レビュー機能を維持し、認知モード、枝、未解決課題、Trace Eventの純粋ロジックを追加する。

認知モードは既存の正式phase state machineに追加していない。`EXPLORATION`／`FORMAL_EVALUATION`は会話運用レイヤー、既存phaseは承認済みProblem Box／axis-setに基づく正式評価の内側レイヤーである。

## 2. 追加したPython API

`icc.cognitive_trace`:

- `validate_cognitive_session(session, events=None)` — JSON Schemaと意味的不変条件を確認する。
- `validate_trace_events(events, session=None)` — event schema、session/branch参照、sequence、related-event参照を確認する。
- `set_cognitive_mode(...)` — 呼び出し元が明示したモード変更を記録する。自然言語分類はしない。
- `fork_branch(...)` — active branchをPAUSEDにし、新しいACTIVE branchを作る。
- `rollback_to_new_branch(...)` — 必要な場合にEXPLORATIONへ戻し、正式評価をPAUSEDで保持して新枝を作る。
- `resume_branch(...)` — PAUSEDまたはARCHIVEDの既存枝を再開し、他の枝を保持する。
- `create_open_issue(...)` / `update_open_issue_status(...)` — 未解決課題の状態と変更イベントを記録する。
- `render_markdown_archive(session, events)` — 呼び出し元が明示的に渡した構造化記録だけをMarkdown化する。

変更関数は入力dict/listを直接変更せず、新しいsessionとeventsを返す。Trace Eventのsequenceは既存最大値+1。訂正・状態変更は新しいeventとして記録する。

## 3. 意味的Validatorが確認する主な不変条件

1. `active_branch_id`が存在し、そのbranchだけがACTIVEである。
2. branch IDとissue IDはsession内で一意である。
3. parent branchが同一session内に存在し、branch graphに循環がない。
4. branch / issueのevent referenceが、渡されたevent集合内に存在する。
5. event sequenceは配列内で一意かつ厳密に増加し、related_event_idsは前のeventを参照する。
6. eventのsession_idとbranch_idが、指定されたsessionに整合する。
7. `formal_evaluation_state=ACTIVE`の場合、Problem Box参照とaxis-set参照がある。
8. `MANUAL_ONLY`と`autoload_archived_traces=false`を維持する。

イベント参照の整合性を確認するには、sessionだけでなくevents配列もValidatorへ渡す。JSON Schema合格だけで意味的整合性が保証されるわけではない。

## 4. CLI

以下はすべて、明示指定されたローカルJSONファイルだけを読み込む。

```bash
# v2.73 Session + Event参照の検証
PYTHONPATH=src python -m icc validate-cognitive-session \
  --input examples/cognitive-session.v2.73.json \
  --events examples/cognitive-trace-events.v2.73.json

# Trace Event配列の検証
PYTHONPATH=src python -m icc validate-trace \
  --session examples/cognitive-session.v2.73.json \
  --events examples/cognitive-trace-events.v2.73.json

# 既存枝から新しい枝を作る（入力を保持し、出力先を分ける）
PYTHONPATH=src python -m icc trace-fork \
  --session examples/cognitive-session.v2.73.json \
  --events examples/cognitive-trace-events.v2.73.json \
  --branch-id branch-C \
  --summary "前提を変えた代替案を探索" \
  --changed-assumption "初期条件Xを固定しない" \
  --out-session /tmp/icc-session-next.json \
  --out-events /tmp/icc-events-next.json

# 正式評価から探索へ戻り、新しい枝を開始
PYTHONPATH=src python -m icc trace-rollback \
  --session /tmp/icc-session-formal.json \
  --events /tmp/icc-events-formal.json \
  --branch-id branch-exploration-2 \
  --summary "前提を再検討する探索枝" \
  --out-session /tmp/icc-session-rollback.json \
  --out-events /tmp/icc-events-rollback.json

# 指定済みのSession/EventだけをMarkdownへExport
PYTHONPATH=src python -m icc export-trace \
  --session /tmp/icc-session-next.json \
  --events /tmp/icc-events-next.json \
  --output /tmp/icc-trace.md
```

`trace-set-mode`では`--mode`と`--reason`を明示する。コードは発話内容を自動判定せず、仮説が有力になっただけでFormal Evaluationへ移行させない。

## 5. Prompt Compilerへの統合

既存のv0.2.5専門評価プロンプト（日本語／英語）は置き換えていない。v2.73 Addendumを追加し、`compile_prompt(..., language="ja")`では日本語Addendum、`language="en"`では英語Addendumを既存プロンプトの後ろへ連結する。これにより、旧Problem Box／axis／Evidence／Critical／HARDの専門ルールを保持しながら、v2.73の認知モード、自然言語トリガー、人間主導Archive、Minimal Context等を追加する。

Addendumの優先関係では、自由探索に正式Problem Boxを強制せず、正式評価前には既存の人間承認ゲートを維持する。自然言語判定そのものはLLMの動作であり、コンパイラは意図を分類しない。

## 6. テスト

```bash
PYTHONPATH=src python -m unittest discover -s tests -v
# または
PYTHONPATH=src python -m pytest -q
```

v0.2.5の既存回帰テストに加え、v2.73用テストでactive branch整合、複数ACTIVE拒否、親枝循環、欠損event参照、sequence順序、fork/resume、rollback、mode/gate分離、issue lifecycle、manual archive policyを確認する。

## 7. 明確な限界

- Pythonの自然言語理解・モード意図分類器は実装していない。
- これは永続化エンジンではない。関数はメモリ上の新しい値を返し、CLIは明示指定された出力ファイルへ書く。
- 追記型eventのデータモデルは実装したが、ファイルやDBを改ざん不能にする機構、同時書込み制御、署名付き監査ログはない。
- approval refの存在は確認できるが、承認者の本人性・権限・実際の承認は検証しない。信頼できるHost callback/認証境界が必要。
- Problem Box / axis-set参照先の実在性や承認済み状態は、Hostが検証する必要がある。
- archive retrieval、embedding検索、未指定ファイルの自動ロードを制御するHost integrationは含まない。Exporterは渡されたJSONだけを処理する。
- 外部LLM APIやMulti-Agent orchestrationは含まない。

従って、本版は「v2.73の純粋ロジックとローカルCLIを持つ参照実装候補」であり、Production Hostまで完成したものではない。
