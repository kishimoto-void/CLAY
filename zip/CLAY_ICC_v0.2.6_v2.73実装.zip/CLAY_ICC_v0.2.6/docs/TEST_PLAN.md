# ICC Test Plan v0.2.5

## A. Existing core regression tests

- Schema shape, required fields, enums, unique identifiers, and safe types.
- Problem Box approval metadata and axis-set version linkage.
- Hard-constraint and critical-axis incompatibility checks.
- Evidence and assessment cross-reference integrity.
- PASS evidence requirements and contradiction handling.
- Independence-group de-duplication.
- BTM v0.2.0 enum compatibility, omitted-field defaults, and rigor/scope orthogonality.
- State transitions and re-approval requirements.
- Scope-change and axis-change re-approval flags.
- Japanese/English prompt compilation and untrusted-input marking.
- Optional satellite-map references, causal evidence metadata, cycle rejection, and categorical coverage reporting.

## B. v0.2.5 external review package tests

- Prepare a review packet from a valid source ZIP.
- Verify packet manifest and per-file SHA-256 values.
- Detect target-file tampering and manifest inventory mismatch.
- Reject absolute paths, parent traversal, backslash paths, duplicate/case-colliding paths, symlinks, encrypted members, oversized files/archives, and suspicious compression ratios.
- Confirm both language prompts explicitly disclose memory limitations and treat target content as untrusted.
- Bind reviewer reports to exact Package ID and source archive SHA-256.
- Reject reports referencing missing target paths, invalid line ranges, and non-UTF-8 line references.
- Require exactly one coverage entry for each of the nine review categories.
- Require unique Finding IDs and check IDs.
- Require PASS/FAIL execution claims to include target evidence references.
- Require drift status and related Finding IDs to be internally consistent.
- Require every axis proposal to remain a human-approved candidate (`requires_human_approval=true`).
- Reject unknown fields, malformed JSON, Markdown-fenced JSON, and over-limit reports.
- Verify report intake remains pending human triage and never auto-merges findings.

## C. External behavioral review (not run by local tests)

For each named external provider/model, a human reviewer should record:

- Provider and exact model name/version if visible.
- New/temporary session status.
- Memory setting as disabled/enabled/unavailable/unknown.
- Prior familiarity with the project.
- Files actually inspected and files not inspected.
- Commands/tests actually executed, environment, and logs.
- Whether prompt injection, context contamination, and drift checks were followed.
- Findings and axis proposals with exact file/line references.

Do not claim external behavioral conformance until these runs have actually occurred. Multiple model reports are independent review perspectives, not proof by majority vote.

## D. Non-goals

- No external LLM API call or autonomous multi-agent orchestration.
- No provider-side memory clearing or verification.
- No automatic application of external findings or axes.
- No semantic proof that the reviewer inspected every file.
- No cryptographic reviewer identity/signature or production permission system.
- No domain certification or factual truth guarantee.
