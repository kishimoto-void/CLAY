# ICC v0.2.5 外部レビュー報告フォーマット

機械可読な正本は `schemas/external-review-report.schema.json`。生成されたレビュー用ZIPには同じスキーマが `REVIEW_REPORT_SCHEMA.json` として同梱される。JSON Schemaは報告の形・参照整合性を確認するもので、報告内容の真偽やレビュアーの実行環境を認証しない。

## 必須セクション

| 項目 | 目的 |
|---|---|
| `target` | Package IDと元ZIPのSHA-256で対象版を固定 |
| `reviewer_context` | Provider、モデル名、新規セッション、メモリ設定、過去接触を申告 |
| `review_summary` | 全体評価、長所、重大リスク、レビュー上の制約 |
| `drift_assessment` | 資料間の不変条件・目的・責務・版・実装状態のずれを整理し、関連Findingを参照 |
| `checks_executed` | 実施した検査、手順、環境、出力抜粋、対象内証拠参照。未実施は`NOT_RUN` |
| `coverage` | 9領域をREVIEWED / PARTIAL / NOT_REVIEWED / NOT_APPLICABLEで申告 |
| `external_sources` | 外部資料を使った場合のタイトル、発行元、URL、確認日、資料種別、支持する主張 |
| `findings` | 重大度、対象ファイル、行範囲、再現手順、影響、推奨、確信度。外部資料を使った場合は`external_source_ids`で参照 |
| `axis_proposals` | 追加軸候補、Problem Boxとの関係、既存軸との重複、対象内根拠、外部資料、測定方法、PASS条件、トレードオフ |
| `questions` / `limitations` | 未解決事項とレビュー上の制約 |

## Findingの重大度

- `BLOCKER`: 対象の安全な利用・評価を停止すべき重大な問題
- `CRITICAL`: 重要な不変条件・承認境界などへの深刻な違反
- `HIGH`: 大きな機能・安全・仕様上の問題
- `MEDIUM`: 影響が限定されるが修正・明示が望ましい問題
- `LOW`: 軽微な問題や改善余地
- `INFO`: 情報・観察事項であり、欠陥とは限らない

重大度はレビュアーの判断であり、ICCが妥当性やリスク量を自動認証するものではない。

## 実行チェックの扱い

`PASS` / `FAIL`を申告する場合、対象ZIP内の根拠参照に加え、実行環境・手順・出力抜粋が必要。`NOT_RUN`は失敗ではなく未実施。`INCONCLUSIVE`は実施したが判定できなかった状態。`output_excerpt`や実行申告はレビュアーの提出情報であり、ICCは外部環境やログの真正性を認証しない。重大な試験結果は人間が再現する。

外部資料を根拠に使用した場合は、`external_sources`に資料を登録する。Findingや軸候補から`external_source_ids`で参照し、どの主張を支えるかを明確にする。資料が見つからない、URLが開けない、一次資料を確認できない等の場合は、その制約を記録する。出典・URL・ページ・引用を捏造してはならない。

## 軸候補の扱い

`axis_proposals`は現行Axis Setの変更命令ではない。`requires_human_approval`は常に`true`。各候補には対象Problem Boxとの関係、既存軸との重複、対象ファイル中の`evidence_refs`、外部資料を用いた場合の`external_source_ids`、観測・測定方法、PASS条件、追加コストと副作用を含める。

外部LLMは「軸が不足している」と指摘できるが、それだけで新軸を増やす必要はない。既存軸の細分化で足りる場合、Problem Boxに関係しない場合、測定不能な場合、複雑化コストが便益を上回る場合は、追加しない選択を残す。採用時はProblem Boxとの整合、重複、優先度、criticality、交渉可能性、依存関係を見直し、新版Axis Setで検証する。
