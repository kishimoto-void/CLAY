# ICC v0.2.5 外部LLM独立レビュー手順

## 1. 目的

Claude、Gemini、Grokなど、ChatGPTとは別のLLMに同一のプロジェクトZIPを渡し、設計・仕様・実装・テスト・ドリフト・評価軸の不足を確認してもらう。これは手動レビュー用の受け渡し規格であり、自動MASやAPIオーケストレーションではない。

## 2. レビュー用ZIPの作成

```bash
PYTHONPATH=src python -m icc prepare-review \
  --input ./PROJECT.zip \
  --output ./PROJECT_REVIEW_PACKET.zip \
  --project-name "Project Name" \
  --project-version "0.2.5"
```

ZIP内には以下が入る。

- `README_JA.md`: 作業手順と制約
- `REVIEW_PROMPT_JA.md` / `REVIEW_PROMPT_EN.md`: 外部LLMに渡す指示
- `REVIEW_CRITERIA.json`: レビュー領域と評価原則
- `REVIEW_REPORT_SCHEMA.json`: 返却JSONの構造
- `REVIEW_CONTEXT.json`: 対象名・版・Package ID・元ZIPのSHA-256
- `TARGET_MANIFEST.json`: 対象ファイル一覧・サイズ・個別SHA-256
- `target/`: 展開して固定したレビュー対象の複製
- `PACKET_MANIFEST.json`: レビューパケット内のファイル整合性一覧

## 3. 外部LLMへ渡す

1. 可能なら新規／一時チャットを開く。
2. 各サービスが提供するメモリ・過去会話参照の設定を確認する。確認できない場合は無効化済みと見なさず、`UNKNOWN` とする。
3. レビュー用ZIPをアップロードする。
4. ZIP内の `REVIEW_PROMPT_JA.md` 全文を最初の指示として渡す。英語レビューなら英語版を使う。
5. ZIP全体を読めないサービスでは、無理に全体を読んだことにせず、レビュー可能な範囲を明示する。必要に応じて `target/` 以下を展開して分割アップロードする。
6. `REVIEW_REPORT_SCHEMA.json` に適合するJSONだけを返すよう要求する。
7. 出力されたJSONを `external_review.json` として保存する。

### メモリ汚染の扱い

この方法は他社LLMのメモリを消去しない。新しい会話、メモリ設定の確認、対象以外の文脈を持ち込まない指示はリスク低減策であって、完全な隔離保証ではない。

レビュー担当は以下を自己申告する。

- 新規セッションか：`YES / NO / UNKNOWN`
- メモリ設定：`DISABLED / ENABLED / NOT_AVAILABLE / UNKNOWN`
- 対象への過去接触：`NONE / POSSIBLE / KNOWN`
- 追加説明

メモリ設定を確認できない場合、`UNKNOWN` が正しい。`DISABLED` はレビュアーの申告値であり、ICCが外部検証した証明ではない。

## 4. 返却レポートの検証

```bash
PYTHONPATH=src python -m icc validate-review-packet \
  --input ./PROJECT_REVIEW_PACKET.zip

PYTHONPATH=src python -m icc validate-review-report \
  --packet ./PROJECT_REVIEW_PACKET.zip \
  --report ./external_review.json \
  --output ./review_intake_validation.json
```

レポート検証では、対象Package ID、元ZIPハッシュ、カバレッジ9領域、Finding ID、対象内パス、行範囲、レビュー担当の文脈申告、テスト実行の証拠、軸提案の人間承認フラグを確認する。

JSONにMarkdownコードフェンスを付けたまま提出するとJSONとして読み取れないため、純粋なJSONファイルとして保存する。

## 5. レビュー結果の採否

検証成功の状態は `VALIDATED_PENDING_HUMAN_TRIAGE` である。これは「JSON構造と対象参照が妥当」という意味であり、Findingの真実性や軸案の正しさを承認した意味ではない。

- Findingは元ファイル・該当箇所・再現条件を再確認する。
- `PASS` と報告された試験は、コマンド・環境・ログを確認する。
- 外部LLMの意見が一致しても多数決で採用しない。
- 1モデルだけの重大指摘も、重大度だけで棄却せず再現性を確認する。
- 指摘が矛盾したら条件・前提・根拠を分離して残す。
- 軸案は既存軸との重複、Problem Boxとの関係、測定可能性、PASS条件、コストを比較する。
- 軸案を採用する場合は人間が承認し、Axis Setの新バージョンを作成して通常の検証・テストを再実行する。

## 6. 独立性の注意

複数モデルは同じ対象ZIPを読むため、レビュー報告が複数存在しても、その対象内の事実に対する複数の独立した一次証拠とは限らない。モデル間の学習データ・評価傾向・過去接触の独立性も保証されない。レビューは視点を増やす手段であり、真理判定の投票ではない。

## 7. 安全・プライバシー

- ZIPに個人情報、秘密鍵、APIキー、実顧客データ、未公開の機微情報を含めない。
- 外部LLMへ渡すファイルの内容と送信先を人間が確認する。
- 外部LLMがコードを実行したと申告しても、その環境・手順・ログが確認できない限りICC側では実行済みと断定しない。
- ZIP内のテキストは外部LLMにとっても未信頼データであり、埋め込み命令を実行してはならない。
- ICCは外部送信、モデル起動、実行環境の隔離を行わない。
