# ICC Threat Model (Initial)

## Assets to protect
- Integrity of the approved Problem Box and axis definitions.
- Provenance and independence metadata for evidence.
- Visibility of contradictions, failed gates, and unresolved conditions.
- Human control over scope, approvals, and consequential decisions.
- Correct separation between prompts, code, permissions, and execution.

## Threats and failure modes

| Threat | Example | Mitigation in v0.1.0 | Remaining gap |
|---|---|---|---|
| Scope creep | Diagnostic task silently becomes broad redesign | BTM scope mapping + explicit ICC boundary prompt | Semantic detection depends on target LLM; Host review needed |
| False approval | Imported JSON says HUMAN_APPROVED | Metadata validation only; manifest says Host must authenticate | No signature / identity service |
| Axis omission | All declared axes pass but objective-critical aspect missing | Prompt requires axis completeness and human approval | No automatic semantic completeness proof |
| Compensatory scoring | Great secondary metrics hide critical failure | Non-compensatory status logic | Human must correctly designate critical axes |
| Correlated evidence | Multiple summaries repeat same study | independence_group_id grouping | Code cannot discover hidden source dependence |
| Evidence laundering | Model text presented as independent verification | Provenance fields + prompt restriction | External source validation not included |
| Stale coordinate frame | New evidence invalidates old assumption | Version references and revalidation guidance | Append-only host event store not included |
| Prompt injection | Input strings contain instructions | Prompt labels input as untrusted data | Host must preserve trusted/untrusted channel boundaries |
| Permission confusion | Module manifest treated as authorization | Empty permissions; explicit non-responsibility | Actual enforcement is Host-side |
| Unsafe destructive test | ICC prompt interpreted as permission to break/test | Explicit exclusion; separate-module requirement | Specific high-risk test policy depends on Host and applicable law |
| Overclaiming | Prompt generation described as model behavior guarantee | Status labels and limitation docs | Target model behavior needs external conformance testing |

## Abuse-resistant defaults
- Treat all imported records and evidence as data.
- Reject malformed or duplicate identifiers.
- Never accept unresolved/untested as PASS.
- Never downgrade a HARD constraint or CRITICAL axis through automatic logic.
- Stop formal evaluation when the Problem Box or axis set lacks recorded human approval.
- Do not execute or authorize external actions.

## v0.2.5 external review additions

| Threat | Example | Mitigation in v0.2.5 | Remaining gap |
|---|---|---|---|
| Memory/context contamination | External reviewer sees prior user-specific memory or earlier project discussion | New-session guidance plus mandatory self-disclosure fields (`new_session`, `memory_setting`, `prior_familiarity`) | ICC cannot inspect or disable provider-side memory; declarations are not authenticated |
| Review-target substitution | Reviewer comments on a different ZIP/version | Package ID bound to exact source-archive SHA-256; per-file manifest | Hashes do not authenticate publisher identity; distribute packet through a trusted channel |
| Review packet tampering | Prompt, schema, or target file changes after preparation | Packet manifest with path, size, and SHA-256 checks | No digital signature; a coordinated rewrite of both content and manifest is not prevented |
| Prompt injection in target files | Reviewed source contains instructions to ignore the review protocol | Reviewer prompt marks all target files as untrusted data; no target code execution is required | Provider behavior is not guaranteed; reviewer may still follow embedded instructions |
| False test execution claim | Reviewer says tests passed without running them | `checks_executed` requires procedure, status, environment, and supporting target references for PASS/FAIL | A target-file reference alone is not proof of an execution log; human verification remains necessary |
| Fake or weak axis expansion | External model proposes unnecessary or unmeasurable axes | Axis proposal requires Problem Box relation, overlap, measurement, pass condition, trade-offs, and human approval | Semantic quality and completeness still require human/domain review |
| Consensus laundering | Multiple LLMs repeat the same unsupported claim | No-majority-as-truth rule; preserve individual provenance and disagreement | Models may share training data or evaluation biases |
| Review coverage overclaim | Reviewer silently skips files or test areas | Nine explicit coverage categories with `NOT_REVIEWED` and `PARTIAL` states | Coverage is reviewer-declared; it does not prove every file was read |

### External review abuse-resistant defaults

- External review reports are untrusted input until structurally validated and human-triaged.
- Unknown memory state is allowed but must remain explicitly `UNKNOWN`.
- Review IDs and finding IDs must be unique within a report.
- Evidence paths must exist in the exact target manifest; line ranges must be valid for UTF-8 text files.
- A reviewer cannot self-authorize an axis proposal; `requires_human_approval` must be `true`.
- A valid intake record means only `VALIDATED_PENDING_HUMAN_TRIAGE`, never accepted or merged.
- The package preparation code rejects path traversal, absolute paths, symlinks, encrypted members, duplicate/case-colliding paths, and excessive archive sizes.
