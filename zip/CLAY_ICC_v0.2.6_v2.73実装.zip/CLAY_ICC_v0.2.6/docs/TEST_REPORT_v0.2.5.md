# ICC v0.2.5 Test Report

**Date:** 2026-11-10  
**Runtime:** Python 3 (container environment)  
**Package state:** reference implementation / intermediate design release  
**Baseline:** ICC v0.2.0 OBSERVATION ORBIT  
**External provider tests:** NOT RUN

## Final local results

| Check | Result |
|---|---|
| Existing v0.2.0 core + satellite regression tests | PASS — 72 baseline tests retained |
| New external-review tests | PASS — 25 tests |
| New external-review report schema/template check | PASS — 1 additional test |
| **Complete unit/integration/schema suite** | **PASS — 98 tests** |
| Python bytecode compilation (`compileall`) | PASS |
| Draft 2020-12 JSON Schema meta-validation | PASS — all packaged schemas |
| External review report template | PASS — schema validation |
| CLI `prepare-review` | PASS — smoke test |
| CLI `validate-review-packet` | PASS — smoke test |
| CLI `validate-review-report` | PASS — valid report accepted as pending human triage |

## New behaviors covered

- Review packet generation from a source ZIP.
- Exact source archive SHA-256 binding and per-target-file SHA-256 validation.
- Packet-wide manifest integrity validation for prompt, schema, context, and target files.
- Archive traversal, duplicate/case-collision path, symlink, encrypted member, non-regular member, and size/ratio defenses.
- Memory/context disclosure instructions and explicit statement that provider-side memory cannot be controlled or verified by ICC.
- Untrusted-input warning for content contained in the target package.
- Nine-category review coverage ledger.
- Structured drift assessment and executed-check declarations.
- Exact target-file and line-range validation for external Findings and test claims.
- Duplicate Finding / check IDs and unknown report fields rejected.
- Axis proposals remain candidates and require human approval.
- Malformed/unhashable enum values fail closed without uncaught exceptions.
- Review intake does not auto-merge or auto-apply findings.

## Packaging and external review status

- The source ICC v0.2.0 archive was inspected and its 72-test suite was rerun before modification; all 72 passed.
- The complete v0.2.5 suite was executed locally after the final report-schema and validation changes; all 98 tests passed.
- Clean-extraction verification was performed against the final release archive; all 98 tests passed.
- Grok / Claude / Gemini / other external model reviews have **not** been run. The review packet is prepared for those later trials.

## What these checks establish

The results establish deterministic local behavior of the reference implementation in the tested environment: package preparation, archive validation, report structure/target-reference validation, existing ICC regression behavior, and schema validity.

## What these checks do not establish

- That a target LLM follows the review prompt.
- That provider-side memory or prior-chat context was actually isolated.
- That an external report is factually correct or all files were read.
- That external model reviewers are statistically or cognitively independent.
- That suggested axes are complete, optimal, or appropriate for a domain.
- That a test reported as PASS was actually executed unless the human independently verifies its environment/logs.
- That any result is professional certification, security certification, or production readiness.

The ZIP manifests detect accidental or partial tampering when the manifest is trusted; they are not digital signatures and do not authenticate the packet publisher or reviewer.

## Release verification

- Release archive: `CLAY_ICC_v0.2.5_INDEPENDENT_REVIEW.zip`
- Archive integrity: `unzip -t` — PASS, no compressed-data errors.
- Clean extraction: PASS; all 98 tests passed from the extracted release directory.
- Commands executed after clean extraction:
  - `PYTHONPATH=src python -m compileall -q src tests`
  - `PYTHONPATH=src python -m unittest discover -s tests`
- CLI smoke tests included in the suite successfully created and validated a review packet, then accepted a schema-conforming sample report as `VALIDATED_PENDING_HUMAN_TRIAGE`.
- The final release ZIP was rebuilt from the tested source tree and its CRC was rechecked. A separate external-review packet was then generated from that final ZIP and validated successfully.

The clean-extraction test confirms the packaged local reference implementation runs its deterministic suite in this environment. It does not demonstrate behavior from Grok, Claude, Gemini, or another external model; those reviews remain pending.
