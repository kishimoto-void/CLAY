# ICC v0.2.6 Test Report — 2026-11-15

## Scope

This report covers the v0.2.5 regression suite carried into the v0.2.6 candidate and the additional ICC v2.73 cognitive-trace logic.

## Environment and command

- Python: 3.13 runtime in the build environment
- Optional schema test dependency: `jsonschema 4.26.0`
- Test runner: `pytest 9.0.2`
- Command: `PYTHONPATH=src python -m pytest -q`

## Result

```text
112 passed, 11 subtests passed
```

This includes the prior 98-test suite and 14 new tests for:

1. sample Session/Event semantic validity;
2. active branch pointer consistency;
3. rejection of multiple ACTIVE branches;
4. branch-parent cycle rejection;
5. missing branch-origin event rejection;
6. monotonic event sequence and prior related-event references;
7. non-destructive branch fork;
8. branch resume while retaining other branches;
9. rollback to exploration and formal-state pause;
10. mode transition not activating the formal gate;
11. open-issue creation/resolution event lifecycle;
12. explicit-record-only Markdown export;
13. manual archive policy preservation; and
14. Japanese/English prompt compiler inclusion of the v2.73 addendum while retaining the previous specialist contract.

## CLI smoke test

The following paths were executed successfully against the sample records:

- `validate-cognitive-session`
- `validate-trace`
- `trace-fork`
- re-validation after fork
- `export-trace`
- Japanese and English prompt compiler addendum inclusion

The final CLI smoke test exported a 76-line Markdown trace after a branch fork. A wheel build also succeeded; package inspection confirmed inclusion of `cognitive_trace.py`, both v2.73 schemas, and the Japanese/English addenda. No source archive discovery was performed.

## Important limitations

The test result is local code evidence only. It does not constitute a multi-turn LLM behavioral test, independent external-model review, Host integration test, approval/authentication test, persistence durability test, tamper-resistance test, or archive-search exclusion test. The implementation does not authenticate actors or validate the real-world approval state behind Problem Box / axis-set references.
