import copy
import json
from pathlib import Path
import unittest

from icc.cognitive_trace import (
    create_open_issue,
    fork_branch,
    render_markdown_archive,
    resume_branch,
    rollback_to_new_branch,
    set_cognitive_mode,
    update_open_issue_status,
    validate_cognitive_session,
    validate_trace_events,
)

PROJECT_ROOT = Path(__file__).resolve().parents[1]
DATA_ROOT = PROJECT_ROOT / "examples"


def load_fixture():
    session = json.loads((DATA_ROOT / "cognitive-session.v2.73.json").read_text(encoding="utf-8"))
    events = json.loads((DATA_ROOT / "cognitive-trace-events.v2.73.json").read_text(encoding="utf-8"))
    return session, events


class CognitiveTraceTests(unittest.TestCase):
    def test_reference_session_and_events_are_semantically_valid(self):
        session, events = load_fixture()
        self.assertEqual(validate_cognitive_session(session, events), [])
        self.assertEqual(validate_trace_events(events, session), [])

    def test_active_branch_must_match_exactly_one_active_status(self):
        session, events = load_fixture()
        session["active_branch_id"] = "branch-A"
        errors = validate_cognitive_session(session, events)
        self.assertTrue(any("active_branch_id must reference" in e for e in errors))

    def test_multiple_active_branches_are_rejected(self):
        session, events = load_fixture()
        session["branches"][0]["status"] = "ACTIVE"
        errors = validate_cognitive_session(session, events)
        self.assertTrue(any("exactly one ACTIVE branch" in e for e in errors))

    def test_parent_cycle_is_rejected(self):
        session, events = load_fixture()
        session["branches"][0]["parent_branch_id"] = "branch-B"
        errors = validate_cognitive_session(session, events)
        self.assertTrue(any("cycle" in e for e in errors))

    def test_missing_origin_event_is_rejected(self):
        session, events = load_fixture()
        session["branches"][1]["origin_event_id"] = "missing-event"
        errors = validate_cognitive_session(session, events)
        self.assertTrue(any("missing origin event" in e for e in errors))

    def test_event_sequences_must_increase_and_related_events_must_be_prior(self):
        session, events = load_fixture()
        bad = copy.deepcopy(events)
        bad[1]["sequence"] = 3
        bad[1]["related_event_ids"] = ["event-08"]
        errors = validate_trace_events(bad, session)
        self.assertTrue(any("strictly increasing" in e for e in errors))
        self.assertTrue(any("missing or non-prior related event" in e for e in errors))

    def test_fork_is_non_destructive_and_preserves_parent(self):
        session, events = load_fixture()
        original_session = copy.deepcopy(session)
        original_events = copy.deepcopy(events)
        updated, updated_events = fork_branch(
            session, events, branch_id="branch-C", summary="別の前提で検討",
            changed_assumptions=["初期条件Xを固定しない"],
        )
        self.assertEqual(session, original_session)
        self.assertEqual(events, original_events)
        self.assertEqual(updated["active_branch_id"], "branch-C")
        statuses = {b["branch_id"]: b["status"] for b in updated["branches"]}
        self.assertEqual(statuses["branch-B"], "PAUSED")
        self.assertEqual(statuses["branch-C"], "ACTIVE")
        self.assertEqual(validate_cognitive_session(updated, updated_events), [])

    def test_resume_branch_does_not_delete_other_branches(self):
        session, events = load_fixture()
        forked, forked_events = fork_branch(session, events, branch_id="branch-C", summary="新枝")
        resumed, resumed_events = resume_branch(forked, forked_events, branch_id="branch-A")
        statuses = {b["branch_id"]: b["status"] for b in resumed["branches"]}
        self.assertEqual(resumed["active_branch_id"], "branch-A")
        self.assertEqual(statuses["branch-C"], "PAUSED")
        self.assertEqual(len(resumed["branches"]), 3)
        self.assertEqual(validate_cognitive_session(resumed, resumed_events), [])

    def test_rollback_returns_to_exploration_and_pauses_formal_state(self):
        session, events = load_fixture()
        session["cognitive_mode"] = "FORMAL_EVALUATION"
        session["mode_reason"] = "USER_EXPLICIT_REQUEST"
        session["formal_evaluation_state"] = "ACTIVE"
        updated, updated_events = rollback_to_new_branch(
            session, events, branch_id="branch-rollback", summary="別前提を再探索",
        )
        self.assertEqual(updated["cognitive_mode"], "EXPLORATION")
        self.assertEqual(updated["mode_reason"], "USER_REQUESTED_ROLLBACK")
        self.assertEqual(updated["formal_evaluation_state"], "PAUSED")
        self.assertTrue(any(e["event_type"] == "ROLLBACK_STARTED" for e in updated_events))
        self.assertEqual(validate_cognitive_session(updated, updated_events), [])

    def test_mode_change_never_activates_formal_gate_by_itself(self):
        session, events = load_fixture()
        updated, updated_events = set_cognitive_mode(
            session, events, mode="FORMAL_EVALUATION", reason="USER_EXPLICIT_REQUEST",
        )
        self.assertEqual(updated["cognitive_mode"], "FORMAL_EVALUATION")
        self.assertEqual(updated["formal_evaluation_state"], "PAUSED")
        back, back_events = set_cognitive_mode(
            updated, updated_events, mode="EXPLORATION", reason="USER_REQUESTED_ROLLBACK",
        )
        self.assertEqual(back["formal_evaluation_state"], "PAUSED")
        self.assertEqual(validate_cognitive_session(back, back_events), [])

    def test_open_issue_lifecycle_is_append_oriented(self):
        session, events = load_fixture()
        created, created_events = create_open_issue(
            session, events, issue_id="issue-03", title="追加データの不足",
            impact="判断の確度に影響", next_check="出典を確認する",
        )
        resolved, resolved_events = update_open_issue_status(
            created, created_events, issue_id="issue-03", status="RESOLVED",
        )
        issue = next(i for i in resolved["open_issues"] if i["issue_id"] == "issue-03")
        self.assertEqual(issue["status"], "RESOLVED")
        self.assertIsNotNone(issue["origin_event_id"])
        self.assertIsNotNone(issue["resolution_event_id"])
        self.assertEqual(len(resolved_events), len(events) + 2)
        self.assertEqual(validate_cognitive_session(resolved, resolved_events), [])

    def test_archive_contains_only_structured_records_not_full_chat(self):
        session, events = load_fixture()
        archive = render_markdown_archive(session, events)
        self.assertIn("## Branches", archive)
        self.assertIn("## Open Issues", archive)
        self.assertIn("## Trace Events", archive)
        self.assertIn("このファイルは、呼び出し元が明示的に渡した", archive)
        self.assertNotIn("full conversation transcript", archive.lower())

    def test_manual_archive_policy_is_not_relaxed(self):
        session, events = load_fixture()
        session["autoload_archived_traces"] = True
        errors = validate_cognitive_session(session, events)
        self.assertTrue(any("autoload_archived_traces" in e for e in errors))


if __name__ == "__main__":
    unittest.main()
