from __future__ import annotations
import argparse
import json
from pathlib import Path
from .validation import validate_problem_box, validate_axis_set, validate_bundle
from .analysis import analyze_bundle
from .prompt_compiler import compile_prompt
from .policy import validate_btm_control
from .independent_review import prepare_review_packet, validate_review_packet, validate_review_report
from .cognitive_trace import (
    validate_cognitive_session, validate_trace_events, render_markdown_archive,
    set_cognitive_mode, fork_branch, rollback_to_new_branch, resume_branch,
    load_json_file, write_json_file,
)


MAX_JSON_INPUT_BYTES = 5_000_000


def _load(path: str):
    p = Path(path)
    if p.stat().st_size > MAX_JSON_INPUT_BYTES:
        raise ValueError(f"input file exceeds {MAX_JSON_INPUT_BYTES} byte safety limit")
    with p.open("r", encoding="utf-8") as f:
        return json.load(f)


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(prog="icc", description="CLAY ICC structural reference tools")
    sub = parser.add_subparsers(dest="command", required=True)
    for name in ("validate-problem", "validate-axes", "validate-bundle", "analyze"):
        p = sub.add_parser(name)
        p.add_argument("--input", required=True)
    pr = sub.add_parser("prepare-review", help="prepare a portable packet for an external LLM review")
    pr.add_argument("--input", required=True, help="source project ZIP")
    pr.add_argument("--output", required=True, help="review packet ZIP to create")
    pr.add_argument("--project-name", help="human-readable project name")
    pr.add_argument("--project-version", help="project version (recorded as supplied)")
    vp = sub.add_parser("validate-review-packet", help="verify packet inventory and SHA-256 hashes")
    vp.add_argument("--input", required=True, help="review packet ZIP")
    vr = sub.add_parser("validate-review-report", help="validate an external reviewer JSON report against a packet")
    vr.add_argument("--packet", required=True, help="review packet ZIP")
    vr.add_argument("--report", required=True, help="external reviewer JSON report")
    vr.add_argument("--output", help="optional path for the intake validation record")
    c = sub.add_parser("compile")
    c.add_argument("--input", required=True, help="ICC JSON bundle")
    c.add_argument("--btm-control", help="optional BTM v0.2.0 thinking-control JSON")
    c.add_argument("--target", default="generic")
    c.add_argument("--language", choices=["ja", "en"], default="ja")
    c.add_argument("--output", required=True)

    vcs = sub.add_parser("validate-cognitive-session", help="validate v2.73 session and semantic invariants")
    vcs.add_argument("--input", required=True, help="cognitive-session JSON")
    vcs.add_argument("--events", help="optional trace-events JSON array; required to verify event references")

    vte = sub.add_parser("validate-trace", help="validate v2.73 trace events against a session")
    vte.add_argument("--session", required=True)
    vte.add_argument("--events", required=True, help="trace-events JSON array")

    exp = sub.add_parser("export-trace", help="export explicitly supplied session/events to Markdown")
    exp.add_argument("--session", required=True)
    exp.add_argument("--events", required=True)
    exp.add_argument("--output", required=True)

    for command, help_text in (
        ("trace-set-mode", "record an explicit cognitive-mode transition"),
        ("trace-fork", "fork a new branch from the active branch"),
        ("trace-rollback", "return to exploration and fork a new branch"),
        ("trace-resume", "resume a previous branch"),
    ):
        tp = sub.add_parser(command, help=help_text)
        tp.add_argument("--session", required=True)
        tp.add_argument("--events", required=True)
        tp.add_argument("--out-session", required=True)
        tp.add_argument("--out-events", required=True)
        if command == "trace-set-mode":
            tp.add_argument("--mode", required=True, choices=["EXPLORATION", "FORMAL_EVALUATION"])
            tp.add_argument("--reason", required=True, choices=["USER_EXPLICIT_REQUEST", "USER_INTENT_CLEAR", "USER_REQUESTED_ROLLBACK", "RESTORED_FROM_USER_SELECTED_STATE"])
        elif command in {"trace-fork", "trace-rollback"}:
            tp.add_argument("--branch-id", required=True)
            tp.add_argument("--summary", required=True)
            tp.add_argument("--changed-assumption", action="append", default=[])

        else:
            tp.add_argument("--branch-id", required=True)

    args = parser.parse_args(argv)
    if args.command == "prepare-review":
        result = prepare_review_packet(args.input, args.output, args.project_name, args.project_version)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    if args.command == "validate-review-packet":
        result = validate_review_packet(args.input)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    if args.command == "validate-review-report":
        result = validate_review_report(args.packet, args.report)
        if args.output:
            out = Path(args.output)
            out.parent.mkdir(parents=True, exist_ok=True)
            out.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0 if result["valid"] else 2

    if args.command == "validate-cognitive-session":
        session = load_json_file(args.input)
        events = load_json_file(args.events) if args.events else None
        errors = validate_cognitive_session(session, events)
        print(json.dumps({"valid": not errors, "errors": errors}, ensure_ascii=False, indent=2))
        return 0 if not errors else 2
    if args.command == "validate-trace":
        session = load_json_file(args.session)
        events = load_json_file(args.events)
        errors = validate_trace_events(events, session)
        print(json.dumps({"valid": not errors, "errors": errors}, ensure_ascii=False, indent=2))
        return 0 if not errors else 2
    if args.command == "export-trace":
        session = load_json_file(args.session)
        events = load_json_file(args.events)
        if Path(args.output).resolve() in {Path(args.session).resolve(), Path(args.events).resolve()}:
            raise ValueError("Markdown output must not overwrite the supplied session or event input")
        markdown = render_markdown_archive(session, events)
        out = Path(args.output)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(markdown, encoding="utf-8")
        print(f"Trace archive written: {out}")
        return 0
    if args.command in {"trace-set-mode", "trace-fork", "trace-rollback", "trace-resume"}:
        session = load_json_file(args.session)
        events = load_json_file(args.events)
        if args.command == "trace-set-mode":
            new_session, new_events = set_cognitive_mode(session, events, mode=args.mode, reason=args.reason)
        elif args.command == "trace-fork":
            new_session, new_events = fork_branch(
                session, events, branch_id=args.branch_id, summary=args.summary,
                changed_assumptions=args.changed_assumption,
            )
        elif args.command == "trace-rollback":
            new_session, new_events = rollback_to_new_branch(
                session, events, branch_id=args.branch_id, summary=args.summary,
                changed_assumptions=args.changed_assumption,
            )
        else:
            new_session, new_events = resume_branch(session, events, branch_id=args.branch_id)
        input_paths = {Path(args.session).resolve(), Path(args.events).resolve()}
        output_paths = {Path(args.out_session).resolve(), Path(args.out_events).resolve()}
        if len(output_paths) != 2 or output_paths & input_paths:
            raise ValueError("output paths must be distinct from each other and from input paths")
        write_json_file(args.out_session, new_session)
        write_json_file(args.out_events, new_events)
        print(json.dumps({"valid": True, "active_branch_id": new_session["active_branch_id"],
                          "cognitive_mode": new_session["cognitive_mode"],
                          "event_count": len(new_events)}, ensure_ascii=False, indent=2))
        return 0

    data = _load(args.input)
    if args.command == "validate-problem":
        errors = validate_problem_box(data)
    elif args.command == "validate-axes":
        errors = validate_axis_set(data)
    elif args.command == "validate-bundle":
        errors = validate_bundle(data)
    elif args.command == "analyze":
        result = analyze_bundle(data)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0 if not any(x["severity"] == "ERROR" for x in result["issues"]) else 2
    else:
        control = _load(args.btm_control) if args.btm_control else None
        control_errors = validate_btm_control(control)
        if control_errors:
            print(json.dumps({"errors": control_errors}, ensure_ascii=False, indent=2))
            return 2
        prompt = compile_prompt(data, control, args.target, args.language)
        Path(args.output).write_text(prompt, encoding="utf-8")
        print(f"Prompt written: {args.output}")
        return 0
    print(json.dumps({"valid": not errors, "errors": errors}, ensure_ascii=False, indent=2))
    return 0 if not errors else 2


if __name__ == "__main__":
    raise SystemExit(main())
