"""CLAY ICC v0.2.6 — v2.73 cognitive trace implementation candidate."""
__version__ = "0.2.6"
